// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Indonesian (`id`).
class AppLocalizationsId extends AppLocalizations {
  AppLocalizationsId([String locale = 'id']) : super(locale);

  @override
  String get appTitle => 'TerraBot Field';

  @override
  String get navHome => 'Beranda';

  @override
  String get navAttendance => 'Absensi';

  @override
  String get navCasting => 'Cor';

  @override
  String get navQueue => 'Pending';

  @override
  String get navSettings => 'Pengaturan';

  @override
  String get navAttendanceSoon => 'Absensi belum aktif — segera hadir.';

  @override
  String get comingSoon => 'Segera hadir';

  @override
  String homeGreeting(String name) {
    return 'Halo, $name';
  }

  @override
  String get homeTagline =>
      'Selamat bekerja. Data tersimpan di HP walau tanpa sinyal.';

  @override
  String get homePickProject => 'Pilih proyek saya';

  @override
  String get homeAllSent => 'Semua sudah terkirim';

  @override
  String homePending(int count) {
    return '$count belum terkirim';
  }

  @override
  String get homeWatched => 'Sedang dipantau';

  @override
  String homeWatchedCount(int count) {
    return '$count catatan';
  }

  @override
  String get homeDrillRunning => 'catatan bor berjalan';

  @override
  String get homeCastRunning => 'catatan cor berjalan';

  @override
  String get labelDrill => 'Bor';

  @override
  String get labelCast => 'Cor';

  @override
  String get shortcutAttendance => 'Absen kru';

  @override
  String get shortcutAttendanceBody =>
      'Foto masuk & pulang, centang kru yang hadir';

  @override
  String get shortcutCasting => 'Catatan bor & cor';

  @override
  String get shortcutCastingBody =>
      'Catat kedalaman bor, TM, tremie & sounding per titik';

  @override
  String get shortcutWorkers => 'Pekerja';

  @override
  String get shortcutWorkersBody =>
      'Semua pekerja per proyek, daftarkan pekerja baru';

  @override
  String get shortcutReports => 'Laporan lapangan';

  @override
  String get shortcutReportsBody =>
      'Titik yang dibor & dicor hari ini, kemarin, atau seminggu';

  @override
  String get settingsLanguage => 'Bahasa';

  @override
  String get settingsLanguageBody =>
      'Bahasa tampilan app. Istilah teknis lapangan tetap sama di semua bahasa.';

  @override
  String get languageSystem => 'Ikut HP';

  @override
  String get languageIndonesian => 'Indonesia';

  @override
  String get languageEnglish => 'English';

  @override
  String get languageChinese => '中文';

  @override
  String get settingsTitle => 'Pengaturan';

  @override
  String settingsLevel(String n) {
    return 'Level $n';
  }

  @override
  String get sectionAppearance => 'Tampilan';

  @override
  String get sectionMyProject => 'Proyek saya';

  @override
  String get sectionNotifications => 'Notifikasi';

  @override
  String get sectionAccount => 'Akun';

  @override
  String get sectionAbout => 'Tentang';

  @override
  String get settingsTheme => 'Tema';

  @override
  String get themeSystem => 'Ikuti HP';

  @override
  String get themeLight => 'Terang';

  @override
  String get themeDark => 'Gelap';

  @override
  String get settingsAccent => 'Warna aksen';

  @override
  String get accentBlue => 'Biru';

  @override
  String get accentOrange => 'Jingga';

  @override
  String get accentTeal => 'Teal';

  @override
  String get accentPurple => 'Ungu';

  @override
  String get settingsTextSize => 'Ukuran teks';

  @override
  String get textSizeNormal => 'Normal';

  @override
  String get textSizeLarge => 'Besar';

  @override
  String get textSizeHuge => 'Sangat besar';

  @override
  String get myProjectBodyAttendance =>
      'Absen, pekerja baru dan catatan cor langsung memakai proyek ini. Masih bisa diganti di tiap layar.';

  @override
  String get myProjectBody =>
      'Daftar titik bor & cor langsung membuka proyek ini di urutan teratas.';

  @override
  String get myProjectSaved => 'Proyek saya disimpan.';

  @override
  String get myProjectCleared => 'Proyek saya dikosongkan.';

  @override
  String get projectsLoadFailed => 'Daftar proyek gagal dibaca';

  @override
  String get projectsMissingTitle => 'Daftar proyek belum ada di HP';

  @override
  String get projectsMissingBody =>
      'Tarik ke bawah di Beranda untuk mengambilnya dari server. Perlu sinyal sekali saja.';

  @override
  String get notifTitle => 'Pengingat getar';

  @override
  String get notifOn =>
      'Aktif. HP bergetar saat TM lebih dari 20 menit dan selama cor dijeda. Jam tangan yang sudah terhubung ke HP ikut menerima pengingat dan tombol Selesai TM — tanpa setelan tambahan di sini.';

  @override
  String get notifOff =>
      'Mati. Ketuk untuk mengizinkan; tanpa ini pengingat saat ngecor tidak muncul.';

  @override
  String get notifBlockedTitle => 'Pengingat tidak akan muncul';

  @override
  String get notifBlockedBody =>
      'HP ini belum mengizinkan TerraBot Field memunculkan notifikasi. Pengingat TM lewat 20 menit, cor yang dijeda, dan catatan bor yang belum ditutup semuanya tidak akan terdengar. Ketuk Izinkan.';

  @override
  String get notifAllow => 'Izinkan';

  @override
  String get notifAllowManual =>
      'Notifikasi masih dimatikan telepon. Buka Setelan telepon → Aplikasi → TerraBot Field → Notifikasi, lalu nyalakan.';

  @override
  String get powerTitle => 'Baterai & mulai otomatis';

  @override
  String get powerOk =>
      'Tanpa batasan. Pengingat dan kirim otomatis jalan saat layar mati.';

  @override
  String get powerRestricted =>
      'Masih dibatasi HP. Ketuk untuk mengatur, supaya pengingat cor tidak terlewat.';

  @override
  String get reloadPermissions => 'Muat ulang hak akses';

  @override
  String get reloadPermissionsBody =>
      'Setelah kantor mengubah level atau divisi Anda.';

  @override
  String get permissionsReloaded => 'Hak akses dimuat ulang.';

  @override
  String logoutPendingTitle(int docs, int photos) {
    return 'Masih ada $docs data dan $photos foto belum terkirim';
  }

  @override
  String get logoutPendingBody =>
      'Keluar TIDAK menghapusnya; terkirim begitu Anda masuk lagi. Tetapi orang lain yang masuk di HP ini tidak dapat mengirimnya.';

  @override
  String get logout => 'Keluar';

  @override
  String get logoutConfirm => 'Keluar?';

  @override
  String get logoutConfirmBody => 'Perlu sinyal untuk masuk lagi.';

  @override
  String get cancel => 'Batal';

  @override
  String get appVersion => 'Versi aplikasi';

  @override
  String serverLabel(String host) {
    return 'Server $host';
  }

  @override
  String deviceIdLabel(String id) {
    return 'ID perangkat $id';
  }

  @override
  String get sendLog => 'Kirim catatan masalah ke admin';

  @override
  String get sendLogBody =>
      'Bila aplikasi bermasalah: catatan masalah dari HP ini, tanpa data pribadi.';

  @override
  String get noLogYet => 'Belum ada catatan masalah di HP ini.';

  @override
  String logShareFailed(String error) {
    return 'Catatan masalah gagal dibagikan: $error';
  }

  @override
  String get castingTitle => 'Catatan pengecoran';

  @override
  String get projectsLoadError => 'Proyek gagal dibaca';

  @override
  String get pickProject => 'Pilih proyek';

  @override
  String get pickProjectBody => 'Titik bor diisi kantor dari gambar kerja';

  @override
  String get noCastingProjects =>
      'Belum ada proyek cor di HP. Tarik ke bawah saat ada sinyal.';

  @override
  String get myProjectTag => 'PROYEK SAYA';

  @override
  String pointCount(int n) {
    return '$n titik';
  }

  @override
  String get pointsTitle => 'Titik bor';

  @override
  String pointsTitleOf(String code) {
    return '$code · titik bor';
  }

  @override
  String get toTop => 'Ke atas';

  @override
  String get pointsLoadError => 'Titik gagal dibaca';

  @override
  String get noPointsTitle => 'Belum ada titik bor';

  @override
  String get noPointsBody =>
      'Titik bor diisi kantor (impor Excel di TerraBot web). Tarik ke bawah di halaman sebelumnya untuk mengambil yang terbaru.';

  @override
  String get searchPointCode => 'Cari kode titik';

  @override
  String get clear => 'Hapus';

  @override
  String get filterAll => 'Semua';

  @override
  String get filterUndrilled => 'Belum bor';

  @override
  String get filterDrilled => 'Dibor';

  @override
  String get filterCast => 'Dicor';

  @override
  String castProgress(int done, int total) {
    return '$done dari $total titik sudah dicor';
  }

  @override
  String get noMatchingPoints => 'Tidak ada titik yang cocok.';

  @override
  String get stageCasting => 'Sedang dicor';

  @override
  String get stageCast => 'Sudah dicor';

  @override
  String stageDrilled(String depth) {
    return 'Dibor $depth';
  }

  @override
  String get stageDrilling => 'Sedang dibor';

  @override
  String get stageUndrilled => 'Belum dibor';

  @override
  String get gsMissingShort => 'GS belum diisi';

  @override
  String pointHeading(String code) {
    return 'Titik $code';
  }

  @override
  String get fieldDiameter => 'Diameter';

  @override
  String get fieldLevels => 'GS / cut-off / tip';

  @override
  String get fieldCutOffDepth => 'Kedalaman cut-off dari GS';

  @override
  String get fieldPlannedDrill => 'Panjang bor rencana';

  @override
  String get fieldPlannedEff => 'Panjang efektif rencana';

  @override
  String get fieldPlannedVol => 'Volume beton rencana';

  @override
  String get fieldActualDrill => 'Kedalaman bor aktual';

  @override
  String get gsMissingTitle => 'Elevasi GS belum diisi';

  @override
  String get gsMissingBody =>
      'Kedalaman dari GS belum dapat dihitung, dan catatan cor baru bisa dimulai setelah GS terisi. Isi GS saat menandai titik ini sudah dibor.';

  @override
  String get notFilled => 'belum diisi';

  @override
  String get castLogExists => 'Titik ini sudah punya catatan cor';

  @override
  String get castLogOnMyOther => 'Catatan cornya ada di HP Anda yang lain';

  @override
  String get castLogElsewhere => 'Sedang dicor dari HP lain';

  @override
  String castLogHeldBody(String who) {
    return '$who yang memegang catatan cornya. Satu titik hanya boleh satu catatan cor. Bila catatan itu salah, minta kantor menghapusnya dulu.';
  }

  @override
  String get logIsMineBody =>
      'Catatan ini dipegang akun Anda sendiri, hanya isinya belum ada di HP ini. Ambil langsung ke sini tanpa kode oper.';

  @override
  String castLogHandoverBody(String who) {
    return '$who yang memegang catatan cornya. Satu titik hanya boleh satu catatan cor. Untuk melanjutkan dari HP ini, minta dia menekan \"Oper ke rekan\" lalu masukkan kodenya di sini.';
  }

  @override
  String get takeToThisPhone => 'Ambil ke HP ini';

  @override
  String get continueHereCode => 'Lanjutkan di HP ini (kode oper)';

  @override
  String get drillLogOnMyOther => 'Catatan bornya ada di HP Anda yang lain';

  @override
  String get drillLogElsewhere => 'Sedang dibor dari HP lain';

  @override
  String drillLogHandoverBody(String who) {
    return 'Catatan bornya dipegang $who. Satu titik hanya boleh satu catatan bor. Untuk melanjutkan dari HP ini, minta dia menekan \"Oper ke rekan\" lalu masukkan kodenya di sini.';
  }

  @override
  String get drillFirstTitle => 'Catat bor dulu';

  @override
  String get castAfterDrillLog =>
      'Catatan cor bisa dimulai setelah catatan bor ditutup dengan \"Selesai bor\".';

  @override
  String get castAfterDrilled =>
      'Catatan cor baru bisa dimulai setelah titik ini selesai dibor: lewat catatan bor, atau tandai langsung.';

  @override
  String get viewOnlyTitle => 'Hanya dapat dilihat';

  @override
  String get viewOnlyCastBody => 'Akun ini tidak berhak mencatat catatan cor.';

  @override
  String get continueDrillLog => 'Lanjutkan catatan bor';

  @override
  String get viewDrillLog => 'Lihat catatan bor';

  @override
  String get startDrillLog => 'Mulai catatan bor';

  @override
  String get markDrilledNoLog => 'Tandai sudah dibor (tanpa catatan)';

  @override
  String get correctDrillGs => 'Koreksi kedalaman bor / GS';

  @override
  String get openCastLog => 'Buka catatan cor';

  @override
  String get startCastLog => 'Mulai catatan cor';

  @override
  String get confirmPointCodeTitle => 'Ketik nomor titiknya';

  @override
  String get confirmPointCodeBody =>
      'Lihat tiang yang akan Anda cor, jangan daftar di HP. Nomor yang Anda ketik inilah yang menjaga catatan ini tidak masuk ke titik sebelah.';

  @override
  String get confirmPointCodeField => 'Nomor titik';

  @override
  String get confirmPointCodeConfirm => 'Benar, mulai cor';

  @override
  String confirmPointCodeMismatch(String selected, String typed) {
    return 'Di daftar Anda memilih $selected, yang Anda ketik $typed. Kalau yang benar $typed, tutup ini lalu pilih titik itu di daftar.';
  }

  @override
  String get colleague => 'Rekan';

  @override
  String markedDrilled(String code, String depth) {
    return '$code ditandai sudah dibor $depth.';
  }

  @override
  String get gsInvalid => 'Elevasi GS tidak sah.';

  @override
  String get gsRequiredMsg =>
      'Isi elevasi GS titik ini. Catatan cor tidak dapat dimulai tanpanya.';

  @override
  String get drillDepthInvalid => 'Isi kedalaman bor (m), lebih dari 0.';

  @override
  String drillDepthTooDeep(String max) {
    return 'Kedalaman paling dalam $max. Periksa angkanya.';
  }

  @override
  String markDrilledTitle(String code) {
    return 'Tandai dibor $code';
  }

  @override
  String get checkInput => 'Periksa isian';

  @override
  String get gsFieldRequired => 'Elevasi GS (m) — wajib';

  @override
  String get gsField => 'Elevasi GS (m)';

  @override
  String get cutOffAboveGsTitle => 'Cut-off di atas GS';

  @override
  String cutOffAboveGsBody(String col) {
    return 'COL $col lebih tinggi dari GS ini. Pastikan angka GS benar sebelum menyimpan.';
  }

  @override
  String get drillDepthField => 'Kedalaman bor (m)';

  @override
  String beyondPlanTitle(String over) {
    return 'Sudah lewat $over dari rencana';
  }

  @override
  String beyondPlanBody(String planned) {
    return 'Rencana $planned. Lewat sedikit boleh; pastikan memang perlu dibor lebih dalam.';
  }

  @override
  String get save => 'Simpan';

  @override
  String get drillLogWord => 'catatan bor';

  @override
  String get castLogWord => 'catatan cor';

  @override
  String sendingFirst(String log) {
    return 'Mengirim $log dulu…';
  }

  @override
  String get sendBeforeHandoverTitle => 'Kirim dulu sebelum oper';

  @override
  String sendBeforeHandoverBody(String log) {
    return 'Isi $log ini belum sampai ke server, jadi belum bisa dioper. Cari sinyal sebentar, lalu coba lagi — rekan menerima persis isi terakhir.';
  }

  @override
  String get understood => 'Mengerti';

  @override
  String get askingCode => 'Meminta kode oper…';

  @override
  String handoverTitle(String log, String code) {
    return 'Oper $log $code';
  }

  @override
  String handoverBody(String code) {
    return 'Minta rekan membuka titik $code di HP-nya dan memilih \"Lanjutkan di HP ini\", lalu sebutkan kode ini:';
  }

  @override
  String codeValidFor(int minutes) {
    return 'Berlaku $minutes menit, sekali pakai';
  }

  @override
  String get codeValidBody =>
      'Begitu rekan memasukkannya, catatan pindah ke dia dan HP ini hanya bisa melihat. Foto yang diambil di HP ini tetap terkirim dari sini.';

  @override
  String get done => 'Selesai';

  @override
  String takeLogHere(String log, String code) {
    return 'Ambil $log $code ke HP ini';
  }

  @override
  String takeLogHereBody(String log) {
    return '$log ini memang dipegang akun Anda, hanya isinya belum ada di HP ini. Tidak perlu kode oper.\n\nBila catatan ini sedang terbuka di HP Anda yang lain, lanjutkan di SATU HP saja supaya isiannya tidak bertabrakan.';
  }

  @override
  String takingLog(String log) {
    return 'Mengambil $log…';
  }

  @override
  String logNowHere(String log, String code) {
    return '$log $code sekarang dipegang HP ini.';
  }

  @override
  String continueLog(String log, String code) {
    return 'Lanjutkan $log $code';
  }

  @override
  String get enterHandoverCode =>
      'Masukkan kode oper 6 angka yang disebutkan pemegang catatannya (dia menekan \"Oper ke rekan\" di HP-nya).';

  @override
  String get takeOver => 'Ambil alih';

  @override
  String get castLogNotOnPhone => 'Catatan cor tidak ditemukan di HP ini.';

  @override
  String get pointNotOnPhone =>
      'Titik bor tidak ada di HP ini. Tarik data terbaru saat ada sinyal.';

  @override
  String gsMissingFor(String code) {
    return 'Elevasi GS titik $code belum diisi. Kembali ke daftar titik, pilih \"Tandai sudah dibor\", lalu isi GS-nya.';
  }

  @override
  String pointHasCastLog(String code, String by) {
    return 'Titik $code sudah punya catatan cor$by. Satu titik hanya boleh satu catatan cor.';
  }

  @override
  String byWhom(String who) {
    return ' dari $who';
  }

  @override
  String pointNotDrilled(String code) {
    return 'Titik $code belum ditandai sudah dibor. Kembali ke daftar titik, pilih \"Tandai sudah dibor\", lalu isi kedalamannya.';
  }

  @override
  String get notSignedIn => 'Belum masuk akun — tidak ada yang tersimpan.';

  @override
  String get lockedByOffice =>
      'Catatan cor sudah diperiksa kantor — tidak dapat diubah lagi.';

  @override
  String heldByOther(String who) {
    return 'Catatan cor ini dipegang $who — ubah dari HP pemegangnya.';
  }

  @override
  String get tremieTooLongTitle => 'Tremie kepanjangan';

  @override
  String tremieTooLongAdd(String len, String stick, String max, String need) {
    return 'Dengan pipa $len m ini, ujung atas tremie $stick di atas GS (paling tinggi $max, setinggi hopper). Lubang ini cukup $need tremie. Periksa lagi pipa yang terpasang.';
  }

  @override
  String get tremieBottomTitle => 'Tremie bottom';

  @override
  String get lengthM => 'Panjang (m)';

  @override
  String get tremieBottomHint =>
      'Ujung runcing yang dipasang paling bawah. Ukur panjangnya untuk cor ini.';

  @override
  String get topSegmentRemoved =>
      'Pipa tremie paling atas dihapus dari susunan.';

  @override
  String get segmentLength => 'Panjang pipa tremie';

  @override
  String get dontPullYet => 'Jangan dicabut dulu';

  @override
  String get embedTooShortTitle => 'Tremie kurang tertanam';

  @override
  String embedAfterRemoval(String len, String after, String min) {
    return 'Setelah pipa $len m ini dicabut, tremie tinggal tertanam $after di beton (paling sedikit $min). Beton baru bisa menembus muka beton dan bercampur lumpur.';
  }

  @override
  String estimateSoundFirst(String text) {
    return '$text\n\nMuka beton ini perkiraan. Sounding dulu kalau ragu.';
  }

  @override
  String get tickAnyway => 'Tetap centang';

  @override
  String get pullUndone => 'Cabut dibatalkan; pipa tremienya terpasang lagi.';

  @override
  String get pullTickTitle => 'Tandai tremie tercabut?';

  @override
  String pullTickBody(int pos, String panjang, int seq, String sisa) {
    return 'Pipa #$pos ($panjang m) akan tercatat dicabut setelah TM #$seq, dan tremie tertanam menjadi $sisa. Catatan ini masuk Piling Record sebagai bukti.';
  }

  @override
  String pullTickAfterPour(int seq) {
    return 'TM #$seq sudah selesai dituang. Kalau tremienya tidak benar-benar dicabut, jangan ditandai.';
  }

  @override
  String pullRecorded(int seq) {
    return 'Pipa tremie tercatat dicabut setelah TM #$seq.';
  }

  @override
  String truckSaved(int seq) {
    return 'TM #$seq tersimpan.';
  }

  @override
  String truckUpdated(int seq) {
    return 'TM #$seq diperbarui.';
  }

  @override
  String get atCutOffTitle => 'Beton sudah sampai cut-off';

  @override
  String atCutOffBody(String level, String cutoff, String over) {
    return 'Muka beton $level dari GS, cut-off $cutoff$over. Biasanya cor titik ini sudah cukup.';
  }

  @override
  String overBy(String over) {
    return ' (lebih $over)';
  }

  @override
  String get estimateFromVolume =>
      'Angka ini perkiraan dari volume. Sounding dulu untuk memastikan.';

  @override
  String get finishCasting => 'Selesai cor';

  @override
  String get addTruckAnyway => 'Tetap tambah TM';

  @override
  String soundingAfter(String seq) {
    return 'Sounding setelah TM #$seq';
  }

  @override
  String soundingBefore(String seq) {
    return 'Sounding sebelum TM #$seq';
  }

  @override
  String get soundingQuestion =>
      'Dari muka tanah turun ke muka beton, berapa meter?';

  @override
  String get concreteDepthField => 'Dari muka tanah ke muka beton';

  @override
  String soundingHint(String est) {
    return 'Wajib diukur. Perkiraan dari volume: $est.';
  }

  @override
  String soundingMissing(int seq) {
    return 'Sounding TM #$seq belum diisi. Wajib sebelum TM berikutnya.';
  }

  @override
  String truckStartTime(String seq) {
    return 'Jam mulai TM #$seq';
  }

  @override
  String truckEndTime(String seq) {
    return 'Jam selesai TM #$seq';
  }

  @override
  String soundingCleared(String seq) {
    return 'Sounding TM #$seq dikosongkan.';
  }

  @override
  String soundingSaved(String seq, String value) {
    return 'Sounding TM #$seq tersimpan: $value.';
  }

  @override
  String get tremieNotAtBottom => 'Tremie belum sampai dasar';

  @override
  String tremieTooLongNow(
    String fitted,
    String stick,
    String max,
    String need,
  ) {
    return 'Terpasang $fitted, ujung atasnya $stick di atas GS (paling tinggi $max). Lubang ini cukup $need. Hapus pipa yang berlebih dulu.';
  }

  @override
  String tremieShortBody(String fitted, String need) {
    return 'Terpasang $fitted, perlu $need (dasar lubang dikurangi celah). Tambah pipa tremie dulu: beton yang jatuh dari atas akan bercampur lumpur.';
  }

  @override
  String notifPouring(String seq) {
    return 'Mengecor TM #$seq';
  }

  @override
  String notifTapToOpen(String vol) {
    return '$vol m³ · ketuk untuk membuka catatan cor';
  }

  @override
  String pourStarted(String seq) {
    return 'Cor TM #$seq dimulai. Jamnya berjalan di notifikasi.';
  }

  @override
  String notifTruckLate(String seq, int min, String code) {
    return 'TM #$seq sudah $min menit · $code';
  }

  @override
  String get notifTruckLateBody =>
      'Belum selesai dicor. Cek muka beton dan posisi tremie.';

  @override
  String notifPausedTitle(int seq) {
    return 'TM #$seq dijeda';
  }

  @override
  String notifPausedBody(String reason) {
    return '$reason · ketuk untuk melanjutkan';
  }

  @override
  String notifStillPaused(int seq, String code) {
    return 'TM #$seq masih dijeda · $code';
  }

  @override
  String get notifStillPausedBody =>
      'Sudah lanjut cor? Ketuk Lanjut di catatan cor';

  @override
  String pourPaused(String reason) {
    return 'Cor dijeda: $reason.';
  }

  @override
  String pourResumed(int seq) {
    return 'Cor TM #$seq dilanjutkan.';
  }

  @override
  String notifNoNextTruck(String code) {
    return 'Belum ada TM berikutnya · $code';
  }

  @override
  String get notifNoNextTruckBody =>
      'Awas sambungan dingin. Cek kapan TM datang';

  @override
  String truckFinished(int seq) {
    return 'TM #$seq selesai dicor.';
  }

  @override
  String get castDataSaved => 'Data cor disimpan.';

  @override
  String get finishNotStored =>
      'Status selesai belum tersimpan. Coba tekan \"Selesai cor\" sekali lagi.';

  @override
  String castFinished(String code) {
    return 'Cor $code selesai. Terkirim otomatis saat ada sinyal.';
  }

  @override
  String get castReopened =>
      'Catatan cor dibuka lagi. Jangan lupa Selesai cor setelah beres.';

  @override
  String get cleanTremieTitle => 'Bersihkan tremie & hopper';

  @override
  String get beforeNextUse => 'Sebelum dipakai lagi';

  @override
  String get cleanWhy =>
      'Sisa beton yang mengeras di dalam pipa atau sambungan bisa menyumbat tremie saat cor berikutnya.';

  @override
  String get cleanStep1 =>
      'Siram/semprot hopper dan tiap pipa tremie sampai bersih dari sisa beton.';

  @override
  String get cleanStep2 =>
      'Bersihkan sambungan dan karet seal; ganti seal yang rusak.';

  @override
  String get cleanStep3 => 'Lakukan segera, sebelum sisa beton mengeras.';

  @override
  String get cleanStep4 =>
      'Susun kembali di tempatnya, jangan tergeletak di tanah.';

  @override
  String get cleanedOk => 'Siap, dibersihkan';

  @override
  String castOf(String code) {
    return 'Cor $code';
  }

  @override
  String get handOverToMate => 'Oper ke rekan';

  @override
  String handedOverTo(String who) {
    return 'Dioper ke $who';
  }

  @override
  String handedOverBody(String who) {
    return 'Catatan cor ini dilanjutkan dari HP $who. Di HP ini hanya bisa dilihat; perubahan dibuat di HP pemegangnya.';
  }

  @override
  String get rejectedByServer => 'Ditolak server';

  @override
  String get reviewedByOffice => 'Sudah diperiksa kantor';

  @override
  String officeNote(String note) {
    return 'Catatan: $note';
  }

  @override
  String get cannotChangeAnymore => 'Catatan cor ini tidak dapat diubah lagi.';

  @override
  String get gradeMissingTitle => 'Mutu beton belum diisi';

  @override
  String get gradeMissingBody =>
      'Titik dan proyek ini belum punya mutu bawaan. Isi di data cor, atau catatan cor akan ditolak server.';

  @override
  String get finishNeedsGrade => 'Isi mutu dulu';

  @override
  String get fill => 'Isi';

  @override
  String get drillDepthUnmarked => 'Kedalaman bor belum ditandai';

  @override
  String get drillDepthUnmarkedBody =>
      'Hitungan memakai panjang bor RENCANA. Tandai kedalaman aktual dari daftar titik supaya saran potong tepat.';

  @override
  String get tremieSection => 'Tremie';

  @override
  String tremieSectionBody(String gap) {
    return 'Pipa bawah → atas. Ujung bawah $gap di atas dasar lubang.';
  }

  @override
  String get trucksSection => 'Truk mixer (TM)';

  @override
  String trucksSectionBody(int n, String vol) {
    return '$n TM · $vol m³';
  }

  @override
  String get noTrucksYet => 'Belum ada TM';

  @override
  String get noTrucksReadOnly => 'Catatan cor ini tidak punya TM.';

  @override
  String get noTrucksTremieFirst =>
      'Susun tremie dulu, lalu tekan \"TM #1 datang\" saat truk pertama tiba.';

  @override
  String get noTrucksTapArrived =>
      'Tekan \"TM #1 datang\" di bawah saat truk pertama tiba.';

  @override
  String get pause => 'Jeda';

  @override
  String get resume => 'Lanjut';

  @override
  String finishTruck(String seq) {
    return 'Selesai TM #$seq';
  }

  @override
  String startTruck(String seq) {
    return 'Mulai cor TM #$seq';
  }

  @override
  String get tremieFirst => 'Susun tremie dulu';

  @override
  String truckArrived(int seq) {
    return 'TM #$seq datang';
  }

  @override
  String get castDone => 'Cor selesai';

  @override
  String get savedAutoSend => 'Tersimpan. Dikirim otomatis.';

  @override
  String get reopen => 'Buka lagi';

  @override
  String planNoPull(int seq) {
    return 'Rencana TM #$seq: tidak perlu cabut';
  }

  @override
  String planTitle(int seq) {
    return 'Rencana TM #$seq';
  }

  @override
  String planCutLine(String vol, String which, String before, String after) {
    return '• Setelah ±$vol m³: cabut $which → tremie tertanam $before → $after m';
  }

  @override
  String get joinThen => ' lalu ';

  @override
  String warnEmbedShort(String emb) {
    return '⚠ Tremie tertanam sebelum TM ini hanya $emb m — periksa sounding.';
  }

  @override
  String warnNoSafePull(String vol) {
    return '⚠ Setelah ±$vol m³ tremie tertanam lebih dari 6 m dan tidak ada pipa yang aman dicabut.';
  }

  @override
  String planEnd(String level, String emb, String cut) {
    return 'Perkiraan akhir TM: muka beton $level, tremie tertanam $emb$cut.';
  }

  @override
  String get cutOffReachedSuffix => ' — cut-off tercapai';

  @override
  String usingOverbreak(String ratio) {
    return 'Memakai angka pelebaran lubang $ratio dari sounding TM sebelumnya.';
  }

  @override
  String embedTitle(String emb, String est) {
    return 'Tremie tertanam $emb$est';
  }

  @override
  String get estimateSuffix => ' (perkiraan)';

  @override
  String get notSoundedYet =>
      'Muka beton belum disounding — angka ini dari volume. Sounding dulu sebelum mencabut.';

  @override
  String get dontPullUnderOne =>
      'Kurang dari 1 m: JANGAN cabut. Tremie berisiko keluar dari beton.';

  @override
  String get noPullNeeded => 'Tidak perlu cabut sekarang.';

  @override
  String pullSuggestion(String which, String after) {
    return 'Saran: cabut $which → tertanam $after. Centang di daftar tremie setelah dicabut.';
  }

  @override
  String get tick => 'Centang';

  @override
  String get cellGrade => 'Mutu beton';

  @override
  String get cellSupplier => 'Pemasok';

  @override
  String get cellHoleBottom => 'Dasar lubang';

  @override
  String get cellCutOff => 'Cut-off';

  @override
  String get cellConcreteLevel => 'Muka beton';

  @override
  String get cellTheoretical => 'Seharusnya';

  @override
  String get cellUsed => 'Terpakai';

  @override
  String get cellOveruse => 'Lebih pakai';

  @override
  String get estimatedFootnote => '* perkiraan dari volume';

  @override
  String tremieNeedFrom(String need) {
    return 'Perlu $need. Mulai dari tremie bottom (ujung runcing).';
  }

  @override
  String tremieOverLong(String stick, String max) {
    return 'Kepanjangan: ujung atas $stick di atas GS (paling tinggi $max). Hapus pipa paling atas.';
  }

  @override
  String tremieAtBottom(String stick) {
    return 'Sudah sampai dasar. Ujung atas $stick di atas GS (hopper).';
  }

  @override
  String tremieShortBy(String missing) {
    return 'Kurang $missing lagi sampai dasar.';
  }

  @override
  String ofNeeded(String need) {
    return 'dari $need perlu';
  }

  @override
  String get fitBottomPiece => 'Pasang tremie bottom';

  @override
  String get other => 'Lainnya';

  @override
  String get removeTop => 'Hapus teratas';

  @override
  String get pullTremieTitle => 'Cabut tremie';

  @override
  String get pullTremieBody =>
      'Tekan \"Cabut\" pada pipa yang dicabut setelah TM ini. Gambar di atas ikut berubah.';

  @override
  String tremieBottomOf(String len) {
    return 'Tremie bottom · $len m';
  }

  @override
  String pipeOf(String len) {
    return 'Pipa $len m';
  }

  @override
  String pulledAfterTruck(String seq) {
    return 'Dicabut setelah TM #$seq';
  }

  @override
  String get lowest => 'paling bawah';

  @override
  String get pull => 'Cabut';

  @override
  String truckHeading(int seq, String vol) {
    return 'TM #$seq · $vol m³';
  }

  @override
  String hullNo(String no) {
    return 'Lambung $no';
  }

  @override
  String ticketNo(String no) {
    return 'SJ $no';
  }

  @override
  String slumpOf(String cm) {
    return 'Slump $cm cm';
  }

  @override
  String get tremieFitted => 'Tremie terpasang';

  @override
  String get start => 'Mulai';

  @override
  String get finish => 'Selesai';

  @override
  String pausesCount(int n, String total) {
    return '$n× · $total';
  }

  @override
  String pauseLine(String reason, String from, String to) {
    return '$reason · $from–$to';
  }

  @override
  String get now => 'sekarang';

  @override
  String get soundingBeforeLabel => 'Sounding sebelum';

  @override
  String get soundingAfterLabel => 'Sounding sesudah';

  @override
  String get soundingAfterRequired =>
      'Sounding sesudah wajib diisi. Ketuk baris di atas.';

  @override
  String get overbreakRatio => 'Lubang lebih besar';

  @override
  String get deliveryNote => 'Surat jalan';

  @override
  String get slumpTest => 'Uji slump';

  @override
  String get pausedLabel => 'Dijeda';

  @override
  String overMinutes(int min) {
    return 'Lewat $min menit';
  }

  @override
  String get pourTime => 'Waktu tuang';

  @override
  String pauseTruckTitle(int seq) {
    return 'Jeda TM #$seq';
  }

  @override
  String get pauseTruckBody =>
      'Kenapa dijeda? Jam tuang berhenti, dan HP bergetar tiap 3 menit sampai Anda ketuk Lanjut.';

  @override
  String volumeInvalid(String max) {
    return 'Isi volume TM (m³), paling besar $max.';
  }

  @override
  String volumeUnusual(String vol) {
    return '$vol m³ lebih besar dari biasanya (5–7 m³). Cek surat jalannya; kalau benar, tekan Simpan TM sekali lagi.';
  }

  @override
  String get slumpInvalid => 'Slump tidak masuk akal (0–40 cm).';

  @override
  String editTruck(int seq) {
    return 'Ubah TM #$seq';
  }

  @override
  String get photoTicket => 'Foto surat jalan TM';

  @override
  String get photoSlump => 'Foto uji slump';

  @override
  String get hullNoField => 'Nomor lambung TM';

  @override
  String get truckSupplier => 'Pemasok beton TM ini';

  @override
  String get otherTypeName => 'Lainnya — ketik nama';

  @override
  String get otherSupplierName => 'Nama pemasok lain';

  @override
  String get volumeField => 'Volume';

  @override
  String get slumpField => 'Slump hasil uji';

  @override
  String get soundingBeforeOptional => 'Sounding sebelum (opsional)';

  @override
  String estimateHint(String value) {
    return 'perkiraan $value';
  }

  @override
  String get saveChanges => 'Simpan perubahan';

  @override
  String get saveTruck => 'Simpan TM';

  @override
  String get castDataTitle => 'Data cor';

  @override
  String defaultGrade(String grade) {
    return 'Mutu bawaan $grade MPa';
  }

  @override
  String get defaultGradeBody =>
      'Dari titik/proyek. Isi hanya bila beton yang datang berbeda.';

  @override
  String get suppliersWithPo => 'Pemasok dengan PO beton di proyek ini';

  @override
  String get noPoYet => 'Belum ada PO beton di proyek ini';

  @override
  String get suppliersWithPoBody =>
      'Jadi isian awal tiap TM; tiap TM datang masih bisa memilih pemasoknya sendiri. Tidak ada di daftar? Pilih \"Lainnya\" lalu ketik namanya, dan kabari kantor.';

  @override
  String get noPoYetBody =>
      'Menampilkan semua pemasok beton; daftar menyempit sendiri setelah kantor membuat PO. Tiap TM datang masih bisa memilih pemasoknya sendiri.';

  @override
  String get noteField => 'Keterangan';

  @override
  String hangAboveGs(String top, String bottom) {
    return '$top–$bottom m di atas GS';
  }

  @override
  String hangAcrossGs(String top, String bottom) {
    return '$top m di atas GS sampai kedalaman $bottom m';
  }

  @override
  String hangDepth(String top, String bottom) {
    return 'kedalaman $top–$bottom m';
  }

  @override
  String get stopTremieBlocked => 'Tremie tersumbat / beton macet';

  @override
  String get stopNoTruck => 'TM tidak datang / beton habis';

  @override
  String get stopHoleCollapse => 'Lubang runtuh';

  @override
  String get stopPlantWeather => 'Alat rusak atau cuaca';

  @override
  String labelDetail(String label, String detail) {
    return '$label — $detail';
  }

  @override
  String stoppedBeforeCutOff(String missing, String vol, String why) {
    return 'Cor dihentikan sebelum cut-off (kurang $missing ≈ $vol m³): $why';
  }

  @override
  String get belowCutOffTitle => 'Beton belum sampai cut-off';

  @override
  String finishCastingOf(String code) {
    return 'Selesai cor $code?';
  }

  @override
  String shortfallTitle(String vol, int trucks) {
    return 'Masih kurang $vol m³ (±$trucks TM lagi)';
  }

  @override
  String shortfallLine1(String level, String cutoff, String missing) {
    return 'Muka beton $level dari GS, cut-off $cutoff — kurang $missing.';
  }

  @override
  String shortfallLine2(String poured, String theoretical, String percent) {
    return 'Sudah tercor $poured m³ dari ±$theoretical m³ yang seharusnya$percent.';
  }

  @override
  String percentSuffix(String percent) {
    return ' ($percent%)';
  }

  @override
  String get estimateSoundToBeSure =>
      'Angka ini perkiraan dari volume — sounding dulu untuk memastikan.';

  @override
  String get shortPileWarning =>
      'Tiang yang ditutup di bawah cut-off jadi tiang pendek, dan beton mengeras — tidak bisa dibatalkan. Kalau cor memang dihentikan, pilih alasannya; kantor perlu tahu. Kalau cuma salah tekan, pilih \"Belum — lanjut cor\".';

  @override
  String get reasonRequired => 'Alasan (wajib)';

  @override
  String get detailOptional => 'Keterangan (boleh kosong)';

  @override
  String get reasonHint =>
      'mis. tremie mampet di pipa ke-3, beton sudah mengeras';

  @override
  String get shortABitBody =>
      'Kurang sedikit saja dari cut-off — kelebihan di atas cut-off memang dipotong nanti. Titik ditandai sudah dicor; catatan cor masih dapat diperbaiki sampai diperiksa kantor.';

  @override
  String get finishedBody =>
      'Titik ditandai sudah dicor. Catatan cor masih dapat diperbaiki sampai diperiksa kantor.';

  @override
  String get finishAnyway => 'Tetap selesai';

  @override
  String get notYetKeepPouring => 'Belum — lanjut cor';

  @override
  String get notYet => 'Belum';

  @override
  String get castLogTitle => 'Catatan cor';

  @override
  String overuseTitle(String percent) {
    return 'Beton terpakai $percent% di atas teoretis';
  }

  @override
  String overuseBody(String level, String used, String theoretical) {
    return 'Sampai muka beton $level: terpakai $used m³, teoretis $theoretical m³. Kemungkinan lubang membesar atau runtuh. Laporkan ke pengawas.';
  }

  @override
  String get gapInvalid => 'Celah bawah tremie 0–5 m.';

  @override
  String get reasonTidakValid => 'Isi data tidak sah';

  @override
  String get reasonTidakBerhak => 'Akun Anda tidak berhak menyimpan data ini';

  @override
  String get reasonBukanMilik => 'Data ini milik pengguna lain';

  @override
  String get reasonDioper =>
      'Catatan ini sudah dioper ke rekan — perubahan hanya dari HP pemegangnya';

  @override
  String get reasonSudahDihapus => 'Data ini sudah dihapus di kantor';

  @override
  String get reasonSudahDitinjau =>
      'Absen sudah ditinjau kantor — tidak dapat diubah lagi';

  @override
  String get reasonSudahDiperiksa =>
      'Catatan cor sudah diperiksa kantor — tidak dapat diubah lagi';

  @override
  String get reasonSudahDicor => 'Titik ini sudah tercatat dicor';

  @override
  String get reasonProyekTidakAda =>
      'Proyek tidak ditemukan atau sudah ditutup';

  @override
  String get reasonProyekTanggalTetap =>
      'Proyek dan tanggal absen tidak dapat diganti setelah terkirim';

  @override
  String get reasonTanggalDepan =>
      'Tanggal absen di masa depan — periksa jam HP';

  @override
  String get reasonAbsenSudahAda =>
      'Sudah ada absen Anda untuk proyek dan tanggal ini';

  @override
  String get reasonWorkerBelumAda =>
      'Menunggu data pekerja baru terkirim lebih dulu';

  @override
  String get reasonPekerjaDihapus => 'Ada pekerja yang sudah dihapus di kantor';

  @override
  String get reasonPekerjaBukanKru => 'Ada pekerja yang bukan kru Anda';

  @override
  String get reasonPekerjaGanda => 'Ada pekerja tercatat dua kali';

  @override
  String get reasonUuidBentrok =>
      'Data bentrok dengan data lain — hubungi admin';

  @override
  String get reasonTitikTidakAda =>
      'Titik bor tidak ditemukan atau sudah dihapus';

  @override
  String get reasonTitikTetap => 'Titik catatan cor tidak dapat diganti';

  @override
  String get reasonCorSudahAda =>
      'Titik ini sudah punya catatan cor dari HP lain';

  @override
  String get reasonMutuKosong =>
      'Mutu beton belum diisi — isi di catatan cor, atau minta kantor mengisinya di titik/proyek';

  @override
  String get reasonPemasokTidakAda => 'Pemasok beton tidak ditemukan';

  @override
  String get reasonTmGanda => 'Nomor urut TM ganda';

  @override
  String get reasonJamTmTerbalik => 'Jam selesai TM lebih awal dari jam mulai';

  @override
  String get reasonSegmenGanda => 'Posisi pipa tremie ganda';

  @override
  String get reasonSegmenTmAsing =>
      'Pipa tremie dicabut setelah TM yang tidak ada';

  @override
  String get reasonGsKosong =>
      'Elevasi GS titik ini belum diisi — isi saat menandai titik dibor';

  @override
  String get reasonJedaTmAsing => 'Ada jeda untuk TM yang tidak ada';

  @override
  String get reasonJamJedaTerbalik =>
      'Jam jeda tidak masuk akal — periksa jam HP';

  @override
  String get reasonTremieBottomSalah =>
      'Tremie bottom harus paling bawah, hanya satu, dan tidak dicabut';

  @override
  String get reasonSoundingKosong =>
      'Sounding sesudah TM belum diisi — wajib sebelum selesai cor';

  @override
  String get reasonLogBorSudahAda =>
      'Titik ini sudah punya catatan bor dari HP lain';

  @override
  String get reasonKedalamanMundur =>
      'Ada bacaan bor yang lebih dangkal dari bacaan sebelumnya';

  @override
  String get reasonBorKosong =>
      'Catatan bor belum punya satu pun bacaan kedalaman';

  @override
  String get reasonEntriGanda => 'Ada bacaan bor tercatat dua kali';

  @override
  String get reasonBerkasHilang => 'Berkas foto hilang dari HP';

  @override
  String reasonWithDetail(String reason, String detail) {
    return '$reason ($detail)';
  }

  @override
  String get entityWorker => 'Pekerja';

  @override
  String get entityAttendance => 'Absen';

  @override
  String get entityDrillMark => 'Tanda bor';

  @override
  String get entityDrillLog => 'Catatan bor';

  @override
  String get entityCasting => 'Catatan cor';

  @override
  String get pauseCabutTremie => 'Cabut tremie';

  @override
  String get pauseTungguTm => 'Tunggu TM';

  @override
  String get pauseKendalaAlat => 'Kendala alat';

  @override
  String get drillLogNotOnPhone => 'Catatan bor tidak ditemukan di HP ini.';

  @override
  String get pointNotFoundPull =>
      'Titik bor tidak ditemukan. Tarik data terbaru dulu.';

  @override
  String pointHasDrillLog(String code, String by) {
    return 'Titik $code sudah punya catatan bor$by. Satu titik hanya boleh satu catatan bor.';
  }

  @override
  String pointAlreadyCast(String code) {
    return 'Titik $code sudah dicor.';
  }

  @override
  String drillHeldByOther(String who) {
    return 'Catatan bor ini dipegang $who — ubah dari HP pemegangnya.';
  }

  @override
  String get operatorSaved => 'Operator bor disimpan.';

  @override
  String get readingDeleted => 'Bacaan dihapus.';

  @override
  String readingRecorded(String depth, String time) {
    return 'Tercatat $depth jam $time.';
  }

  @override
  String get drillFinishNotStored =>
      'Status selesai belum tersimpan. Coba tekan \"Selesai bor\" sekali lagi.';

  @override
  String drillFinished(String code, String depth) {
    return '$code selesai dibor $depth.';
  }

  @override
  String get drillReopened => 'Catatan bor dibuka lagi.';

  @override
  String drillOf(String code) {
    return 'Bor $code';
  }

  @override
  String drillHandedOverBody(String who) {
    return 'Catatan bor ini dilanjutkan dari HP $who. Di HP ini hanya bisa dilihat; perubahan dibuat di HP pemegangnya.';
  }

  @override
  String drilledToDepth(String depth) {
    return 'Selesai dibor $depth';
  }

  @override
  String get drilledBodyOk =>
      'Titik ini sudah ditandai dibor; catatan cor bisa dimulai.';

  @override
  String get readingsSection => 'Bacaan';

  @override
  String readingsCount(int n) {
    return '$n kali';
  }

  @override
  String get noReadingsYet =>
      'Belum ada bacaan. Tekan \"Catat kedalaman\" setiap kali kedalaman dibaca.';

  @override
  String get finishDrilling => 'Selesai bor';

  @override
  String get recordDepth => 'Catat kedalaman';

  @override
  String get drillOperatorLabel => 'OPERATOR BOR';

  @override
  String get notPicked => 'Belum dipilih';

  @override
  String get pick => 'Pilih';

  @override
  String get change => 'Ganti';

  @override
  String get finalDepthLabel => 'KEDALAMAN AKHIR';

  @override
  String get currentDepthLabel => 'KEDALAMAN SEKARANG';

  @override
  String get planNotComputable => 'rencana belum bisa dihitung';

  @override
  String ofPlanned(String planned) {
    return 'dari $planned rencana';
  }

  @override
  String startedAt(String time) {
    return 'mulai $time';
  }

  @override
  String runningFor(String duration) {
    return 'sudah $duration';
  }

  @override
  String deeperThanPlan(String over) {
    return '$over lebih dalam dari rencana.';
  }

  @override
  String hoursMinutes(int h, int m) {
    return '$h j $m m';
  }

  @override
  String minutesOnly(int m) {
    return '$m menit';
  }

  @override
  String depthGain(String gain, String duration) {
    return '+$gain dalam $duration';
  }

  @override
  String get readingTime => 'Jam bacaan';

  @override
  String get depthInvalid => 'Isi kedalaman (m), lebih dari 0.';

  @override
  String get timeInFuture => 'Jamnya di masa depan. Periksa jam bacaan.';

  @override
  String get editReading => 'Ubah bacaan';

  @override
  String lastReadingWas(String depth, String time) {
    return 'Bacaan terakhir $depth jam $time';
  }

  @override
  String plannedIs(String planned) {
    return 'rencana $planned';
  }

  @override
  String get editTime => 'Ubah jam';

  @override
  String get depthFromGs => 'Kedalaman dari GS';

  @override
  String get noteOptional => 'Catatan (boleh kosong)';

  @override
  String get drillNoteHint => 'mis. ketemu batu, ganti mata bor';

  @override
  String get deleteThisReading => 'Hapus bacaan ini';

  @override
  String finishDrillingOf(String code) {
    return 'Selesai bor $code?';
  }

  @override
  String finishDrillBody(String depth) {
    return 'Kedalaman akhir $depth (bacaan terdalam). Titik ditandai sudah dibor dan catatan cor bisa dimulai.';
  }

  @override
  String shallowerThanPlan(String short) {
    return 'Masih $short lebih dangkal dari rencana';
  }

  @override
  String shallowerBody(String planned) {
    return 'Rencana $planned. Pastikan memang berhenti di sini.';
  }

  @override
  String get operatorNameRequired => 'Isi nama operator.';

  @override
  String operatorExists(String name) {
    return 'Sudah ada \"$name\". Pilih dari daftar bila orangnya sama, atau tekan Simpan sekali lagi bila memang orang lain.';
  }

  @override
  String get drillOperator => 'Operator bor';

  @override
  String get newOperator => 'Operator baru';

  @override
  String get checkFirst => 'Periksa dulu';

  @override
  String get operatorName => 'Nama operator';

  @override
  String get phoneOptional => 'No. HP (boleh kosong)';

  @override
  String get backToList => 'Kembali ke daftar';

  @override
  String get searchName => 'Cari nama';

  @override
  String get noMatchAddNew => 'Belum ada yang cocok. Tambahkan operator baru.';

  @override
  String get queueTitle => 'Belum terkirim';

  @override
  String get queueLoadError => 'Daftar yang belum terkirim gagal dibaca';

  @override
  String get lastSendFailed => 'Kiriman terakhir gagal';

  @override
  String queueCount(int docs, int photos) {
    return '$docs data · $photos foto';
  }

  @override
  String get notSentSinceOpen => 'Belum dikirim sejak aplikasi dibuka';

  @override
  String lastTriedAt(String time) {
    return 'Terakhir dicoba pukul $time';
  }

  @override
  String get allSent => 'Semua sudah terkirim.';

  @override
  String get photosSection => 'Foto';

  @override
  String photoLine(String kind, String kb, String time) {
    return '$kind · $kb kB · $time';
  }

  @override
  String get photoFace => 'Wajah pekerja';

  @override
  String get photoCheckIn => 'Absen masuk';

  @override
  String get photoCheckOut => 'Absen pulang';

  @override
  String get photoTicketKind => 'Surat jalan TM';

  @override
  String get photoSlumpKind => 'Uji slump TM';

  @override
  String changedAt(String time, String id) {
    return 'Diubah $time · $id';
  }

  @override
  String retryAt(String time) {
    return 'Dicoba lagi pukul $time';
  }

  @override
  String get discardTitle => 'Buang dari HP?';

  @override
  String get discardBody =>
      'Data ini tidak akan dikirim lagi. Tidak dapat dibatalkan.';

  @override
  String get discard => 'Buang';

  @override
  String get unsavedTitle => 'Tinggalkan tanpa menyimpan?';

  @override
  String get unsavedBody =>
      'Ada isian di lembar ini yang belum tersimpan, termasuk foto yang baru diambil. Foto yang dibuang tidak akan menempel ke TM ini.';

  @override
  String get discarded => 'Dibuang dari HP.';

  @override
  String get queuedResend => 'Dicoba kirim ulang sekarang.';

  @override
  String get resend => 'Kirim ulang';

  @override
  String get fillEmailPassword => 'Isi email dan kata sandi.';

  @override
  String get loginNeedsSignal =>
      'Masuk perlu sinyal. Sesudah masuk sekali, aplikasi dapat dipakai tanpa sinyal.';

  @override
  String get accountOnOtherPhone => 'Akun ini masih dipakai di HP lain';

  @override
  String oneAccountOnePhone(String last) {
    return 'Satu akun hanya boleh dipakai di satu HP, supaya catatan lapangan tidak bercabang.$last';
  }

  @override
  String lastActiveSuffix(String when) {
    return ' HP itu terakhir aktif $when.';
  }

  @override
  String get oldPhoneKeepsData => 'Data di HP lama tidak hilang';

  @override
  String get oldPhoneKeepsDataBody =>
      'HP itu masih dapat mengirim sisa catatannya, hanya tidak boleh mencatat yang baru. Bila HP itu yang sebenarnya Anda pakai, batalkan saja dan masuk dari sana.';

  @override
  String get moveToThisPhone => 'Pindahkan ke HP ini';

  @override
  String minutesAgo(int n) {
    return '$n menit lalu';
  }

  @override
  String hoursAgo(int n) {
    return '$n jam lalu';
  }

  @override
  String daysAgo(int n) {
    return '$n hari lalu';
  }

  @override
  String get justNow => 'barusan';

  @override
  String get loginTagline => 'Absensi kru & catatan pengecoran';

  @override
  String get dataSafeHere => 'Data di HP ini aman';

  @override
  String get signInAgainToSend =>
      'Masuk lagi dengan akun yang sama supaya sisanya terkirim.';

  @override
  String get cannotSignInYet => 'Belum dapat masuk';

  @override
  String get email => 'Email';

  @override
  String get password => 'Kata sandi';

  @override
  String get signIn => 'Masuk';

  @override
  String get phoneReplacedTitle => 'HP ini sudah digantikan';

  @override
  String get accountUsedElsewhere => 'Akun ini dipakai di HP lain';

  @override
  String get phoneReplacedBody =>
      'Akun Anda dipakai masuk di HP lain, jadi HP ini tidak lagi menerima catatan baru. Sisa yang belum terkirim tetap dikirim dari sini. Bila HP ini yang Anda pakai, masuk lagi di HP ini.';

  @override
  String accountUsedElsewhereBody(String who, String until) {
    return 'Akun Anda dipakai masuk di HP lain$who. Kirim sisa data dari HP ini, lalu lanjutkan di HP itu. Mulai $until HP ini tidak lagi menerima catatan baru.';
  }

  @override
  String inParens(String what) {
    return ' ($what)';
  }

  @override
  String get signInOnThisPhone => 'Masuk di HP ini';

  @override
  String get sessionExpired => 'Sesi berakhir — masuk lagi';

  @override
  String get sessionExpiredBody =>
      'Data di HP ini AMAN dan tetap dapat diisi. Masuk lagi supaya sisanya dapat dikirim.';

  @override
  String clockOffTitle(String drift) {
    return 'Jam HP $drift dari jam server';
  }

  @override
  String get clockOffBody =>
      'Semua jam bacaan bor dan jam TM diambil dari jam HP ini. Nyalakan \"Tanggal & waktu otomatis\" di pengaturan HP, lalu tarik data lagi.';

  @override
  String rejectedCount(int n) {
    return '$n data ditolak server';
  }

  @override
  String get rejectedBody =>
      'Buka \"Pending\" untuk melihat sebabnya dan memperbaikinya.';

  @override
  String get view => 'Lihat';

  @override
  String get sending => 'Mengirim…';

  @override
  String staleUnsent(int docs, int photos) {
    return 'Lebih dari sehari belum terkirim: $docs data, $photos foto';
  }

  @override
  String unsent(int docs, int photos) {
    return 'Belum terkirim: $docs data, $photos foto';
  }

  @override
  String get staleUnsentBody =>
      'Cari tempat bersinyal atau WiFi, lalu tekan Kirim. Bila tetap tidak terkirim, hubungi admin TerraBot.';

  @override
  String get offlineAutoSend =>
      'Tidak ada sinyal. Dikirim otomatis begitu HP mendapat sinyal, walau aplikasi ditutup.';

  @override
  String get autoSendOnSignal => 'Dikirim otomatis begitu ada sinyal.';

  @override
  String get send => 'Kirim';

  @override
  String updateAvailableTitle(String version) {
    return 'Versi $version sudah tersedia';
  }

  @override
  String get updateAvailableBody =>
      'Aplikasi tetap bisa dipakai seperti biasa. Perbarui kalau sempat — lebih enak dilakukan sebelum mulai kerja daripada di tengah pengecoran.';

  @override
  String get updateNow => 'Perbarui';

  @override
  String get updateTitle => 'Perbarui TerraBot Field';

  @override
  String updateBody(String current, String min) {
    return 'Versi di HP ini $current sudah tidak dilayani server. Pasang versi $min atau yang lebih baru untuk lanjut bekerja.';
  }

  @override
  String unsentSafeHere(int n) {
    return '$n data belum terkirim — AMAN di HP ini';
  }

  @override
  String get installOverBody =>
      'Pasang versi baru DI ATAS app ini. JANGAN uninstall dulu: uninstall menghapus semua data yang belum terkirim. Setelah diperbarui, data langsung terkirim sendiri.';

  @override
  String get downloadNew => 'Unduh versi baru';

  @override
  String get askAdminApk => 'Minta file app terbaru ke admin';

  @override
  String get askAdminApkBody =>
      'Admin TerraBot akan mengirim file APK atau tautannya.';

  @override
  String get checkAgain => 'Periksa lagi';

  @override
  String get keepRunningTitle => 'Biarkan TerraBot Field jalan';

  @override
  String get keepRunningBody =>
      'HP ini mematikan aplikasi yang tidak sedang dibuka. Tanpa pengaturan di bawah, getar pengingat cor (20 menit, jeda) dan kirim otomatis TIDAK jalan saat layar mati.';

  @override
  String get openAutostart => 'Buka pengaturan Mulai otomatis';

  @override
  String get openBattery => 'Buka pengaturan Baterai aplikasi';

  @override
  String get setBatteryOnce => 'Atur baterai HP sekali saja';

  @override
  String get setBatteryBody =>
      'Supaya getar pengingat cor dan kirim otomatis tetap jalan saat layar mati.';

  @override
  String get setUp => 'Atur';

  @override
  String get thisPeriod => 'Periode ini';

  @override
  String get fullRecap => 'Rekap lengkap';

  @override
  String fullRecapBody(String to) {
    return 'Semua titik sejak awal proyek sampai $to';
  }

  @override
  String get excelSubject => 'Rekapitulasi Data Tiang';

  @override
  String excelFailed(String error) {
    return 'Excel gagal diunduh: $error';
  }

  @override
  String get reportsTitle => 'Laporan lapangan';

  @override
  String get presetToday => 'Hari ini';

  @override
  String get presetYesterday => 'Kemarin';

  @override
  String get presetWeek => '7 hari';

  @override
  String get pickDate => 'Pilih tanggal';

  @override
  String get pickRange => 'Pilih rentang';

  @override
  String rangeTooLong(String max) {
    return 'Rentang paling lama $max hari.';
  }

  @override
  String dateRange(String from, String to) {
    return '$from – $to';
  }

  @override
  String get preparingExcel => 'Menyiapkan Excel…';

  @override
  String get downloadExcel => 'Unduh Excel (Rekapitulasi Data Tiang)';

  @override
  String get reportLoadError => 'Laporan gagal dibaca';

  @override
  String get statDrilledPoints => 'Titik dibor';

  @override
  String get statCastPoints => 'Titik dicor';

  @override
  String statCastSub(String vol, String trucks) {
    return '$vol m³ · $trucks TM';
  }

  @override
  String get noPointsThatDay =>
      'Belum ada titik yang dibor atau dicor pada tanggal ini.';

  @override
  String projectNo(String id) {
    return 'Proyek #$id';
  }

  @override
  String get pullToReload =>
      'Tarik ke bawah untuk memuat ulang. Data dari semua HP yang sudah terkirim.';

  @override
  String pointsSuffix(String n) {
    return '$n titik';
  }

  @override
  String drilledCount(int n) {
    return 'Dibor ($n)';
  }

  @override
  String castCount(int n) {
    return 'Dicor ($n)';
  }

  @override
  String get noLog => 'tanpa catatan';

  @override
  String operatorShort(String name) {
    return 'op. $name';
  }

  @override
  String get statusDone => 'Selesai';

  @override
  String get statusChecked => 'Diperiksa';

  @override
  String theoreticalOf(String vol, String over) {
    return 'seharusnya $vol m³$over';
  }

  @override
  String percentParens(String sign, String percent) {
    return ' ($sign$percent%)';
  }

  @override
  String get resumePouring => 'Lanjutkan cor';

  @override
  String pauseReminderMin(String body, int min) {
    return '$body · $min menit';
  }

  @override
  String idleReminderMin(String body, int min) {
    return '$body · $min menit sejak TM terakhir';
  }

  @override
  String get drillSnoozeAction => 'Diamkan sampai besok';

  @override
  String get activityTodayTitle => 'Hari ini';

  @override
  String activityTodayMore(int n) {
    return '+$n lagi — buka Laporan untuk daftar lengkapnya';
  }

  @override
  String activityTodayDone(String jam) {
    return 'beres $jam';
  }

  @override
  String activityTodayRunning(String jam) {
    return 'masih jalan · terakhir $jam';
  }

  @override
  String drillIdleTitle(String code) {
    return 'Catatan bor $code belum diisi';
  }

  @override
  String drillIdleBody(String since, String time) {
    return 'Sudah $since sejak bacaan terakhir ($time). Catat kedalaman sekarang, atau tekan Selesai bor bila sudah selesai.';
  }

  @override
  String hoursText(int h) {
    return '$h jam';
  }

  @override
  String minutesText(int m) {
    return '$m menit';
  }

  @override
  String hoursMinutesText(int h, int m) {
    return '$h jam $m menit';
  }

  @override
  String get unsentTitle => 'Ada data belum terkirim';

  @override
  String unsentBody(String since) {
    return 'Sejak $since. Buka TerraBot Field di tempat bersinyal supaya terkirim.';
  }

  @override
  String get badgeSent => 'Terkirim';

  @override
  String get badgeRejected => 'Ditolak';

  @override
  String get badgeWaiting => 'Menunggu data';

  @override
  String get badgeFailedRetry => 'Gagal, diulang';

  @override
  String get badgeUnsent => 'Belum terkirim';

  @override
  String get powerXiaomi1 =>
      'Mulai otomatis (Autostart): NYALAKAN untuk TerraBot Field.';

  @override
  String get powerXiaomi2 =>
      'Penghemat baterai: pilih \"Tanpa batasan\" (No restrictions).';

  @override
  String get powerOppo1 =>
      'Mulai otomatis / Izinkan auto-launch: NYALAKAN untuk TerraBot Field.';

  @override
  String get powerOppo2 =>
      'Penggunaan baterai: izinkan \"Aktivitas latar belakang\" dan \"Mulai otomatis\".';

  @override
  String get powerVivo1 =>
      'Auto-start / Latar belakang: IZINKAN untuk TerraBot Field.';

  @override
  String get powerVivo2 => 'Baterai → Konsumsi daya latar tinggi: IZINKAN.';

  @override
  String get powerHuawei1 =>
      'Peluncuran aplikasi: matikan \"Kelola otomatis\", lalu nyalakan Mulai otomatis, Mulai sekunder, dan Jalankan di latar.';

  @override
  String get powerSamsung1 =>
      'Baterai: pilih \"Tidak dibatasi\" (Unrestricted).';

  @override
  String get powerSamsung2 =>
      'Pastikan TerraBot Field TIDAK ada di daftar \"Aplikasi tidur\" / \"Aplikasi tidur nyenyak\".';

  @override
  String get powerGeneric =>
      'Baterai: pilih \"Tanpa batasan\" / \"Tidak dioptimalkan\" untuk TerraBot Field.';

  @override
  String soundDeeperThanBottom(String bottom) {
    return 'Lebih dalam dari dasar lubang ($bottom m). Periksa lagi.';
  }

  @override
  String soundDeeperThanBefore(String before) {
    return 'Lebih dalam dari muka beton sebelum TM ini ($before m). Beton tidak mungkin turun; periksa lagi.';
  }

  @override
  String readingShallower(String time, String depth) {
    return 'Lebih dangkal dari bacaan jam $time ($depth). Lubang tidak bisa makin dangkal.';
  }

  @override
  String readingDeeperThanNext(String time, String depth) {
    return 'Lebih dalam dari bacaan berikutnya jam $time ($depth). Periksa jamnya.';
  }

  @override
  String depthFarFromPlan(String depth, String planned, String max) {
    return '$depth m terlalu jauh dari rencana $planned m (paling dalam $max m). Periksa angkanya, titiknya, atau elevasi GS.';
  }

  @override
  String numberInvalid(String max) {
    return 'Isi angka lebih dari 0, paling besar $max.';
  }

  @override
  String get castAlreadyDone => 'Cor titik ini sudah selesai.';

  @override
  String get noTruckPouring => 'Tidak ada TM yang sedang dicor.';

  @override
  String truckAlreadyPaused(int seq) {
    return 'TM #$seq sudah dijeda.';
  }

  @override
  String truckNotPaused(int seq) {
    return 'TM #$seq tidak sedang dijeda.';
  }

  @override
  String get photoUnreadable => 'Foto tidak dapat dibaca.';

  @override
  String get photoCompressFailed => 'Foto tidak dapat dikompres.';

  @override
  String get workersTitle => 'Pekerja';

  @override
  String get newWorker => 'Pekerja baru';

  @override
  String get workersLoadError => 'Daftar pekerja gagal dibaca';

  @override
  String get workersAllBody =>
      'Semua pekerja perusahaan. Siapa pun dapat mengabsen dan mengubahnya.';

  @override
  String workersNoProjectBody(String days) {
    return 'Tanpa proyek utama dan tidak diabsen di mana pun $days hari terakhir.';
  }

  @override
  String workersProjectBody(String code, String days) {
    return 'Proyek utamanya $code, atau diabsen di $code $days hari terakhir.';
  }

  @override
  String workersCount(int n) {
    return '$n pekerja';
  }

  @override
  String get noWorkersYet =>
      'Belum ada pekerja. Daftarkan pekerja baru dengan tombol di bawah.';

  @override
  String get searchNameOrPhone => 'Cari nama atau no. HP';

  @override
  String allCount(int n) {
    return 'Semua ($n)';
  }

  @override
  String withoutProject(int n) {
    return 'Tanpa proyek ($n)';
  }

  @override
  String get noMatchingWorkers => 'Tidak ada pekerja yang cocok.';

  @override
  String mainProjectIs(String code) {
    return 'Proyek utama $code';
  }

  @override
  String lastSeenAt(String code, String date) {
    return 'Terakhir di $code · $date';
  }

  @override
  String cameraFailed(String error) {
    return 'Kamera gagal: $error';
  }

  @override
  String get workerNameRequired => 'Isi nama pekerja.';

  @override
  String workerSaved(String name) {
    return '$name disimpan. Terkirim otomatis saat ada sinyal.';
  }

  @override
  String get mainProjectOptional => 'Proyek utama (opsional)';

  @override
  String get noMainProject => 'Tanpa proyek utama';

  @override
  String andOthers(int n) {
    return '\n• dan $n lainnya';
  }

  @override
  String get maybeRegistered => 'Mungkin sudah terdaftar';

  @override
  String maybeRegisteredBody(String names) {
    return 'Nama atau nomor HP ini mirip pekerja yang sudah ada:\n$names\n\nKalau orangnya sama, batalkan dan pakai pekerja yang sudah ada. Kalau memang orang lain, tekan tombol simpan sekali lagi.';
  }

  @override
  String get needsFixing => 'Perlu diperbaiki';

  @override
  String get viewOnlyWorkerBody =>
      'Akun Anda tidak punya izin mendaftarkan atau mengubah pekerja. Minta kantor menambahkan izinnya.';

  @override
  String get noFaceDetected => 'Wajah tidak terdeteksi';

  @override
  String facesDetected(int n) {
    return '$n wajah terdeteksi';
  }

  @override
  String get facePhotoBody =>
      'Foto wajah dipakai kantor untuk mencocokkan kru. Ambil ulang dengan satu wajah, menghadap kamera.';

  @override
  String get retake => 'Ulang';

  @override
  String get fullName => 'Nama lengkap';

  @override
  String get phoneOptional2 => 'No. HP (opsional)';

  @override
  String get workerNoteHint => 'Catatan (mis. tukang besi, operator)';

  @override
  String get saveAsNewWorker => 'Tetap simpan sebagai pekerja baru';

  @override
  String get attendanceTitle => 'Absensi kru';

  @override
  String get attendToday => 'Absen hari ini';

  @override
  String get attendanceLoadError => 'Absen gagal dibaca';

  @override
  String get attendanceHistory => 'Riwayat absen';

  @override
  String get otherProject => 'proyek lain';

  @override
  String get attendanceHistoryBody => 'Absen yang dibuat dari HP ini';

  @override
  String get noAttendanceYet => 'Belum ada absen.';

  @override
  String failedWith(String error) {
    return 'Gagal: $error';
  }

  @override
  String photoInGallery(String album) {
    return 'Foto tersimpan di galeri HP (album \"$album\").';
  }

  @override
  String get galleryDenied =>
      'Absen tersimpan, tapi foto tidak masuk galeri: izin galeri ditolak.';

  @override
  String get galleryFailed =>
      'Absen tersimpan, tapi foto gagal disimpan ke galeri HP.';

  @override
  String get saveCrewTicks => 'Simpan centang kru?';

  @override
  String get saveCrewTicksBody => 'Ada perubahan kru yang belum disimpan.';

  @override
  String get crewAttendance => 'Absen kru';

  @override
  String saveWithCount(int n) {
    return 'Simpan · $n kru';
  }

  @override
  String get rejectedByOffice => 'Ditolak kantor';

  @override
  String get approvedByOffice => 'Sudah disetujui kantor';

  @override
  String get attendanceLocked => 'Absen ini tidak dapat diubah lagi dari HP.';

  @override
  String get projectLabel => 'Proyek';

  @override
  String get projectNoLocation => 'Lokasi proyek belum diisi kantor';

  @override
  String get projectNoLocationBody =>
      'Absen tetap tersimpan; jarak ke proyek tidak dapat diperiksa.';

  @override
  String get checkIn => 'Absen masuk';

  @override
  String get checkOut => 'Absen pulang';

  @override
  String get savedWithoutLocation => 'Tersimpan tanpa lokasi';

  @override
  String savedWithoutLocationBody(String problem) {
    return '$problem Kantor akan melihat absen ini bertanda \"tanpa lokasi\".';
  }

  @override
  String crewPresent(int n) {
    return 'Kru hadir ($n)';
  }

  @override
  String get noWorkersTitle => 'Belum ada pekerja';

  @override
  String get noWorkersBody =>
      'Daftarkan pekerja baru dulu. Pekerja yang didaftarkan di sini langsung dapat diabsen, walau belum terkirim.';

  @override
  String get thisProject => 'proyek ini';

  @override
  String get searchWorkerName => 'Cari nama pekerja';

  @override
  String noWorkersForProject(String code) {
    return 'Belum ada pekerja $code';
  }

  @override
  String noWorkersForProjectBody(String code, String days) {
    return 'Belum ada yang proyek utamanya $code atau diabsen di sini $days hari terakhir. Centang dari daftar semua pekerja di bawah; setelah terkirim, mereka muncul paling atas di sini.';
  }

  @override
  String get unknownWorker => 'Pekerja tidak dikenal';

  @override
  String otherWorkers(int n) {
    return 'Pekerja lain ($n)';
  }

  @override
  String get noWorkerByName => 'Tidak ada pekerja dengan nama itu.';

  @override
  String get flaggedForOffice => 'Ditandai untuk diperiksa kantor';

  @override
  String get flagOutsideRadius => '• Lokasi absen di luar radius proyek';

  @override
  String get flagNoProjectLocation => '• Lokasi proyek belum diisi kantor';

  @override
  String get flagNoLocation => '• Absen tanpa lokasi GPS';

  @override
  String get flagMockLocation => '• HP melaporkan lokasi palsu';

  @override
  String get flagClockOff => '• Jam HP berbeda jauh dari jam server';

  @override
  String get flagClockUnverified =>
      '• Jam HP tidak dapat diverifikasi (HP dinyalakan ulang)';

  @override
  String get flagClockEdited => '• Jam diubah manual';

  @override
  String get flagFaceCountOff =>
      '• Jumlah wajah di foto berbeda dengan jumlah kru';

  @override
  String get flagPhotoPending => '• Foto masih menunggu terkirim';

  @override
  String get fullDay => 'Penuh';

  @override
  String get halfDay => '½ hari';

  @override
  String get overtime => 'Lembur';

  @override
  String hoursShort(String h) {
    return '$h j';
  }

  @override
  String crewPhotoOf(String what) {
    return 'Foto kru · $what';
  }

  @override
  String atTime(String time) {
    return 'Pukul $time';
  }

  @override
  String withinRadius(String m) {
    return '$m m dari proyek ✓';
  }

  @override
  String outsideRadius(String m, String radius) {
    return '$m m dari proyek — di luar radius $radius m';
  }

  @override
  String get noLocation => 'Tanpa lokasi';

  @override
  String get mockLocation => 'Lokasi palsu terdeteksi';

  @override
  String facesInPhoto(int n) {
    return '$n wajah di foto';
  }

  @override
  String get longPressRetake => 'Tekan lama untuk foto ulang';

  @override
  String get levelRefTitle => 'Patokan elevasi';

  @override
  String levelRefColTip(String col, String tip) {
    return 'COL $col · Tip $tip';
  }

  @override
  String get notSet => 'belum ada';

  @override
  String get levelRefNoGs =>
      'Isi GS dulu untuk melihat kedalaman COL dan rencana bor.';

  @override
  String levelRefGs(String gs) {
    return 'GS $gs';
  }

  @override
  String levelRefColBelow(String d) {
    return '• COL $d di bawah GS';
  }

  @override
  String levelRefPlanned(String d) {
    return '• Rencana bor $d';
  }

  @override
  String get levelRefFooter =>
      'Kedalaman bor diukur dari GS sampai dasar lubang.';

  @override
  String get projectsMissingHome =>
      'Tarik ke bawah untuk mengambilnya dari server. Perlu sinyal sekali saja; sesudahnya dapat dipakai tanpa sinyal.';

  @override
  String get noFieldAccess => 'Akun ini belum punya akses lapangan';

  @override
  String get noFieldAccessBody =>
      'Minta admin TerraBot menambahkan divisi Field Engineer ke akun Anda, lalu tarik ke bawah.';

  @override
  String get volumePouredHere => 'Volume tertuang di titik ini';

  @override
  String get volumeSharedHint =>
      'Bawaannya satu TM penuh. Bila TM ini dibagi dengan lubang lain, isi porsi yang masuk ke titik ini saja.';

  @override
  String overuseAheadTitle(String percent) {
    return 'Beton akan lewat $percent% dari seharusnya';
  }

  @override
  String overuseAheadBody(String used, String theoretical) {
    return 'Terpakai $used m³ dari $theoretical m³ yang seharusnya setelah TM ini. Paling sering sebabnya TM dibagi dengan lubang lain — isi porsinya saja bila begitu.';
  }

  @override
  String get overuseAfterTitle => 'Beton jauh di atas seharusnya';

  @override
  String overuseAfterBody(int seq, String percent) {
    return 'Sampai TM #$seq, beton terpakai $percent% di atas seharusnya. Sebelum dicatat sebagai lubang membesar, periksa dulu: apakah ada TM yang dibagi dengan lubang lain?';
  }

  @override
  String get fixTruckVolume => 'Betulkan volume TM';

  @override
  String get holeReallyWider => 'Lubang memang membesar';

  @override
  String get later => 'Nanti saja';

  @override
  String widerHoleNote(int seq, String percent) {
    return 'TM #$seq: beton $percent% di atas teoritis — lubang membesar (diperiksa di lapangan).';
  }

  @override
  String get pullNowTitle => 'Cabut tremie sekarang?';

  @override
  String pullNowBody(int seq, String emb, String which, String after) {
    return 'TM #$seq selesai, tertanam $emb. Cabut $which supaya tertanam jadi $after.';
  }

  @override
  String get pulledAlready => 'Sudah dicabut';

  @override
  String get notYetPull => 'Belum dicabut';

  @override
  String get overbreakCheckedTag => '[overbreak diperiksa]';

  @override
  String get excelOptionsTitle => 'Unduh Excel';

  @override
  String get excelPeriodLabel => 'Rentang';

  @override
  String get excelSheetsLabel => 'Lembar yang dibuat';

  @override
  String get sheetPiles => 'Rekap tiang';

  @override
  String get sheetPilesBody =>
      'Satu baris per titik: kedalaman, volume, tanggal.';

  @override
  String get sheetConcrete => 'Mutu beton';

  @override
  String get sheetConcreteBody =>
      'Hanya titik yang sudah dicor, beserta kuat tekannya.';

  @override
  String get sheetOperators => 'Rekap operator';

  @override
  String get sheetOperatorsBody =>
      'Meter bor aktual vs teoritis per operator, plus satu lembar tiap operator.';

  @override
  String get pickAtLeastOneSheet => 'Pilih minimal satu lembar.';

  @override
  String get download => 'Unduh';

  @override
  String get retakePhoto => 'Ulangi';

  @override
  String get tapToEnlarge => 'Ketuk untuk memperbesar';

  @override
  String get photoNotOnThisPhone => 'Foto tidak ada di HP ini';

  @override
  String get correct => 'Koreksi';

  @override
  String get backOut => 'Keluar';

  @override
  String get gsRowLabel => 'Muka tanah (GS)';

  @override
  String plannedDrillOf(String depth) {
    return 'Panjang bor rencana $depth';
  }

  @override
  String confirmBeforeDrilling(String code) {
    return 'Konfirmasi sebelum bor $code';
  }

  @override
  String get confirmBeforeDrillingBody =>
      'Masukkan hasil koreksi GS di titik ini. Panjang bor rencana dihitung dari angka ini, jadi harus benar sebelum mata bor turun.';

  @override
  String get correctGsTitle => 'Koreksi GS';

  @override
  String get correctGsBody =>
      'Surveyor merevisi tembakannya? Ubah GS di sini; panjang bor rencana dan kedalaman cut-off ikut terhitung ulang.';

  @override
  String codeHeldBy(String name) {
    return 'Kodenya ada di HP $name';
  }

  @override
  String codeHeldByBody(String name) {
    return 'Minta $name membuka titik ini di HP-nya lalu menekan \"Oper ke rekan\". Kode 6 angka akan muncul di layarnya untuk disebutkan. Tidak ada permintaan yang terkirim otomatis.';
  }

  @override
  String get askHolder => 'Minta ke pemegang';

  @override
  String get sendingRequest => 'Mengirim permintaan…';

  @override
  String get requestSentTitle => 'Permintaan terkirim';

  @override
  String requestSentBody(String name) {
    return '$name mendapat pemberitahuan di HP-nya. Begitu disetujui, catatan ini pindah ke HP Anda — tidak perlu kode.';
  }

  @override
  String get handingOver => 'Memindahkan catatan…';

  @override
  String get rejectingRequest => 'Menolak permintaan…';

  @override
  String logHandedTo(String code, String name) {
    return 'Catatan $code sudah pindah ke $name.';
  }

  @override
  String requestRejected(String name) {
    return 'Permintaan $name ditolak.';
  }

  @override
  String handoverRequestTitle(String name) {
    return '$name minta oper';
  }

  @override
  String handoverRequestBody(String code) {
    return 'Titik $code — buka untuk menyetujui atau menolak.';
  }

  @override
  String handoverRequestPrompt(String name, String code) {
    return '$name sedang di titik $code dan menunggu jawaban. Disetujui berarti catatan ini langsung pindah ke HP-nya, dan layar ini ditutup.';
  }

  @override
  String get approve => 'Setujui';

  @override
  String get reject => 'Tolak';

  @override
  String get drillProgressLabel => 'Kemajuan bor';

  @override
  String get castProgressLabel => 'Kemajuan cor';

  @override
  String drillProgressMain(String depth, String planned) {
    return '$depth dari $planned rencana';
  }

  @override
  String castProgressMain(String n, String vol, String theoretical) {
    return 'TM ke-$n · $vol m³ dari $theoretical m³ teoritis';
  }

  @override
  String get progressNothingYet => 'Belum ada catatan';

  @override
  String get logGoneResynced =>
      'Catatannya sudah tidak ada di server — kemungkinan dihapus dari kantor. Titik ini baru saja ditarik ulang; silakan buka lagi.';

  @override
  String get progressNoSync =>
      'Catatannya sudah dibuka, catatan pertama belum masuk';

  @override
  String progressLastAt(String time, String age) {
    return 'Catatan terakhir $time · $age';
  }

  @override
  String get progressAsSent =>
      'Sejauh yang sudah terkirim HP pemegangnya. Kalau HP-nya sedang tanpa sinyal, keadaan sebenarnya bisa lebih maju.';

  @override
  String get refresh => 'Muat ulang';

  @override
  String get pointHistoryOpen => 'Lihat riwayat titik';

  @override
  String pointHistoryTitle(String code) {
    return 'Riwayat $code';
  }

  @override
  String get pointHistoryErrorTitle => 'Riwayat tidak bisa dibuka';

  @override
  String get pointHistoryErrorBody =>
      'Layar ini membaca langsung dari server, jadi perlu sinyal. Tarik ke bawah untuk mencoba lagi.';

  @override
  String get pointHistoryNoCasting =>
      'Belum ada catatan cor di server untuk titik ini.';

  @override
  String get pointHistoryTrail => 'Jejak koreksi';

  @override
  String get deletedLabel => 'Dihapus';

  @override
  String get fromOffice => 'Dari kantor';

  @override
  String trucksCount(int n) {
    return '$n TM';
  }

  @override
  String get volumeUsed => 'Volume terpakai';

  @override
  String get volumeTheoretical => 'Volume teoritis';

  @override
  String get overusePercent => 'Kelebihan pakai';

  @override
  String get castStartEnd => 'Mulai – selesai cor';

  @override
  String get drillLogNotClosed => 'Catatan belum ditutup';

  @override
  String get embedBeforeLabel => 'Tremie tertanam awal';

  @override
  String get embedAfterLabel => 'Tremie tertanam akhir';

  @override
  String tremieSummary(int n, String total, String gap) {
    return '$n batang · $total m · ujung bawah $gap di atas dasar lubang';
  }

  @override
  String get tremieStillFitted => 'masih terpasang';

  @override
  String tremiePulledAfter(int seq) {
    return 'dicabut setelah TM $seq';
  }

  @override
  String get pointConfirmedTitle => 'Titik sudah dikonfirmasi';

  @override
  String pointConfirmedBody(String who, String when) {
    return 'Dikonfirmasi $who, $when. Data bor dan cor titik ini tidak dapat diubah lagi sampai konfirmasinya dibuka dari kantor.';
  }

  @override
  String get reasonTitikDikonfirmasi =>
      'Titik ini sudah dikonfirmasi kantor — minta kantor membuka konfirmasinya dulu';

  @override
  String get drillSection => 'Pengeboran';

  @override
  String get castSection => 'Pengecoran';

  @override
  String get deepestLabel => 'Terdalam';

  @override
  String get drillDurationLabel => 'Lama bor';

  @override
  String get avgRateLabel => 'Laju rata-rata';

  @override
  String get slowestSegmentLabel => 'Ruas paling lambat';

  @override
  String metresPerHour(String v) {
    return '$v m/jam';
  }

  @override
  String get drillEffectiveLabel => 'Lama mengebor';

  @override
  String drillOfTotal(String total) {
    return 'dari total $total';
  }

  @override
  String get drillEffectiveRateLabel => 'Laju bor';

  @override
  String drillRateTotal(String laju) {
    return '$laju m/jam termasuk berhenti';
  }

  @override
  String drillStops(String n, String lama) {
    return '$n kali berhenti · $lama';
  }

  @override
  String get denahTitle => 'Denah titik';

  @override
  String get denahLabelToggle => 'Kode titik';

  @override
  String get denahRotate => 'Putar 90°';

  @override
  String get denahFit => 'Pas layar';

  @override
  String get denahDeviationToggle => 'Garis simpangan';

  @override
  String get denahDrilled => 'Sudah dibor';

  @override
  String denahNoCoordTitle(String n) {
    return '$n titik tidak tergambar';
  }

  @override
  String get denahNoCoordBody =>
      'Titik ini belum punya koordinat X/Y — rencana maupun aktual — jadi tidak ada tempatnya di denah. Kantor yang mengisinya lewat impor Excel.';

  @override
  String get denahEmptyTitle => 'Belum ada koordinat';

  @override
  String get denahEmptyBody =>
      'Tidak ada satu pun titik proyek ini yang koordinat X/Y-nya terisi, jadi denahnya belum dapat digambar. Koordinat rencananya diisi dari kantor.';

  @override
  String drillPlanRef(String v) {
    return '$v rencana';
  }

  @override
  String deviationStopTitle(String v) {
    return 'Simpangan $v melewati toleransi';
  }

  @override
  String deviationStopBody(String batas, String lewat) {
    return 'Toleransi proyek $batas; titik ini lewat $lewat. Periksa dulu hasil ukur dan koordinat rencananya sebelum lubang ini dicor — sesudah dicor, satu-satunya pilihan yang tersisa adalah perkuatan, dan itu bukan keputusan dari HP.';
  }

  @override
  String get deviationStopSave => 'Simpan apa adanya';

  @override
  String get deviationStopRecheck => 'Periksa lagi';

  @override
  String get filterDrilling => 'Sedang dibor';

  @override
  String get filterCasting => 'Sedang dicor';

  @override
  String progressIdle(String jam, String lama) {
    return 'Berhenti sejak $jam · $lama tanpa bacaan baru';
  }

  @override
  String readingTableTitle(String n) {
    return 'Bacaan ($n)';
  }

  @override
  String get readingColTime => 'Jam';

  @override
  String get readingColDepth => 'Kedalaman';

  @override
  String get readingColAdded => 'Tambah';

  @override
  String get readingColRate => 'Laju';

  @override
  String get readingNotPlotted =>
      'Tidak tergambar di kurva — jam atau kedalamannya tidak terbaca.';

  @override
  String get activityTitle => 'Aktivitas lapangan';

  @override
  String get activityToday => 'Hari ini · ketuk untuk pilih tanggal';

  @override
  String get activityPick => 'Ketuk untuk pilih tanggal';

  @override
  String get activityPrevDay => 'Hari sebelumnya';

  @override
  String get activityNextDay => 'Hari berikutnya';

  @override
  String get activityEmptyTitle => 'Tidak ada catatan pada hari ini';

  @override
  String get activityEmptyBody =>
      'Tidak ada pengeboran maupun pengecoran yang tercatat. Pilih hari lain dengan panah di atas.';

  @override
  String get activityDrilled => 'titik dibor';

  @override
  String get activityPoured => 'titik dicor';

  @override
  String get activityAllProjects => 'Semua proyek';

  @override
  String get activityNoProject => 'Tanpa proyek';

  @override
  String get activitySeeAll => 'Lihat semua';

  @override
  String get curveNeedsTwo =>
      'Kurvanya perlu sedikitnya dua bacaan yang jam dan kedalamannya terbaca.';

  @override
  String get readingUnreadable =>
      'Bacaan ini jam atau kedalamannya tidak terbaca - betulkan dari kantor.';

  @override
  String trailCount(int n) {
    return '$n perubahan';
  }

  @override
  String get pourStartTitle => 'Sebelum TM pertama';

  @override
  String get stickOutQuestion =>
      'Pipa tremie menyembul berapa meter di atas tanah?';

  @override
  String get stickOutField => 'Menyembul di atas tanah';

  @override
  String stickOutBasis(String panjang) {
    return 'Pipa yang sudah tersusun $panjang.';
  }

  @override
  String stickOutResult(String dalam, String celah) {
    return 'Berarti ujung tremie di $dalam, yaitu $celah di atas dasar lubang.';
  }

  @override
  String get stickOutRequired => 'Isi dulu berapa meter pipa yang menyembul.';

  @override
  String stickOutTooHigh(String celah) {
    return 'Ujung tremie jadi $celah di atas dasar lubang. Terlalu tinggi — periksa lagi.';
  }

  @override
  String get stickOutTooDeep =>
      'Ujung tremie jadi lebih dalam dari dasar lubang. Periksa lagi.';

  @override
  String get gradeQuestion => 'Mutu beton TM hari ini berapa?';

  @override
  String get nextStep => 'Lanjut';

  @override
  String get backStep => 'Kembali';

  @override
  String get ratioOddTitle => 'Sounding tidak cocok dengan volume beton';

  @override
  String ratioOddBody(String ini, String pola) {
    return 'TM ini keluar $ini, padahal TM sebelumnya $pola. Lubangnya sudah selesai dibor sebelum beton pertama masuk, jadi bentuknya tidak berubah di tengah cor — paling sering sebabnya sounding kebaca salah.';
  }

  @override
  String ratioOddAlone(String ini) {
    return 'TM ini keluar $ini, dan belum ada TM sebelumnya sebagai pembanding. Wajarnya antara −20% dan +100%; di luar itu biasanya soundingnya yang kebaca salah.';
  }

  @override
  String get remeasure => 'Ukur ulang';

  @override
  String get saveAnyway => 'Tetap simpan';

  @override
  String get qTruckNo => 'TM-nya nomor lambung berapa?';

  @override
  String get qVolume => 'Berapa kubik beton di TM ini?';

  @override
  String get qSupplier => 'Beton dari pemasok mana?';

  @override
  String get qSlump => 'Slump hasil ujinya berapa?';

  @override
  String get qPhoto => 'Foto surat jalannya';

  @override
  String supplierSameAsBefore(String nama) {
    return 'Masih $nama, sama seperti TM sebelumnya.';
  }

  @override
  String get changeIt => 'Ubah';

  @override
  String get lengkapiTitle => 'Lengkapi dulu';

  @override
  String get lengkapiBody =>
      'Catatan cor belum bisa ditutup. Isi yang kurang di bawah ini, lalu lanjut.';

  @override
  String get qSoundingAwal =>
      'Sebelum TM pertama dituang, dari muka tanah ke muka beton berapa meter?';

  @override
  String get tremieDepthField => 'Kedalaman ujung tremie dari GS';

  @override
  String tremieDepthHint(String dasar) {
    return 'Diukur saat tremie sudah tersusun, sebelum TM pertama. Dasar lubang $dasar; celahnya dihitung dari sini.';
  }

  @override
  String get tremieDepthRequired => 'Isi kedalaman ujung tremie dulu.';

  @override
  String tremieDepthInvalid(String dasar) {
    return 'Ujung tremie harus di antara dasar lubang ($dasar) dan 5 m di atasnya.';
  }

  @override
  String get soundingBeforeNeeded =>
      'Sounding sebelum TM #1 belum diisi — tanpa itu tertanam awalnya tidak pernah ada.';

  @override
  String get reasonSoundingAwalKosong =>
      'Sounding sebelum TM pertama belum diisi';

  @override
  String get reasonTremieDalamSalah =>
      'Kedalaman ujung tremie tidak masuk akal terhadap dasar lubang';

  @override
  String get actualX => 'X aktual';

  @override
  String get actualY => 'Y aktual';

  @override
  String get actualXRequired => 'X aktual — wajib';

  @override
  String get actualYRequired => 'Y aktual — wajib';

  @override
  String get actualXYRequiredMsg =>
      'Isi X dan Y aktual pusat lubang. Diukur setelah pengeboran selesai.';

  @override
  String get actualXYBothMsg => 'X dan Y harus diisi dua-duanya.';

  @override
  String get actualXYInvalid => 'Koordinat tidak sah.';

  @override
  String get designXYTitle => 'Koordinat rencana';

  @override
  String designXYBody(String x, String y) {
    return 'X $x · Y $y';
  }

  @override
  String deviationBody(String simpangan, String toleransi) {
    return 'Simpangan $simpangan, toleransi $toleransi.';
  }

  @override
  String deviationOverTitle(String simpangan) {
    return 'Simpangan $simpangan melewati toleransi';
  }

  @override
  String deviationOverBody(String toleransi) {
    return 'Toleransi proyek ini $toleransi. Periksa angkanya sebelum menyimpan — kalau benar, laporkan ke kantor.';
  }

  @override
  String get castDoneTitle => 'Sudah selesai dicor';

  @override
  String get castDoneVolume => 'Beton terkirim';

  @override
  String get castDonePlanned => 'Teoritis rencana';

  @override
  String castDoneVsPlanned(String rencana, String selisih) {
    return '$rencana m³ ($selisih%)';
  }

  @override
  String get castDoneTrucks => 'Jumlah TM';

  @override
  String get castDoneTopDepth => 'Muka beton terakhir tercatat';

  @override
  String get castDoneHoleDepth => 'Kedalaman lubang';

  @override
  String get castDoneAt => 'Selesai cor';

  @override
  String get finishTruckAction => 'Selesai TM';

  @override
  String notifSoundingDue(String seq) {
    return 'TM $seq selesai — sounding belum diisi';
  }

  @override
  String get notifSoundingDueBody =>
      'Buka catatan cor di HP dan isi sounding muka beton sesudah tuang. Tertanam tremie dan pemeriksaan volume dihitung dari angka itu.';

  @override
  String get drillLockedConfirmedTitle => 'Sudah diperiksa kantor — terkunci';

  @override
  String get drillLockedConfirmedBody =>
      'Titik ini sudah diperiksa dan disetujui, jadi catatan bornya tidak bisa diubah lagi. Kalau ada angka yang salah, minta kantor membuka konfirmasinya dulu.';

  @override
  String get drillLockedCastTitle => 'Sudah dicor — terkunci';

  @override
  String get drillLockedCastBody =>
      'Betonnya sudah masuk, jadi catatan bor ini tertutup untuk selamanya. Tidak ada lagi yang bisa diubah di layar ini.';

  @override
  String get drillNeedGsTitle => 'Isi ground level dulu';

  @override
  String get drillNeedGsBody =>
      'Semua kedalaman dihitung turun dari ground level, jadi belum ada yang bisa dicatat sebelum itu terisi. Ketuk baris ground level di atas untuk mengisinya.';

  @override
  String get blockedNeedGs => 'Isi ground level dulu — ketuk baris di atas.';

  @override
  String get blockedConfirmed =>
      'Sudah diperiksa kantor; catatan ini tidak bisa diubah lagi.';

  @override
  String get blockedCast =>
      'Sudah dicor; catatan bor sudah tertutup untuk selamanya.';

  @override
  String get blockedNeedTremie => 'Susun pipa tremie dulu, baru tambah TM.';

  @override
  String get tremieDepthFirst => 'Ukur tremie dulu';

  @override
  String get blockedNeedTremieDepth =>
      'Ukur kedalaman ujung tremie dulu. Begitu beton masuk, angkanya tidak bisa diukur lagi.';

  @override
  String get drillReopenConfirmTitle => 'Buka lagi catatan bor ini?';

  @override
  String get drillReopenConfirmBody =>
      'Catatan ini sudah ditutup. Kalau dibuka lagi, kedalamannya bisa ditambah dan diubah, dan kantor akan melihat bahwa catatan ini pernah dibuka ulang. Lakukan hanya kalau memang ada angka yang salah.';

  @override
  String get castReopenConfirmTitle => 'Buka lagi catatan cor ini?';

  @override
  String get castReopenConfirmBody =>
      'Catatan ini sudah ditutup. Kalau dibuka lagi, TM dan volumenya bisa ditambah dan diubah, dan kantor akan melihat bahwa catatan ini pernah dibuka ulang. Lakukan hanya kalau memang ada angka yang salah.';

  @override
  String get supplierLocal => 'Lokal (site-mix, diaduk di lokasi)';

  @override
  String get supplierMustBePicked =>
      'Pilih pemasok dari daftar. Kalau pemasoknya belum ada di daftar, minta kantor menambahkannya — jangan diketik sendiri.';

  @override
  String get supplierMissingTitle => 'Pemasoknya tidak ada di daftar?';

  @override
  String get supplierMissingBody =>
      'Jangan diketik sendiri. Hubungi kantor supaya pemasoknya ditandai \"Pemasok beton\" dan PO proyek ini diterbitkan — nama yang diketik sendiri tidak pernah masuk rekap pemasok dan tidak cocok dengan surat jalan.';

  @override
  String get supplierTypedBefore =>
      'Nama ini diketik tangan pada versi lama — pilih pemasok yang benar dari daftar';

  @override
  String get supplierLocalConfirmTitle => 'Pakai beton Lokal (site-mix)?';

  @override
  String get supplierLocalConfirmBody =>
      'Artinya betonnya diaduk di lokasi, bukan dikirim batching plant — jadi catatan ini tidak akan punya pemasok dan tidak akan cocok dengan surat jalan mana pun. Kalau betonnya datang pakai TM, pilih pemasoknya dari daftar.';

  @override
  String get supplierLocalConfirmYes => 'Ya, site-mix';

  @override
  String get watchOpen => 'Pantau sekarang';

  @override
  String watchTitle(String code) {
    return 'Pantau $code';
  }

  @override
  String watchAsOf(String jam, int menit) {
    return 'per $jam · $menit menit lalu';
  }

  @override
  String get watchNoTimestamp => 'Belum ada catatan berjam dari HP pemegangnya';

  @override
  String get watchOfflineTitle => 'Tidak bisa menarik data';

  @override
  String get watchOfflineBody =>
      'Pantau membaca langsung dari server, jadi butuh sinyal. Tarik ke bawah untuk mencoba lagi.';

  @override
  String get watchNothingTitle => 'Belum ada yang dikerjakan di titik ini';

  @override
  String get watchNothingBody =>
      'Begitu HP pemegangnya mengirim bacaan atau TM pertama, kemajuannya muncul di sini.';

  @override
  String get watchCastRunning => 'Sedang dicor';

  @override
  String get watchCastDone => 'Cor selesai';

  @override
  String watchPouringNow(String seq) {
    return 'TM $seq sedang dituang';
  }

  @override
  String get watchTrucks => 'TM masuk';

  @override
  String get watchVolume => 'Volume';

  @override
  String get watchConcreteLevel => 'Muka beton dari GS';

  @override
  String get watchNotSounded => 'belum disounding';

  @override
  String get watchEmbedment => 'Tremie tertanam';

  @override
  String get watchDrillRunning => 'Sedang dibor';

  @override
  String get watchDrillDone => 'Bor selesai';

  @override
  String get watchCurveWaitTitle => 'Kurvanya butuh dua bacaan';

  @override
  String get watchCurveWaitBody =>
      'Dengan satu bacaan belum ada rentang waktu yang bisa digambar. Muncul sendiri begitu bacaan kedua masuk.';

  @override
  String get watchDepth => 'Kedalaman';

  @override
  String get watchRate => 'Laju rata-rata';

  @override
  String get watchReadings => 'Bacaan';

  @override
  String truckTableTitle(String n) {
    return 'Truk mixer ($n)';
  }

  @override
  String get truckColSeq => 'TM';

  @override
  String get truckColPour => 'Tuang';

  @override
  String get truckColVolume => 'Volume';

  @override
  String get truckColCumulative => 'Kumulatif';

  @override
  String truckArrivedAt(String jam) {
    return 'datang $jam';
  }

  @override
  String get photoExpired => 'Foto ini sudah lewat masa simpannya di server.';

  @override
  String get photoFailed =>
      'Foto tidak dapat dimuat. Periksa sinyal, lalu coba lagi.';

  @override
  String get truckShare => 'Bagikan';

  @override
  String get shareNoPhoto =>
      'Foto surat jalan tidak dapat diambil — teksnya saja yang dibagikan.';

  @override
  String get sheetSupplier => 'Beton per pemasok';

  @override
  String get sheetSupplierBody =>
      'Tiap pemasok satu lembar: TM, surat jalan, volume, dan totalnya.';

  @override
  String get loginLockedTitle => 'Terkunci sementara';

  @override
  String loginLockedBody(String sisa) {
    return 'Terlalu banyak percobaan masuk. Tombol Masuk hidup lagi dalam $sisa. Menekannya sekarang tidak memperpanjang kunci, tetapi juga tidak mempercepatnya.';
  }

  @override
  String loginLockedButton(String sisa) {
    return 'Tunggu $sisa';
  }

  @override
  String get koordinatKomaJudul => 'Komanya terlewat?';

  @override
  String koordinatKomaIsi(String nama, int diketik, int rencana, int maks) {
    return '$nama aktual diketik $diketik angka sebelum koma, sedangkan koordinat rencana titik ini $rencana angka. Isian berhenti menerima angka pada $maks — bukan rusak, melainkan penuh. Ketik komanya sesudah $rencana angka, lalu angka desimalnya.';
  }

  @override
  String get koordinatKosongkan => 'Kosongkan isian ini';

  @override
  String get swipeToFinishDrilling => 'Geser untuk selesai bor';

  @override
  String get swipeToFinishCasting => 'Geser untuk selesai cor';

  @override
  String get swipeDone => 'Tersimpan';

  @override
  String get entityGateTicket => 'Catatan gerbang';

  @override
  String get gateRecordTruck => 'Gerbang: catat TM masuk';

  @override
  String gateTitle(String code) {
    return 'TM masuk gerbang · $code';
  }

  @override
  String get gateIntroTitle => 'Ketik persis seperti di badan truk';

  @override
  String get gateIntroBody =>
      'Nomor ini yang memasangkan catatan gerbang dengan TM yang dituang di lubang.';

  @override
  String get gateVolume => 'Volume di surat jalan';

  @override
  String get gateGrade => 'Mutu beton (fc\')';

  @override
  String get gateGradeInvalid => 'Mutu beton tidak masuk akal (1–150 MPa).';

  @override
  String get gateRejected => 'TM ini ditolak di gerbang';

  @override
  String get gateRejectedTitle => 'TM yang ditolak tidak dituang';

  @override
  String get gateRejectedBody =>
      'Catatannya tetap tersimpan sebagai bukti, tetapi volumenya tidak masuk ke log cor titik ini.';

  @override
  String get gateRejectReason => 'Alasan ditolak';

  @override
  String get gateRejectReasonRequired => 'Isi alasan TM ini ditolak.';

  @override
  String get gateTruckRequired => 'Isi nomor lambung TM.';

  @override
  String get gatePhotoRequired => 'Foto surat jalannya dulu.';

  @override
  String gateSaved(String truck) {
    return 'TM $truck dicatat. Terkirim otomatis saat ada sinyal.';
  }

  @override
  String get startPourOnlyLog => 'Mulai log cor — di lubang saja';

  @override
  String get pourTruckNoTitle => 'Nomor TM adalah kuncinya';

  @override
  String get pourTruckNoBody =>
      'Pilih nomor TM yang sudah dicatat di gerbang, atau ketik persis seperti di badan truk. Volume, slump, dan surat jalannya menempel dari catatan gerbang lewat nomor ini.';

  @override
  String get pourTruckNoBodyEmpty =>
      'Catatan gerbang untuk titik ini belum sampai ke HP ini. Ketik nomor TM persis seperti di badan truk; volume, slump, dan surat jalannya menempel dari catatan gerbang lewat nomor ini.';

  @override
  String get gateQGrade => 'Mutu betonnya berapa?';

  @override
  String get gateQSummary => 'Sudah benar semua?';

  @override
  String get gateRejectAction => 'Tolak TM ini';

  @override
  String gateOtherPileTitle(String truck) {
    return 'TM $truck juga dituang ke lubang lain?';
  }

  @override
  String get gateOtherPileBody =>
      'Kalau satu TM dibagi ke dua lubang, catat juga di lubang berikutnya. Nomor TM, foto surat jalan, slump, dan mutunya disalin — tinggal isi volumenya.';

  @override
  String get gateOtherPileNo => 'Tidak, selesai';

  @override
  String get gateOtherPilePick => 'Ya — ketuk lubang berikutnya:';

  @override
  String get gateOtherPileSearch => 'Cari kode titik';

  @override
  String gateCopiedTitle(String truck) {
    return 'TM $truck lanjut ke titik ini';
  }

  @override
  String get gateCopiedBody =>
      'Isi volume yang dituang DI TITIK INI saja, bukan seluruh isi TM.';
}
