import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_en.dart';
import 'app_localizations_id.dart';
import 'app_localizations_zh.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
    : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations)!;
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
        delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('en'),
    Locale('id'),
    Locale('zh'),
  ];

  /// Nama app di daftar tugas Android
  ///
  /// In id, this message translates to:
  /// **'TerraBot Field'**
  String get appTitle;

  /// No description provided for @navHome.
  ///
  /// In id, this message translates to:
  /// **'Beranda'**
  String get navHome;

  /// No description provided for @navAttendance.
  ///
  /// In id, this message translates to:
  /// **'Absensi'**
  String get navAttendance;

  /// No description provided for @navCasting.
  ///
  /// In id, this message translates to:
  /// **'Cor'**
  String get navCasting;

  /// No description provided for @navQueue.
  ///
  /// In id, this message translates to:
  /// **'Pending'**
  String get navQueue;

  /// No description provided for @navSettings.
  ///
  /// In id, this message translates to:
  /// **'Pengaturan'**
  String get navSettings;

  /// Snackbar saat tab Absensi yang nonaktif ditekan
  ///
  /// In id, this message translates to:
  /// **'Absensi belum aktif — segera hadir.'**
  String get navAttendanceSoon;

  /// No description provided for @comingSoon.
  ///
  /// In id, this message translates to:
  /// **'Segera hadir'**
  String get comingSoon;

  /// Sapaan di kartu atas Beranda
  ///
  /// In id, this message translates to:
  /// **'Halo, {name}'**
  String homeGreeting(String name);

  /// No description provided for @homeTagline.
  ///
  /// In id, this message translates to:
  /// **'Selamat bekerja. Data tersimpan di HP walau tanpa sinyal.'**
  String get homeTagline;

  /// No description provided for @homePickProject.
  ///
  /// In id, this message translates to:
  /// **'Pilih proyek saya'**
  String get homePickProject;

  /// No description provided for @homeAllSent.
  ///
  /// In id, this message translates to:
  /// **'Semua sudah terkirim'**
  String get homeAllSent;

  /// Jumlah dokumen + foto yang menunggu
  ///
  /// In id, this message translates to:
  /// **'{count} belum terkirim'**
  String homePending(int count);

  /// No description provided for @homeWatched.
  ///
  /// In id, this message translates to:
  /// **'Sedang dipantau'**
  String get homeWatched;

  /// No description provided for @homeWatchedCount.
  ///
  /// In id, this message translates to:
  /// **'{count} catatan'**
  String homeWatchedCount(int count);

  /// No description provided for @homeDrillRunning.
  ///
  /// In id, this message translates to:
  /// **'catatan bor berjalan'**
  String get homeDrillRunning;

  /// No description provided for @homeCastRunning.
  ///
  /// In id, this message translates to:
  /// **'catatan cor berjalan'**
  String get homeCastRunning;

  /// Awalan judul kartu: Bor PP.A13
  ///
  /// In id, this message translates to:
  /// **'Bor'**
  String get labelDrill;

  /// Awalan judul kartu: Cor PP.A13
  ///
  /// In id, this message translates to:
  /// **'Cor'**
  String get labelCast;

  /// No description provided for @shortcutAttendance.
  ///
  /// In id, this message translates to:
  /// **'Absen kru'**
  String get shortcutAttendance;

  /// No description provided for @shortcutAttendanceBody.
  ///
  /// In id, this message translates to:
  /// **'Foto masuk & pulang, centang kru yang hadir'**
  String get shortcutAttendanceBody;

  /// No description provided for @shortcutCasting.
  ///
  /// In id, this message translates to:
  /// **'Catatan bor & cor'**
  String get shortcutCasting;

  /// No description provided for @shortcutCastingBody.
  ///
  /// In id, this message translates to:
  /// **'Catat kedalaman bor, TM, tremie & sounding per titik'**
  String get shortcutCastingBody;

  /// No description provided for @shortcutWorkers.
  ///
  /// In id, this message translates to:
  /// **'Pekerja'**
  String get shortcutWorkers;

  /// No description provided for @shortcutWorkersBody.
  ///
  /// In id, this message translates to:
  /// **'Semua pekerja per proyek, daftarkan pekerja baru'**
  String get shortcutWorkersBody;

  /// No description provided for @shortcutReports.
  ///
  /// In id, this message translates to:
  /// **'Laporan lapangan'**
  String get shortcutReports;

  /// No description provided for @shortcutReportsBody.
  ///
  /// In id, this message translates to:
  /// **'Titik yang dibor & dicor hari ini, kemarin, atau seminggu'**
  String get shortcutReportsBody;

  /// No description provided for @settingsLanguage.
  ///
  /// In id, this message translates to:
  /// **'Bahasa'**
  String get settingsLanguage;

  /// No description provided for @settingsLanguageBody.
  ///
  /// In id, this message translates to:
  /// **'Bahasa tampilan app. Istilah teknis lapangan tetap sama di semua bahasa.'**
  String get settingsLanguageBody;

  /// No description provided for @languageSystem.
  ///
  /// In id, this message translates to:
  /// **'Ikut HP'**
  String get languageSystem;

  /// No description provided for @languageIndonesian.
  ///
  /// In id, this message translates to:
  /// **'Indonesia'**
  String get languageIndonesian;

  /// No description provided for @languageEnglish.
  ///
  /// In id, this message translates to:
  /// **'English'**
  String get languageEnglish;

  /// No description provided for @languageChinese.
  ///
  /// In id, this message translates to:
  /// **'中文'**
  String get languageChinese;

  /// Halaman Pengaturan: settingsTitle
  ///
  /// In id, this message translates to:
  /// **'Pengaturan'**
  String get settingsTitle;

  /// Halaman Pengaturan: settingsLevel
  ///
  /// In id, this message translates to:
  /// **'Level {n}'**
  String settingsLevel(String n);

  /// Halaman Pengaturan: sectionAppearance
  ///
  /// In id, this message translates to:
  /// **'Tampilan'**
  String get sectionAppearance;

  /// Halaman Pengaturan: sectionMyProject
  ///
  /// In id, this message translates to:
  /// **'Proyek saya'**
  String get sectionMyProject;

  /// Halaman Pengaturan: sectionNotifications
  ///
  /// In id, this message translates to:
  /// **'Notifikasi'**
  String get sectionNotifications;

  /// Halaman Pengaturan: sectionAccount
  ///
  /// In id, this message translates to:
  /// **'Akun'**
  String get sectionAccount;

  /// Halaman Pengaturan: sectionAbout
  ///
  /// In id, this message translates to:
  /// **'Tentang'**
  String get sectionAbout;

  /// Halaman Pengaturan: settingsTheme
  ///
  /// In id, this message translates to:
  /// **'Tema'**
  String get settingsTheme;

  /// Halaman Pengaturan: themeSystem
  ///
  /// In id, this message translates to:
  /// **'Ikuti HP'**
  String get themeSystem;

  /// Halaman Pengaturan: themeLight
  ///
  /// In id, this message translates to:
  /// **'Terang'**
  String get themeLight;

  /// Halaman Pengaturan: themeDark
  ///
  /// In id, this message translates to:
  /// **'Gelap'**
  String get themeDark;

  /// Halaman Pengaturan: settingsAccent
  ///
  /// In id, this message translates to:
  /// **'Warna aksen'**
  String get settingsAccent;

  /// Halaman Pengaturan: accentBlue
  ///
  /// In id, this message translates to:
  /// **'Biru'**
  String get accentBlue;

  /// Halaman Pengaturan: accentOrange
  ///
  /// In id, this message translates to:
  /// **'Jingga'**
  String get accentOrange;

  /// Halaman Pengaturan: accentTeal
  ///
  /// In id, this message translates to:
  /// **'Teal'**
  String get accentTeal;

  /// Halaman Pengaturan: accentPurple
  ///
  /// In id, this message translates to:
  /// **'Ungu'**
  String get accentPurple;

  /// Halaman Pengaturan: settingsTextSize
  ///
  /// In id, this message translates to:
  /// **'Ukuran teks'**
  String get settingsTextSize;

  /// Halaman Pengaturan: textSizeNormal
  ///
  /// In id, this message translates to:
  /// **'Normal'**
  String get textSizeNormal;

  /// Halaman Pengaturan: textSizeLarge
  ///
  /// In id, this message translates to:
  /// **'Besar'**
  String get textSizeLarge;

  /// Halaman Pengaturan: textSizeHuge
  ///
  /// In id, this message translates to:
  /// **'Sangat besar'**
  String get textSizeHuge;

  /// Halaman Pengaturan: myProjectBodyAttendance
  ///
  /// In id, this message translates to:
  /// **'Absen, pekerja baru dan catatan cor langsung memakai proyek ini. Masih bisa diganti di tiap layar.'**
  String get myProjectBodyAttendance;

  /// Halaman Pengaturan: myProjectBody
  ///
  /// In id, this message translates to:
  /// **'Daftar titik bor & cor langsung membuka proyek ini di urutan teratas.'**
  String get myProjectBody;

  /// Halaman Pengaturan: myProjectSaved
  ///
  /// In id, this message translates to:
  /// **'Proyek saya disimpan.'**
  String get myProjectSaved;

  /// Halaman Pengaturan: myProjectCleared
  ///
  /// In id, this message translates to:
  /// **'Proyek saya dikosongkan.'**
  String get myProjectCleared;

  /// Halaman Pengaturan: projectsLoadFailed
  ///
  /// In id, this message translates to:
  /// **'Daftar proyek gagal dibaca'**
  String get projectsLoadFailed;

  /// Halaman Pengaturan: projectsMissingTitle
  ///
  /// In id, this message translates to:
  /// **'Daftar proyek belum ada di HP'**
  String get projectsMissingTitle;

  /// Halaman Pengaturan: projectsMissingBody
  ///
  /// In id, this message translates to:
  /// **'Tarik ke bawah di Beranda untuk mengambilnya dari server. Perlu sinyal sekali saja.'**
  String get projectsMissingBody;

  /// Halaman Pengaturan: notifTitle
  ///
  /// In id, this message translates to:
  /// **'Pengingat getar'**
  String get notifTitle;

  /// Halaman Pengaturan: notifOn
  ///
  /// In id, this message translates to:
  /// **'Aktif. HP bergetar saat TM lebih dari 20 menit dan selama cor dijeda. Jam tangan yang sudah terhubung ke HP ikut menerima pengingat dan tombol Selesai TM — tanpa setelan tambahan di sini.'**
  String get notifOn;

  /// Halaman Pengaturan: notifOff
  ///
  /// In id, this message translates to:
  /// **'Mati. Ketuk untuk mengizinkan; tanpa ini pengingat saat ngecor tidak muncul.'**
  String get notifOff;

  /// Spanduk beranda: notifBlockedTitle
  ///
  /// In id, this message translates to:
  /// **'Pengingat tidak akan muncul'**
  String get notifBlockedTitle;

  /// Spanduk beranda: notifBlockedBody
  ///
  /// In id, this message translates to:
  /// **'HP ini belum mengizinkan TerraBot Field memunculkan notifikasi. Pengingat TM lewat 20 menit, cor yang dijeda, dan catatan bor yang belum ditutup semuanya tidak akan terdengar. Ketuk Izinkan.'**
  String get notifBlockedBody;

  /// Spanduk beranda: notifAllow
  ///
  /// In id, this message translates to:
  /// **'Izinkan'**
  String get notifAllow;

  /// Spanduk notifikasi diblokir: kalau permintaan izin tidak mengubah apa pun
  ///
  /// In id, this message translates to:
  /// **'Notifikasi masih dimatikan telepon. Buka Setelan telepon → Aplikasi → TerraBot Field → Notifikasi, lalu nyalakan.'**
  String get notifAllowManual;

  /// Halaman Pengaturan: powerTitle
  ///
  /// In id, this message translates to:
  /// **'Baterai & mulai otomatis'**
  String get powerTitle;

  /// Halaman Pengaturan: powerOk
  ///
  /// In id, this message translates to:
  /// **'Tanpa batasan. Pengingat dan kirim otomatis jalan saat layar mati.'**
  String get powerOk;

  /// Halaman Pengaturan: powerRestricted
  ///
  /// In id, this message translates to:
  /// **'Masih dibatasi HP. Ketuk untuk mengatur, supaya pengingat cor tidak terlewat.'**
  String get powerRestricted;

  /// Halaman Pengaturan: reloadPermissions
  ///
  /// In id, this message translates to:
  /// **'Muat ulang hak akses'**
  String get reloadPermissions;

  /// Halaman Pengaturan: reloadPermissionsBody
  ///
  /// In id, this message translates to:
  /// **'Setelah kantor mengubah level atau divisi Anda.'**
  String get reloadPermissionsBody;

  /// Halaman Pengaturan: permissionsReloaded
  ///
  /// In id, this message translates to:
  /// **'Hak akses dimuat ulang.'**
  String get permissionsReloaded;

  /// Halaman Pengaturan: logoutPendingTitle
  ///
  /// In id, this message translates to:
  /// **'Masih ada {docs} data dan {photos} foto belum terkirim'**
  String logoutPendingTitle(int docs, int photos);

  /// Halaman Pengaturan: logoutPendingBody
  ///
  /// In id, this message translates to:
  /// **'Keluar TIDAK menghapusnya; terkirim begitu Anda masuk lagi. Tetapi orang lain yang masuk di HP ini tidak dapat mengirimnya.'**
  String get logoutPendingBody;

  /// Halaman Pengaturan: logout
  ///
  /// In id, this message translates to:
  /// **'Keluar'**
  String get logout;

  /// Halaman Pengaturan: logoutConfirm
  ///
  /// In id, this message translates to:
  /// **'Keluar?'**
  String get logoutConfirm;

  /// Halaman Pengaturan: logoutConfirmBody
  ///
  /// In id, this message translates to:
  /// **'Perlu sinyal untuk masuk lagi.'**
  String get logoutConfirmBody;

  /// Halaman Pengaturan: cancel
  ///
  /// In id, this message translates to:
  /// **'Batal'**
  String get cancel;

  /// Halaman Pengaturan: appVersion
  ///
  /// In id, this message translates to:
  /// **'Versi aplikasi'**
  String get appVersion;

  /// serverLabel
  ///
  /// In id, this message translates to:
  /// **'Server {host}'**
  String serverLabel(String host);

  /// Halaman Pengaturan: deviceIdLabel
  ///
  /// In id, this message translates to:
  /// **'ID perangkat {id}'**
  String deviceIdLabel(String id);

  /// Halaman Pengaturan: sendLog
  ///
  /// In id, this message translates to:
  /// **'Kirim catatan masalah ke admin'**
  String get sendLog;

  /// Halaman Pengaturan: sendLogBody
  ///
  /// In id, this message translates to:
  /// **'Bila aplikasi bermasalah: catatan masalah dari HP ini, tanpa data pribadi.'**
  String get sendLogBody;

  /// Halaman Pengaturan: noLogYet
  ///
  /// In id, this message translates to:
  /// **'Belum ada catatan masalah di HP ini.'**
  String get noLogYet;

  /// Halaman Pengaturan: logShareFailed
  ///
  /// In id, this message translates to:
  /// **'Catatan masalah gagal dibagikan: {error}'**
  String logShareFailed(String error);

  /// AppBar layar cor
  ///
  /// In id, this message translates to:
  /// **'Catatan pengecoran'**
  String get castingTitle;

  /// projectsLoadError
  ///
  /// In id, this message translates to:
  /// **'Proyek gagal dibaca'**
  String get projectsLoadError;

  /// pickProject
  ///
  /// In id, this message translates to:
  /// **'Pilih proyek'**
  String get pickProject;

  /// pickProjectBody
  ///
  /// In id, this message translates to:
  /// **'Titik bor diisi kantor dari gambar kerja'**
  String get pickProjectBody;

  /// noCastingProjects
  ///
  /// In id, this message translates to:
  /// **'Belum ada proyek cor di HP. Tarik ke bawah saat ada sinyal.'**
  String get noCastingProjects;

  /// myProjectTag
  ///
  /// In id, this message translates to:
  /// **'PROYEK SAYA'**
  String get myProjectTag;

  /// pointCount
  ///
  /// In id, this message translates to:
  /// **'{n} titik'**
  String pointCount(int n);

  /// pointsTitle
  ///
  /// In id, this message translates to:
  /// **'Titik bor'**
  String get pointsTitle;

  /// pointsTitleOf
  ///
  /// In id, this message translates to:
  /// **'{code} · titik bor'**
  String pointsTitleOf(String code);

  /// toTop
  ///
  /// In id, this message translates to:
  /// **'Ke atas'**
  String get toTop;

  /// pointsLoadError
  ///
  /// In id, this message translates to:
  /// **'Titik gagal dibaca'**
  String get pointsLoadError;

  /// noPointsTitle
  ///
  /// In id, this message translates to:
  /// **'Belum ada titik bor'**
  String get noPointsTitle;

  /// noPointsBody
  ///
  /// In id, this message translates to:
  /// **'Titik bor diisi kantor (impor Excel di TerraBot web). Tarik ke bawah di halaman sebelumnya untuk mengambil yang terbaru.'**
  String get noPointsBody;

  /// searchPointCode
  ///
  /// In id, this message translates to:
  /// **'Cari kode titik'**
  String get searchPointCode;

  /// clear
  ///
  /// In id, this message translates to:
  /// **'Hapus'**
  String get clear;

  /// filterAll
  ///
  /// In id, this message translates to:
  /// **'Semua'**
  String get filterAll;

  /// filterUndrilled
  ///
  /// In id, this message translates to:
  /// **'Belum bor'**
  String get filterUndrilled;

  /// filterDrilled
  ///
  /// In id, this message translates to:
  /// **'Dibor'**
  String get filterDrilled;

  /// filterCast
  ///
  /// In id, this message translates to:
  /// **'Dicor'**
  String get filterCast;

  /// castProgress
  ///
  /// In id, this message translates to:
  /// **'{done} dari {total} titik sudah dicor'**
  String castProgress(int done, int total);

  /// noMatchingPoints
  ///
  /// In id, this message translates to:
  /// **'Tidak ada titik yang cocok.'**
  String get noMatchingPoints;

  /// stageCasting
  ///
  /// In id, this message translates to:
  /// **'Sedang dicor'**
  String get stageCasting;

  /// stageCast
  ///
  /// In id, this message translates to:
  /// **'Sudah dicor'**
  String get stageCast;

  /// stageDrilled
  ///
  /// In id, this message translates to:
  /// **'Dibor {depth}'**
  String stageDrilled(String depth);

  /// stageDrilling
  ///
  /// In id, this message translates to:
  /// **'Sedang dibor'**
  String get stageDrilling;

  /// stageUndrilled
  ///
  /// In id, this message translates to:
  /// **'Belum dibor'**
  String get stageUndrilled;

  /// gsMissingShort
  ///
  /// In id, this message translates to:
  /// **'GS belum diisi'**
  String get gsMissingShort;

  /// pointHeading
  ///
  /// In id, this message translates to:
  /// **'Titik {code}'**
  String pointHeading(String code);

  /// fieldDiameter
  ///
  /// In id, this message translates to:
  /// **'Diameter'**
  String get fieldDiameter;

  /// fieldLevels
  ///
  /// In id, this message translates to:
  /// **'GS / cut-off / tip'**
  String get fieldLevels;

  /// fieldCutOffDepth
  ///
  /// In id, this message translates to:
  /// **'Kedalaman cut-off dari GS'**
  String get fieldCutOffDepth;

  /// fieldPlannedDrill
  ///
  /// In id, this message translates to:
  /// **'Panjang bor rencana'**
  String get fieldPlannedDrill;

  /// fieldPlannedEff
  ///
  /// In id, this message translates to:
  /// **'Panjang efektif rencana'**
  String get fieldPlannedEff;

  /// fieldPlannedVol
  ///
  /// In id, this message translates to:
  /// **'Volume beton rencana'**
  String get fieldPlannedVol;

  /// fieldActualDrill
  ///
  /// In id, this message translates to:
  /// **'Kedalaman bor aktual'**
  String get fieldActualDrill;

  /// gsMissingTitle
  ///
  /// In id, this message translates to:
  /// **'Elevasi GS belum diisi'**
  String get gsMissingTitle;

  /// gsMissingBody
  ///
  /// In id, this message translates to:
  /// **'Kedalaman dari GS belum dapat dihitung, dan catatan cor baru bisa dimulai setelah GS terisi. Isi GS saat menandai titik ini sudah dibor.'**
  String get gsMissingBody;

  /// notFilled
  ///
  /// In id, this message translates to:
  /// **'belum diisi'**
  String get notFilled;

  /// castLogExists
  ///
  /// In id, this message translates to:
  /// **'Titik ini sudah punya catatan cor'**
  String get castLogExists;

  /// castLogOnMyOther
  ///
  /// In id, this message translates to:
  /// **'Catatan cornya ada di HP Anda yang lain'**
  String get castLogOnMyOther;

  /// castLogElsewhere
  ///
  /// In id, this message translates to:
  /// **'Sedang dicor dari HP lain'**
  String get castLogElsewhere;

  /// castLogHeldBody
  ///
  /// In id, this message translates to:
  /// **'{who} yang memegang catatan cornya. Satu titik hanya boleh satu catatan cor. Bila catatan itu salah, minta kantor menghapusnya dulu.'**
  String castLogHeldBody(String who);

  /// logIsMineBody
  ///
  /// In id, this message translates to:
  /// **'Catatan ini dipegang akun Anda sendiri, hanya isinya belum ada di HP ini. Ambil langsung ke sini tanpa kode oper.'**
  String get logIsMineBody;

  /// castLogHandoverBody
  ///
  /// In id, this message translates to:
  /// **'{who} yang memegang catatan cornya. Satu titik hanya boleh satu catatan cor. Untuk melanjutkan dari HP ini, minta dia menekan \"Oper ke rekan\" lalu masukkan kodenya di sini.'**
  String castLogHandoverBody(String who);

  /// takeToThisPhone
  ///
  /// In id, this message translates to:
  /// **'Ambil ke HP ini'**
  String get takeToThisPhone;

  /// continueHereCode
  ///
  /// In id, this message translates to:
  /// **'Lanjutkan di HP ini (kode oper)'**
  String get continueHereCode;

  /// drillLogOnMyOther
  ///
  /// In id, this message translates to:
  /// **'Catatan bornya ada di HP Anda yang lain'**
  String get drillLogOnMyOther;

  /// drillLogElsewhere
  ///
  /// In id, this message translates to:
  /// **'Sedang dibor dari HP lain'**
  String get drillLogElsewhere;

  /// drillLogHandoverBody
  ///
  /// In id, this message translates to:
  /// **'Catatan bornya dipegang {who}. Satu titik hanya boleh satu catatan bor. Untuk melanjutkan dari HP ini, minta dia menekan \"Oper ke rekan\" lalu masukkan kodenya di sini.'**
  String drillLogHandoverBody(String who);

  /// drillFirstTitle
  ///
  /// In id, this message translates to:
  /// **'Catat bor dulu'**
  String get drillFirstTitle;

  /// castAfterDrillLog
  ///
  /// In id, this message translates to:
  /// **'Catatan cor bisa dimulai setelah catatan bor ditutup dengan \"Selesai bor\".'**
  String get castAfterDrillLog;

  /// castAfterDrilled
  ///
  /// In id, this message translates to:
  /// **'Catatan cor baru bisa dimulai setelah titik ini selesai dibor: lewat catatan bor, atau tandai langsung.'**
  String get castAfterDrilled;

  /// viewOnlyTitle
  ///
  /// In id, this message translates to:
  /// **'Hanya dapat dilihat'**
  String get viewOnlyTitle;

  /// viewOnlyCastBody
  ///
  /// In id, this message translates to:
  /// **'Akun ini tidak berhak mencatat catatan cor.'**
  String get viewOnlyCastBody;

  /// continueDrillLog
  ///
  /// In id, this message translates to:
  /// **'Lanjutkan catatan bor'**
  String get continueDrillLog;

  /// viewDrillLog
  ///
  /// In id, this message translates to:
  /// **'Lihat catatan bor'**
  String get viewDrillLog;

  /// startDrillLog
  ///
  /// In id, this message translates to:
  /// **'Mulai catatan bor'**
  String get startDrillLog;

  /// markDrilledNoLog
  ///
  /// In id, this message translates to:
  /// **'Tandai sudah dibor (tanpa catatan)'**
  String get markDrilledNoLog;

  /// correctDrillGs
  ///
  /// In id, this message translates to:
  /// **'Koreksi kedalaman bor / GS'**
  String get correctDrillGs;

  /// openCastLog
  ///
  /// In id, this message translates to:
  /// **'Buka catatan cor'**
  String get openCastLog;

  /// startCastLog
  ///
  /// In id, this message translates to:
  /// **'Mulai catatan cor'**
  String get startCastLog;

  /// Dialog konfirmasi nomor titik: confirmPointCodeTitle
  ///
  /// In id, this message translates to:
  /// **'Ketik nomor titiknya'**
  String get confirmPointCodeTitle;

  /// Dialog konfirmasi nomor titik: confirmPointCodeBody
  ///
  /// In id, this message translates to:
  /// **'Lihat tiang yang akan Anda cor, jangan daftar di HP. Nomor yang Anda ketik inilah yang menjaga catatan ini tidak masuk ke titik sebelah.'**
  String get confirmPointCodeBody;

  /// Dialog konfirmasi nomor titik: confirmPointCodeField
  ///
  /// In id, this message translates to:
  /// **'Nomor titik'**
  String get confirmPointCodeField;

  /// Dialog konfirmasi nomor titik: confirmPointCodeConfirm
  ///
  /// In id, this message translates to:
  /// **'Benar, mulai cor'**
  String get confirmPointCodeConfirm;

  /// Dialog konfirmasi nomor titik: confirmPointCodeMismatch
  ///
  /// In id, this message translates to:
  /// **'Di daftar Anda memilih {selected}, yang Anda ketik {typed}. Kalau yang benar {typed}, tutup ini lalu pilih titik itu di daftar.'**
  String confirmPointCodeMismatch(String selected, String typed);

  /// colleague
  ///
  /// In id, this message translates to:
  /// **'Rekan'**
  String get colleague;

  /// markedDrilled
  ///
  /// In id, this message translates to:
  /// **'{code} ditandai sudah dibor {depth}.'**
  String markedDrilled(String code, String depth);

  /// gsInvalid
  ///
  /// In id, this message translates to:
  /// **'Elevasi GS tidak sah.'**
  String get gsInvalid;

  /// gsRequiredMsg
  ///
  /// In id, this message translates to:
  /// **'Isi elevasi GS titik ini. Catatan cor tidak dapat dimulai tanpanya.'**
  String get gsRequiredMsg;

  /// drillDepthInvalid
  ///
  /// In id, this message translates to:
  /// **'Isi kedalaman bor (m), lebih dari 0.'**
  String get drillDepthInvalid;

  /// drillDepthTooDeep
  ///
  /// In id, this message translates to:
  /// **'Kedalaman paling dalam {max}. Periksa angkanya.'**
  String drillDepthTooDeep(String max);

  /// markDrilledTitle
  ///
  /// In id, this message translates to:
  /// **'Tandai dibor {code}'**
  String markDrilledTitle(String code);

  /// checkInput
  ///
  /// In id, this message translates to:
  /// **'Periksa isian'**
  String get checkInput;

  /// gsFieldRequired
  ///
  /// In id, this message translates to:
  /// **'Elevasi GS (m) — wajib'**
  String get gsFieldRequired;

  /// gsField
  ///
  /// In id, this message translates to:
  /// **'Elevasi GS (m)'**
  String get gsField;

  /// cutOffAboveGsTitle
  ///
  /// In id, this message translates to:
  /// **'Cut-off di atas GS'**
  String get cutOffAboveGsTitle;

  /// cutOffAboveGsBody
  ///
  /// In id, this message translates to:
  /// **'COL {col} lebih tinggi dari GS ini. Pastikan angka GS benar sebelum menyimpan.'**
  String cutOffAboveGsBody(String col);

  /// drillDepthField
  ///
  /// In id, this message translates to:
  /// **'Kedalaman bor (m)'**
  String get drillDepthField;

  /// beyondPlanTitle
  ///
  /// In id, this message translates to:
  /// **'Sudah lewat {over} dari rencana'**
  String beyondPlanTitle(String over);

  /// beyondPlanBody
  ///
  /// In id, this message translates to:
  /// **'Rencana {planned}. Lewat sedikit boleh; pastikan memang perlu dibor lebih dalam.'**
  String beyondPlanBody(String planned);

  /// save
  ///
  /// In id, this message translates to:
  /// **'Simpan'**
  String get save;

  /// drillLogWord
  ///
  /// In id, this message translates to:
  /// **'catatan bor'**
  String get drillLogWord;

  /// castLogWord
  ///
  /// In id, this message translates to:
  /// **'catatan cor'**
  String get castLogWord;

  /// sendingFirst
  ///
  /// In id, this message translates to:
  /// **'Mengirim {log} dulu…'**
  String sendingFirst(String log);

  /// sendBeforeHandoverTitle
  ///
  /// In id, this message translates to:
  /// **'Kirim dulu sebelum oper'**
  String get sendBeforeHandoverTitle;

  /// sendBeforeHandoverBody
  ///
  /// In id, this message translates to:
  /// **'Isi {log} ini belum sampai ke server, jadi belum bisa dioper. Cari sinyal sebentar, lalu coba lagi — rekan menerima persis isi terakhir.'**
  String sendBeforeHandoverBody(String log);

  /// understood
  ///
  /// In id, this message translates to:
  /// **'Mengerti'**
  String get understood;

  /// askingCode
  ///
  /// In id, this message translates to:
  /// **'Meminta kode oper…'**
  String get askingCode;

  /// handoverTitle
  ///
  /// In id, this message translates to:
  /// **'Oper {log} {code}'**
  String handoverTitle(String log, String code);

  /// handoverBody
  ///
  /// In id, this message translates to:
  /// **'Minta rekan membuka titik {code} di HP-nya dan memilih \"Lanjutkan di HP ini\", lalu sebutkan kode ini:'**
  String handoverBody(String code);

  /// codeValidFor
  ///
  /// In id, this message translates to:
  /// **'Berlaku {minutes} menit, sekali pakai'**
  String codeValidFor(int minutes);

  /// codeValidBody
  ///
  /// In id, this message translates to:
  /// **'Begitu rekan memasukkannya, catatan pindah ke dia dan HP ini hanya bisa melihat. Foto yang diambil di HP ini tetap terkirim dari sini.'**
  String get codeValidBody;

  /// done
  ///
  /// In id, this message translates to:
  /// **'Selesai'**
  String get done;

  /// takeLogHere
  ///
  /// In id, this message translates to:
  /// **'Ambil {log} {code} ke HP ini'**
  String takeLogHere(String log, String code);

  /// takeLogHereBody
  ///
  /// In id, this message translates to:
  /// **'{log} ini memang dipegang akun Anda, hanya isinya belum ada di HP ini. Tidak perlu kode oper.\n\nBila catatan ini sedang terbuka di HP Anda yang lain, lanjutkan di SATU HP saja supaya isiannya tidak bertabrakan.'**
  String takeLogHereBody(String log);

  /// takingLog
  ///
  /// In id, this message translates to:
  /// **'Mengambil {log}…'**
  String takingLog(String log);

  /// logNowHere
  ///
  /// In id, this message translates to:
  /// **'{log} {code} sekarang dipegang HP ini.'**
  String logNowHere(String log, String code);

  /// continueLog
  ///
  /// In id, this message translates to:
  /// **'Lanjutkan {log} {code}'**
  String continueLog(String log, String code);

  /// enterHandoverCode
  ///
  /// In id, this message translates to:
  /// **'Masukkan kode oper 6 angka yang disebutkan pemegang catatannya (dia menekan \"Oper ke rekan\" di HP-nya).'**
  String get enterHandoverCode;

  /// takeOver
  ///
  /// In id, this message translates to:
  /// **'Ambil alih'**
  String get takeOver;

  /// castLogNotOnPhone
  ///
  /// In id, this message translates to:
  /// **'Catatan cor tidak ditemukan di HP ini.'**
  String get castLogNotOnPhone;

  /// pointNotOnPhone
  ///
  /// In id, this message translates to:
  /// **'Titik bor tidak ada di HP ini. Tarik data terbaru saat ada sinyal.'**
  String get pointNotOnPhone;

  /// gsMissingFor
  ///
  /// In id, this message translates to:
  /// **'Elevasi GS titik {code} belum diisi. Kembali ke daftar titik, pilih \"Tandai sudah dibor\", lalu isi GS-nya.'**
  String gsMissingFor(String code);

  /// pointHasCastLog
  ///
  /// In id, this message translates to:
  /// **'Titik {code} sudah punya catatan cor{by}. Satu titik hanya boleh satu catatan cor.'**
  String pointHasCastLog(String code, String by);

  /// byWhom
  ///
  /// In id, this message translates to:
  /// **' dari {who}'**
  String byWhom(String who);

  /// pointNotDrilled
  ///
  /// In id, this message translates to:
  /// **'Titik {code} belum ditandai sudah dibor. Kembali ke daftar titik, pilih \"Tandai sudah dibor\", lalu isi kedalamannya.'**
  String pointNotDrilled(String code);

  /// notSignedIn
  ///
  /// In id, this message translates to:
  /// **'Belum masuk akun — tidak ada yang tersimpan.'**
  String get notSignedIn;

  /// lockedByOffice
  ///
  /// In id, this message translates to:
  /// **'Catatan cor sudah diperiksa kantor — tidak dapat diubah lagi.'**
  String get lockedByOffice;

  /// heldByOther
  ///
  /// In id, this message translates to:
  /// **'Catatan cor ini dipegang {who} — ubah dari HP pemegangnya.'**
  String heldByOther(String who);

  /// tremieTooLongTitle
  ///
  /// In id, this message translates to:
  /// **'Tremie kepanjangan'**
  String get tremieTooLongTitle;

  /// tremieTooLongAdd
  ///
  /// In id, this message translates to:
  /// **'Dengan pipa {len} m ini, ujung atas tremie {stick} di atas GS (paling tinggi {max}, setinggi hopper). Lubang ini cukup {need} tremie. Periksa lagi pipa yang terpasang.'**
  String tremieTooLongAdd(String len, String stick, String max, String need);

  /// tremieBottomTitle
  ///
  /// In id, this message translates to:
  /// **'Tremie bottom'**
  String get tremieBottomTitle;

  /// lengthM
  ///
  /// In id, this message translates to:
  /// **'Panjang (m)'**
  String get lengthM;

  /// tremieBottomHint
  ///
  /// In id, this message translates to:
  /// **'Ujung runcing yang dipasang paling bawah. Ukur panjangnya untuk cor ini.'**
  String get tremieBottomHint;

  /// topSegmentRemoved
  ///
  /// In id, this message translates to:
  /// **'Pipa tremie paling atas dihapus dari susunan.'**
  String get topSegmentRemoved;

  /// segmentLength
  ///
  /// In id, this message translates to:
  /// **'Panjang pipa tremie'**
  String get segmentLength;

  /// dontPullYet
  ///
  /// In id, this message translates to:
  /// **'Jangan dicabut dulu'**
  String get dontPullYet;

  /// embedTooShortTitle
  ///
  /// In id, this message translates to:
  /// **'Tremie kurang tertanam'**
  String get embedTooShortTitle;

  /// embedAfterRemoval
  ///
  /// In id, this message translates to:
  /// **'Setelah pipa {len} m ini dicabut, tremie tinggal tertanam {after} di beton (paling sedikit {min}). Beton baru bisa menembus muka beton dan bercampur lumpur.'**
  String embedAfterRemoval(String len, String after, String min);

  /// estimateSoundFirst
  ///
  /// In id, this message translates to:
  /// **'{text}\n\nMuka beton ini perkiraan. Sounding dulu kalau ragu.'**
  String estimateSoundFirst(String text);

  /// tickAnyway
  ///
  /// In id, this message translates to:
  /// **'Tetap centang'**
  String get tickAnyway;

  /// pullUndone
  ///
  /// In id, this message translates to:
  /// **'Cabut dibatalkan; pipa tremienya terpasang lagi.'**
  String get pullUndone;

  /// pullTickTitle
  ///
  /// In id, this message translates to:
  /// **'Tandai tremie tercabut?'**
  String get pullTickTitle;

  /// pullTickBody
  ///
  /// In id, this message translates to:
  /// **'Pipa #{pos} ({panjang} m) akan tercatat dicabut setelah TM #{seq}, dan tremie tertanam menjadi {sisa}. Catatan ini masuk Piling Record sebagai bukti.'**
  String pullTickBody(int pos, String panjang, int seq, String sisa);

  /// pullTickAfterPour
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} sudah selesai dituang. Kalau tremienya tidak benar-benar dicabut, jangan ditandai.'**
  String pullTickAfterPour(int seq);

  /// pullRecorded
  ///
  /// In id, this message translates to:
  /// **'Pipa tremie tercatat dicabut setelah TM #{seq}.'**
  String pullRecorded(int seq);

  /// truckSaved
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} tersimpan.'**
  String truckSaved(int seq);

  /// truckUpdated
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} diperbarui.'**
  String truckUpdated(int seq);

  /// atCutOffTitle
  ///
  /// In id, this message translates to:
  /// **'Beton sudah sampai cut-off'**
  String get atCutOffTitle;

  /// atCutOffBody
  ///
  /// In id, this message translates to:
  /// **'Muka beton {level} dari GS, cut-off {cutoff}{over}. Biasanya cor titik ini sudah cukup.'**
  String atCutOffBody(String level, String cutoff, String over);

  /// overBy
  ///
  /// In id, this message translates to:
  /// **' (lebih {over})'**
  String overBy(String over);

  /// estimateFromVolume
  ///
  /// In id, this message translates to:
  /// **'Angka ini perkiraan dari volume. Sounding dulu untuk memastikan.'**
  String get estimateFromVolume;

  /// finishCasting
  ///
  /// In id, this message translates to:
  /// **'Selesai cor'**
  String get finishCasting;

  /// addTruckAnyway
  ///
  /// In id, this message translates to:
  /// **'Tetap tambah TM'**
  String get addTruckAnyway;

  /// soundingAfter
  ///
  /// In id, this message translates to:
  /// **'Sounding setelah TM #{seq}'**
  String soundingAfter(String seq);

  /// soundingBefore
  ///
  /// In id, this message translates to:
  /// **'Sounding sebelum TM #{seq}'**
  String soundingBefore(String seq);

  /// Plain-words question above the sounding field; 'sounding' alone is a word, not an instruction
  ///
  /// In id, this message translates to:
  /// **'Dari muka tanah turun ke muka beton, berapa meter?'**
  String get soundingQuestion;

  /// concreteDepthField
  ///
  /// In id, this message translates to:
  /// **'Dari muka tanah ke muka beton'**
  String get concreteDepthField;

  /// soundingHint
  ///
  /// In id, this message translates to:
  /// **'Wajib diukur. Perkiraan dari volume: {est}.'**
  String soundingHint(String est);

  /// soundingMissing
  ///
  /// In id, this message translates to:
  /// **'Sounding TM #{seq} belum diisi. Wajib sebelum TM berikutnya.'**
  String soundingMissing(int seq);

  /// truckStartTime
  ///
  /// In id, this message translates to:
  /// **'Jam mulai TM #{seq}'**
  String truckStartTime(String seq);

  /// truckEndTime
  ///
  /// In id, this message translates to:
  /// **'Jam selesai TM #{seq}'**
  String truckEndTime(String seq);

  /// soundingCleared
  ///
  /// In id, this message translates to:
  /// **'Sounding TM #{seq} dikosongkan.'**
  String soundingCleared(String seq);

  /// soundingSaved
  ///
  /// In id, this message translates to:
  /// **'Sounding TM #{seq} tersimpan: {value}.'**
  String soundingSaved(String seq, String value);

  /// tremieNotAtBottom
  ///
  /// In id, this message translates to:
  /// **'Tremie belum sampai dasar'**
  String get tremieNotAtBottom;

  /// tremieTooLongNow
  ///
  /// In id, this message translates to:
  /// **'Terpasang {fitted}, ujung atasnya {stick} di atas GS (paling tinggi {max}). Lubang ini cukup {need}. Hapus pipa yang berlebih dulu.'**
  String tremieTooLongNow(String fitted, String stick, String max, String need);

  /// tremieShortBody
  ///
  /// In id, this message translates to:
  /// **'Terpasang {fitted}, perlu {need} (dasar lubang dikurangi celah). Tambah pipa tremie dulu: beton yang jatuh dari atas akan bercampur lumpur.'**
  String tremieShortBody(String fitted, String need);

  /// notifPouring
  ///
  /// In id, this message translates to:
  /// **'Mengecor TM #{seq}'**
  String notifPouring(String seq);

  /// notifTapToOpen
  ///
  /// In id, this message translates to:
  /// **'{vol} m³ · ketuk untuk membuka catatan cor'**
  String notifTapToOpen(String vol);

  /// pourStarted
  ///
  /// In id, this message translates to:
  /// **'Cor TM #{seq} dimulai. Jamnya berjalan di notifikasi.'**
  String pourStarted(String seq);

  /// notifTruckLate
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} sudah {min} menit · {code}'**
  String notifTruckLate(String seq, int min, String code);

  /// notifTruckLateBody
  ///
  /// In id, this message translates to:
  /// **'Belum selesai dicor. Cek muka beton dan posisi tremie.'**
  String get notifTruckLateBody;

  /// notifPausedTitle
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} dijeda'**
  String notifPausedTitle(int seq);

  /// notifPausedBody
  ///
  /// In id, this message translates to:
  /// **'{reason} · ketuk untuk melanjutkan'**
  String notifPausedBody(String reason);

  /// notifStillPaused
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} masih dijeda · {code}'**
  String notifStillPaused(int seq, String code);

  /// notifStillPausedBody
  ///
  /// In id, this message translates to:
  /// **'Sudah lanjut cor? Ketuk Lanjut di catatan cor'**
  String get notifStillPausedBody;

  /// pourPaused
  ///
  /// In id, this message translates to:
  /// **'Cor dijeda: {reason}.'**
  String pourPaused(String reason);

  /// pourResumed
  ///
  /// In id, this message translates to:
  /// **'Cor TM #{seq} dilanjutkan.'**
  String pourResumed(int seq);

  /// notifNoNextTruck
  ///
  /// In id, this message translates to:
  /// **'Belum ada TM berikutnya · {code}'**
  String notifNoNextTruck(String code);

  /// notifNoNextTruckBody
  ///
  /// In id, this message translates to:
  /// **'Awas sambungan dingin. Cek kapan TM datang'**
  String get notifNoNextTruckBody;

  /// truckFinished
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} selesai dicor.'**
  String truckFinished(int seq);

  /// castDataSaved
  ///
  /// In id, this message translates to:
  /// **'Data cor disimpan.'**
  String get castDataSaved;

  /// finishNotStored
  ///
  /// In id, this message translates to:
  /// **'Status selesai belum tersimpan. Coba tekan \"Selesai cor\" sekali lagi.'**
  String get finishNotStored;

  /// castFinished
  ///
  /// In id, this message translates to:
  /// **'Cor {code} selesai. Terkirim otomatis saat ada sinyal.'**
  String castFinished(String code);

  /// castReopened
  ///
  /// In id, this message translates to:
  /// **'Catatan cor dibuka lagi. Jangan lupa Selesai cor setelah beres.'**
  String get castReopened;

  /// cleanTremieTitle
  ///
  /// In id, this message translates to:
  /// **'Bersihkan tremie & hopper'**
  String get cleanTremieTitle;

  /// beforeNextUse
  ///
  /// In id, this message translates to:
  /// **'Sebelum dipakai lagi'**
  String get beforeNextUse;

  /// cleanWhy
  ///
  /// In id, this message translates to:
  /// **'Sisa beton yang mengeras di dalam pipa atau sambungan bisa menyumbat tremie saat cor berikutnya.'**
  String get cleanWhy;

  /// cleanStep1
  ///
  /// In id, this message translates to:
  /// **'Siram/semprot hopper dan tiap pipa tremie sampai bersih dari sisa beton.'**
  String get cleanStep1;

  /// cleanStep2
  ///
  /// In id, this message translates to:
  /// **'Bersihkan sambungan dan karet seal; ganti seal yang rusak.'**
  String get cleanStep2;

  /// cleanStep3
  ///
  /// In id, this message translates to:
  /// **'Lakukan segera, sebelum sisa beton mengeras.'**
  String get cleanStep3;

  /// cleanStep4
  ///
  /// In id, this message translates to:
  /// **'Susun kembali di tempatnya, jangan tergeletak di tanah.'**
  String get cleanStep4;

  /// cleanedOk
  ///
  /// In id, this message translates to:
  /// **'Siap, dibersihkan'**
  String get cleanedOk;

  /// castOf
  ///
  /// In id, this message translates to:
  /// **'Cor {code}'**
  String castOf(String code);

  /// handOverToMate
  ///
  /// In id, this message translates to:
  /// **'Oper ke rekan'**
  String get handOverToMate;

  /// handedOverTo
  ///
  /// In id, this message translates to:
  /// **'Dioper ke {who}'**
  String handedOverTo(String who);

  /// handedOverBody
  ///
  /// In id, this message translates to:
  /// **'Catatan cor ini dilanjutkan dari HP {who}. Di HP ini hanya bisa dilihat; perubahan dibuat di HP pemegangnya.'**
  String handedOverBody(String who);

  /// rejectedByServer
  ///
  /// In id, this message translates to:
  /// **'Ditolak server'**
  String get rejectedByServer;

  /// reviewedByOffice
  ///
  /// In id, this message translates to:
  /// **'Sudah diperiksa kantor'**
  String get reviewedByOffice;

  /// officeNote
  ///
  /// In id, this message translates to:
  /// **'Catatan: {note}'**
  String officeNote(String note);

  /// cannotChangeAnymore
  ///
  /// In id, this message translates to:
  /// **'Catatan cor ini tidak dapat diubah lagi.'**
  String get cannotChangeAnymore;

  /// gradeMissingTitle
  ///
  /// In id, this message translates to:
  /// **'Mutu beton belum diisi'**
  String get gradeMissingTitle;

  /// gradeMissingBody
  ///
  /// In id, this message translates to:
  /// **'Titik dan proyek ini belum punya mutu bawaan. Isi di data cor, atau catatan cor akan ditolak server.'**
  String get gradeMissingBody;

  /// No description provided for @finishNeedsGrade.
  ///
  /// In id, this message translates to:
  /// **'Isi mutu dulu'**
  String get finishNeedsGrade;

  /// fill
  ///
  /// In id, this message translates to:
  /// **'Isi'**
  String get fill;

  /// drillDepthUnmarked
  ///
  /// In id, this message translates to:
  /// **'Kedalaman bor belum ditandai'**
  String get drillDepthUnmarked;

  /// drillDepthUnmarkedBody
  ///
  /// In id, this message translates to:
  /// **'Hitungan memakai panjang bor RENCANA. Tandai kedalaman aktual dari daftar titik supaya saran potong tepat.'**
  String get drillDepthUnmarkedBody;

  /// tremieSection
  ///
  /// In id, this message translates to:
  /// **'Tremie'**
  String get tremieSection;

  /// tremieSectionBody
  ///
  /// In id, this message translates to:
  /// **'Pipa bawah → atas. Ujung bawah {gap} di atas dasar lubang.'**
  String tremieSectionBody(String gap);

  /// trucksSection
  ///
  /// In id, this message translates to:
  /// **'Truk mixer (TM)'**
  String get trucksSection;

  /// trucksSectionBody
  ///
  /// In id, this message translates to:
  /// **'{n} TM · {vol} m³'**
  String trucksSectionBody(int n, String vol);

  /// noTrucksYet
  ///
  /// In id, this message translates to:
  /// **'Belum ada TM'**
  String get noTrucksYet;

  /// noTrucksReadOnly
  ///
  /// In id, this message translates to:
  /// **'Catatan cor ini tidak punya TM.'**
  String get noTrucksReadOnly;

  /// noTrucksTremieFirst
  ///
  /// In id, this message translates to:
  /// **'Susun tremie dulu, lalu tekan \"TM #1 datang\" saat truk pertama tiba.'**
  String get noTrucksTremieFirst;

  /// noTrucksTapArrived
  ///
  /// In id, this message translates to:
  /// **'Tekan \"TM #1 datang\" di bawah saat truk pertama tiba.'**
  String get noTrucksTapArrived;

  /// pause
  ///
  /// In id, this message translates to:
  /// **'Jeda'**
  String get pause;

  /// resume
  ///
  /// In id, this message translates to:
  /// **'Lanjut'**
  String get resume;

  /// finishTruck
  ///
  /// In id, this message translates to:
  /// **'Selesai TM #{seq}'**
  String finishTruck(String seq);

  /// startTruck
  ///
  /// In id, this message translates to:
  /// **'Mulai cor TM #{seq}'**
  String startTruck(String seq);

  /// tremieFirst
  ///
  /// In id, this message translates to:
  /// **'Susun tremie dulu'**
  String get tremieFirst;

  /// truckArrived
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} datang'**
  String truckArrived(int seq);

  /// castDone
  ///
  /// In id, this message translates to:
  /// **'Cor selesai'**
  String get castDone;

  /// savedAutoSend
  ///
  /// In id, this message translates to:
  /// **'Tersimpan. Dikirim otomatis.'**
  String get savedAutoSend;

  /// reopen
  ///
  /// In id, this message translates to:
  /// **'Buka lagi'**
  String get reopen;

  /// planNoPull
  ///
  /// In id, this message translates to:
  /// **'Rencana TM #{seq}: tidak perlu cabut'**
  String planNoPull(int seq);

  /// planTitle
  ///
  /// In id, this message translates to:
  /// **'Rencana TM #{seq}'**
  String planTitle(int seq);

  /// planCutLine
  ///
  /// In id, this message translates to:
  /// **'• Setelah ±{vol} m³: cabut {which} → tremie tertanam {before} → {after} m'**
  String planCutLine(String vol, String which, String before, String after);

  /// joinThen
  ///
  /// In id, this message translates to:
  /// **' lalu '**
  String get joinThen;

  /// warnEmbedShort
  ///
  /// In id, this message translates to:
  /// **'⚠ Tremie tertanam sebelum TM ini hanya {emb} m — periksa sounding.'**
  String warnEmbedShort(String emb);

  /// warnNoSafePull
  ///
  /// In id, this message translates to:
  /// **'⚠ Setelah ±{vol} m³ tremie tertanam lebih dari 6 m dan tidak ada pipa yang aman dicabut.'**
  String warnNoSafePull(String vol);

  /// planEnd
  ///
  /// In id, this message translates to:
  /// **'Perkiraan akhir TM: muka beton {level}, tremie tertanam {emb}{cut}.'**
  String planEnd(String level, String emb, String cut);

  /// cutOffReachedSuffix
  ///
  /// In id, this message translates to:
  /// **' — cut-off tercapai'**
  String get cutOffReachedSuffix;

  /// usingOverbreak
  ///
  /// In id, this message translates to:
  /// **'Memakai angka pelebaran lubang {ratio} dari sounding TM sebelumnya.'**
  String usingOverbreak(String ratio);

  /// embedTitle
  ///
  /// In id, this message translates to:
  /// **'Tremie tertanam {emb}{est}'**
  String embedTitle(String emb, String est);

  /// estimateSuffix
  ///
  /// In id, this message translates to:
  /// **' (perkiraan)'**
  String get estimateSuffix;

  /// notSoundedYet
  ///
  /// In id, this message translates to:
  /// **'Muka beton belum disounding — angka ini dari volume. Sounding dulu sebelum mencabut.'**
  String get notSoundedYet;

  /// dontPullUnderOne
  ///
  /// In id, this message translates to:
  /// **'Kurang dari 1 m: JANGAN cabut. Tremie berisiko keluar dari beton.'**
  String get dontPullUnderOne;

  /// noPullNeeded
  ///
  /// In id, this message translates to:
  /// **'Tidak perlu cabut sekarang.'**
  String get noPullNeeded;

  /// pullSuggestion
  ///
  /// In id, this message translates to:
  /// **'Saran: cabut {which} → tertanam {after}. Centang di daftar tremie setelah dicabut.'**
  String pullSuggestion(String which, String after);

  /// tick
  ///
  /// In id, this message translates to:
  /// **'Centang'**
  String get tick;

  /// cellGrade
  ///
  /// In id, this message translates to:
  /// **'Mutu beton'**
  String get cellGrade;

  /// cellSupplier
  ///
  /// In id, this message translates to:
  /// **'Pemasok'**
  String get cellSupplier;

  /// cellHoleBottom
  ///
  /// In id, this message translates to:
  /// **'Dasar lubang'**
  String get cellHoleBottom;

  /// cellCutOff
  ///
  /// In id, this message translates to:
  /// **'Cut-off'**
  String get cellCutOff;

  /// cellConcreteLevel
  ///
  /// In id, this message translates to:
  /// **'Muka beton'**
  String get cellConcreteLevel;

  /// cellTheoretical
  ///
  /// In id, this message translates to:
  /// **'Seharusnya'**
  String get cellTheoretical;

  /// cellUsed
  ///
  /// In id, this message translates to:
  /// **'Terpakai'**
  String get cellUsed;

  /// cellOveruse
  ///
  /// In id, this message translates to:
  /// **'Lebih pakai'**
  String get cellOveruse;

  /// estimatedFootnote
  ///
  /// In id, this message translates to:
  /// **'* perkiraan dari volume'**
  String get estimatedFootnote;

  /// tremieNeedFrom
  ///
  /// In id, this message translates to:
  /// **'Perlu {need}. Mulai dari tremie bottom (ujung runcing).'**
  String tremieNeedFrom(String need);

  /// tremieOverLong
  ///
  /// In id, this message translates to:
  /// **'Kepanjangan: ujung atas {stick} di atas GS (paling tinggi {max}). Hapus pipa paling atas.'**
  String tremieOverLong(String stick, String max);

  /// tremieAtBottom
  ///
  /// In id, this message translates to:
  /// **'Sudah sampai dasar. Ujung atas {stick} di atas GS (hopper).'**
  String tremieAtBottom(String stick);

  /// tremieShortBy
  ///
  /// In id, this message translates to:
  /// **'Kurang {missing} lagi sampai dasar.'**
  String tremieShortBy(String missing);

  /// ofNeeded
  ///
  /// In id, this message translates to:
  /// **'dari {need} perlu'**
  String ofNeeded(String need);

  /// fitBottomPiece
  ///
  /// In id, this message translates to:
  /// **'Pasang tremie bottom'**
  String get fitBottomPiece;

  /// other
  ///
  /// In id, this message translates to:
  /// **'Lainnya'**
  String get other;

  /// removeTop
  ///
  /// In id, this message translates to:
  /// **'Hapus teratas'**
  String get removeTop;

  /// pullTremieTitle
  ///
  /// In id, this message translates to:
  /// **'Cabut tremie'**
  String get pullTremieTitle;

  /// pullTremieBody
  ///
  /// In id, this message translates to:
  /// **'Tekan \"Cabut\" pada pipa yang dicabut setelah TM ini. Gambar di atas ikut berubah.'**
  String get pullTremieBody;

  /// tremieBottomOf
  ///
  /// In id, this message translates to:
  /// **'Tremie bottom · {len} m'**
  String tremieBottomOf(String len);

  /// pipeOf
  ///
  /// In id, this message translates to:
  /// **'Pipa {len} m'**
  String pipeOf(String len);

  /// pulledAfterTruck
  ///
  /// In id, this message translates to:
  /// **'Dicabut setelah TM #{seq}'**
  String pulledAfterTruck(String seq);

  /// lowest
  ///
  /// In id, this message translates to:
  /// **'paling bawah'**
  String get lowest;

  /// pull
  ///
  /// In id, this message translates to:
  /// **'Cabut'**
  String get pull;

  /// truckHeading
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} · {vol} m³'**
  String truckHeading(int seq, String vol);

  /// hullNo
  ///
  /// In id, this message translates to:
  /// **'Lambung {no}'**
  String hullNo(String no);

  /// ticketNo
  ///
  /// In id, this message translates to:
  /// **'SJ {no}'**
  String ticketNo(String no);

  /// slumpOf
  ///
  /// In id, this message translates to:
  /// **'Slump {cm} cm'**
  String slumpOf(String cm);

  /// tremieFitted
  ///
  /// In id, this message translates to:
  /// **'Tremie terpasang'**
  String get tremieFitted;

  /// start
  ///
  /// In id, this message translates to:
  /// **'Mulai'**
  String get start;

  /// finish
  ///
  /// In id, this message translates to:
  /// **'Selesai'**
  String get finish;

  /// pausesCount
  ///
  /// In id, this message translates to:
  /// **'{n}× · {total}'**
  String pausesCount(int n, String total);

  /// pauseLine
  ///
  /// In id, this message translates to:
  /// **'{reason} · {from}–{to}'**
  String pauseLine(String reason, String from, String to);

  /// now
  ///
  /// In id, this message translates to:
  /// **'sekarang'**
  String get now;

  /// soundingBeforeLabel
  ///
  /// In id, this message translates to:
  /// **'Sounding sebelum'**
  String get soundingBeforeLabel;

  /// soundingAfterLabel
  ///
  /// In id, this message translates to:
  /// **'Sounding sesudah'**
  String get soundingAfterLabel;

  /// soundingAfterRequired
  ///
  /// In id, this message translates to:
  /// **'Sounding sesudah wajib diisi. Ketuk baris di atas.'**
  String get soundingAfterRequired;

  /// overbreakRatio
  ///
  /// In id, this message translates to:
  /// **'Lubang lebih besar'**
  String get overbreakRatio;

  /// deliveryNote
  ///
  /// In id, this message translates to:
  /// **'Surat jalan'**
  String get deliveryNote;

  /// slumpTest
  ///
  /// In id, this message translates to:
  /// **'Uji slump'**
  String get slumpTest;

  /// pausedLabel
  ///
  /// In id, this message translates to:
  /// **'Dijeda'**
  String get pausedLabel;

  /// overMinutes
  ///
  /// In id, this message translates to:
  /// **'Lewat {min} menit'**
  String overMinutes(int min);

  /// pourTime
  ///
  /// In id, this message translates to:
  /// **'Waktu tuang'**
  String get pourTime;

  /// pauseTruckTitle
  ///
  /// In id, this message translates to:
  /// **'Jeda TM #{seq}'**
  String pauseTruckTitle(int seq);

  /// pauseTruckBody
  ///
  /// In id, this message translates to:
  /// **'Kenapa dijeda? Jam tuang berhenti, dan HP bergetar tiap 3 menit sampai Anda ketuk Lanjut.'**
  String get pauseTruckBody;

  /// volumeInvalid
  ///
  /// In id, this message translates to:
  /// **'Isi volume TM (m³), paling besar {max}.'**
  String volumeInvalid(String max);

  /// volumeUnusual
  ///
  /// In id, this message translates to:
  /// **'{vol} m³ lebih besar dari biasanya (5–7 m³). Cek surat jalannya; kalau benar, tekan Simpan TM sekali lagi.'**
  String volumeUnusual(String vol);

  /// slumpInvalid
  ///
  /// In id, this message translates to:
  /// **'Slump tidak masuk akal (0–40 cm).'**
  String get slumpInvalid;

  /// editTruck
  ///
  /// In id, this message translates to:
  /// **'Ubah TM #{seq}'**
  String editTruck(int seq);

  /// photoTicket
  ///
  /// In id, this message translates to:
  /// **'Foto surat jalan TM'**
  String get photoTicket;

  /// photoSlump
  ///
  /// In id, this message translates to:
  /// **'Foto uji slump'**
  String get photoSlump;

  /// hullNoField
  ///
  /// In id, this message translates to:
  /// **'Nomor lambung TM'**
  String get hullNoField;

  /// truckSupplier
  ///
  /// In id, this message translates to:
  /// **'Pemasok beton TM ini'**
  String get truckSupplier;

  /// otherTypeName
  ///
  /// In id, this message translates to:
  /// **'Lainnya — ketik nama'**
  String get otherTypeName;

  /// otherSupplierName
  ///
  /// In id, this message translates to:
  /// **'Nama pemasok lain'**
  String get otherSupplierName;

  /// volumeField
  ///
  /// In id, this message translates to:
  /// **'Volume'**
  String get volumeField;

  /// slumpField
  ///
  /// In id, this message translates to:
  /// **'Slump hasil uji'**
  String get slumpField;

  /// soundingBeforeOptional
  ///
  /// In id, this message translates to:
  /// **'Sounding sebelum (opsional)'**
  String get soundingBeforeOptional;

  /// estimateHint
  ///
  /// In id, this message translates to:
  /// **'perkiraan {value}'**
  String estimateHint(String value);

  /// saveChanges
  ///
  /// In id, this message translates to:
  /// **'Simpan perubahan'**
  String get saveChanges;

  /// saveTruck
  ///
  /// In id, this message translates to:
  /// **'Simpan TM'**
  String get saveTruck;

  /// castDataTitle
  ///
  /// In id, this message translates to:
  /// **'Data cor'**
  String get castDataTitle;

  /// defaultGrade
  ///
  /// In id, this message translates to:
  /// **'Mutu bawaan {grade} MPa'**
  String defaultGrade(String grade);

  /// defaultGradeBody
  ///
  /// In id, this message translates to:
  /// **'Dari titik/proyek. Isi hanya bila beton yang datang berbeda.'**
  String get defaultGradeBody;

  /// suppliersWithPo
  ///
  /// In id, this message translates to:
  /// **'Pemasok dengan PO beton di proyek ini'**
  String get suppliersWithPo;

  /// noPoYet
  ///
  /// In id, this message translates to:
  /// **'Belum ada PO beton di proyek ini'**
  String get noPoYet;

  /// suppliersWithPoBody
  ///
  /// In id, this message translates to:
  /// **'Jadi isian awal tiap TM; tiap TM datang masih bisa memilih pemasoknya sendiri. Tidak ada di daftar? Pilih \"Lainnya\" lalu ketik namanya, dan kabari kantor.'**
  String get suppliersWithPoBody;

  /// noPoYetBody
  ///
  /// In id, this message translates to:
  /// **'Menampilkan semua pemasok beton; daftar menyempit sendiri setelah kantor membuat PO. Tiap TM datang masih bisa memilih pemasoknya sendiri.'**
  String get noPoYetBody;

  /// noteField
  ///
  /// In id, this message translates to:
  /// **'Keterangan'**
  String get noteField;

  /// hangAboveGs
  ///
  /// In id, this message translates to:
  /// **'{top}–{bottom} m di atas GS'**
  String hangAboveGs(String top, String bottom);

  /// hangAcrossGs
  ///
  /// In id, this message translates to:
  /// **'{top} m di atas GS sampai kedalaman {bottom} m'**
  String hangAcrossGs(String top, String bottom);

  /// hangDepth
  ///
  /// In id, this message translates to:
  /// **'kedalaman {top}–{bottom} m'**
  String hangDepth(String top, String bottom);

  /// stopTremieBlocked
  ///
  /// In id, this message translates to:
  /// **'Tremie tersumbat / beton macet'**
  String get stopTremieBlocked;

  /// stopNoTruck
  ///
  /// In id, this message translates to:
  /// **'TM tidak datang / beton habis'**
  String get stopNoTruck;

  /// stopHoleCollapse
  ///
  /// In id, this message translates to:
  /// **'Lubang runtuh'**
  String get stopHoleCollapse;

  /// stopPlantWeather
  ///
  /// In id, this message translates to:
  /// **'Alat rusak atau cuaca'**
  String get stopPlantWeather;

  /// labelDetail
  ///
  /// In id, this message translates to:
  /// **'{label} — {detail}'**
  String labelDetail(String label, String detail);

  /// stoppedBeforeCutOff
  ///
  /// In id, this message translates to:
  /// **'Cor dihentikan sebelum cut-off (kurang {missing} ≈ {vol} m³): {why}'**
  String stoppedBeforeCutOff(String missing, String vol, String why);

  /// belowCutOffTitle
  ///
  /// In id, this message translates to:
  /// **'Beton belum sampai cut-off'**
  String get belowCutOffTitle;

  /// finishCastingOf
  ///
  /// In id, this message translates to:
  /// **'Selesai cor {code}?'**
  String finishCastingOf(String code);

  /// shortfallTitle
  ///
  /// In id, this message translates to:
  /// **'Masih kurang {vol} m³ (±{trucks} TM lagi)'**
  String shortfallTitle(String vol, int trucks);

  /// shortfallLine1
  ///
  /// In id, this message translates to:
  /// **'Muka beton {level} dari GS, cut-off {cutoff} — kurang {missing}.'**
  String shortfallLine1(String level, String cutoff, String missing);

  /// shortfallLine2
  ///
  /// In id, this message translates to:
  /// **'Sudah tercor {poured} m³ dari ±{theoretical} m³ yang seharusnya{percent}.'**
  String shortfallLine2(String poured, String theoretical, String percent);

  /// percentSuffix
  ///
  /// In id, this message translates to:
  /// **' ({percent}%)'**
  String percentSuffix(String percent);

  /// estimateSoundToBeSure
  ///
  /// In id, this message translates to:
  /// **'Angka ini perkiraan dari volume — sounding dulu untuk memastikan.'**
  String get estimateSoundToBeSure;

  /// shortPileWarning
  ///
  /// In id, this message translates to:
  /// **'Tiang yang ditutup di bawah cut-off jadi tiang pendek, dan beton mengeras — tidak bisa dibatalkan. Kalau cor memang dihentikan, pilih alasannya; kantor perlu tahu. Kalau cuma salah tekan, pilih \"Belum — lanjut cor\".'**
  String get shortPileWarning;

  /// reasonRequired
  ///
  /// In id, this message translates to:
  /// **'Alasan (wajib)'**
  String get reasonRequired;

  /// detailOptional
  ///
  /// In id, this message translates to:
  /// **'Keterangan (boleh kosong)'**
  String get detailOptional;

  /// reasonHint
  ///
  /// In id, this message translates to:
  /// **'mis. tremie mampet di pipa ke-3, beton sudah mengeras'**
  String get reasonHint;

  /// shortABitBody
  ///
  /// In id, this message translates to:
  /// **'Kurang sedikit saja dari cut-off — kelebihan di atas cut-off memang dipotong nanti. Titik ditandai sudah dicor; catatan cor masih dapat diperbaiki sampai diperiksa kantor.'**
  String get shortABitBody;

  /// finishedBody
  ///
  /// In id, this message translates to:
  /// **'Titik ditandai sudah dicor. Catatan cor masih dapat diperbaiki sampai diperiksa kantor.'**
  String get finishedBody;

  /// finishAnyway
  ///
  /// In id, this message translates to:
  /// **'Tetap selesai'**
  String get finishAnyway;

  /// notYetKeepPouring
  ///
  /// In id, this message translates to:
  /// **'Belum — lanjut cor'**
  String get notYetKeepPouring;

  /// notYet
  ///
  /// In id, this message translates to:
  /// **'Belum'**
  String get notYet;

  /// castLogTitle
  ///
  /// In id, this message translates to:
  /// **'Catatan cor'**
  String get castLogTitle;

  /// overuseTitle
  ///
  /// In id, this message translates to:
  /// **'Beton terpakai {percent}% di atas teoretis'**
  String overuseTitle(String percent);

  /// overuseBody
  ///
  /// In id, this message translates to:
  /// **'Sampai muka beton {level}: terpakai {used} m³, teoretis {theoretical} m³. Kemungkinan lubang membesar atau runtuh. Laporkan ke pengawas.'**
  String overuseBody(String level, String used, String theoretical);

  /// gapInvalid
  ///
  /// In id, this message translates to:
  /// **'Celah bawah tremie 0–5 m.'**
  String get gapInvalid;

  /// reasonTidakValid
  ///
  /// In id, this message translates to:
  /// **'Isi data tidak sah'**
  String get reasonTidakValid;

  /// reasonTidakBerhak
  ///
  /// In id, this message translates to:
  /// **'Akun Anda tidak berhak menyimpan data ini'**
  String get reasonTidakBerhak;

  /// reasonBukanMilik
  ///
  /// In id, this message translates to:
  /// **'Data ini milik pengguna lain'**
  String get reasonBukanMilik;

  /// reasonDioper
  ///
  /// In id, this message translates to:
  /// **'Catatan ini sudah dioper ke rekan — perubahan hanya dari HP pemegangnya'**
  String get reasonDioper;

  /// reasonSudahDihapus
  ///
  /// In id, this message translates to:
  /// **'Data ini sudah dihapus di kantor'**
  String get reasonSudahDihapus;

  /// reasonSudahDitinjau
  ///
  /// In id, this message translates to:
  /// **'Absen sudah ditinjau kantor — tidak dapat diubah lagi'**
  String get reasonSudahDitinjau;

  /// reasonSudahDiperiksa
  ///
  /// In id, this message translates to:
  /// **'Catatan cor sudah diperiksa kantor — tidak dapat diubah lagi'**
  String get reasonSudahDiperiksa;

  /// reasonSudahDicor
  ///
  /// In id, this message translates to:
  /// **'Titik ini sudah tercatat dicor'**
  String get reasonSudahDicor;

  /// reasonProyekTidakAda
  ///
  /// In id, this message translates to:
  /// **'Proyek tidak ditemukan atau sudah ditutup'**
  String get reasonProyekTidakAda;

  /// reasonProyekTanggalTetap
  ///
  /// In id, this message translates to:
  /// **'Proyek dan tanggal absen tidak dapat diganti setelah terkirim'**
  String get reasonProyekTanggalTetap;

  /// reasonTanggalDepan
  ///
  /// In id, this message translates to:
  /// **'Tanggal absen di masa depan — periksa jam HP'**
  String get reasonTanggalDepan;

  /// reasonAbsenSudahAda
  ///
  /// In id, this message translates to:
  /// **'Sudah ada absen Anda untuk proyek dan tanggal ini'**
  String get reasonAbsenSudahAda;

  /// reasonWorkerBelumAda
  ///
  /// In id, this message translates to:
  /// **'Menunggu data pekerja baru terkirim lebih dulu'**
  String get reasonWorkerBelumAda;

  /// reasonPekerjaDihapus
  ///
  /// In id, this message translates to:
  /// **'Ada pekerja yang sudah dihapus di kantor'**
  String get reasonPekerjaDihapus;

  /// reasonPekerjaBukanKru
  ///
  /// In id, this message translates to:
  /// **'Ada pekerja yang bukan kru Anda'**
  String get reasonPekerjaBukanKru;

  /// reasonPekerjaGanda
  ///
  /// In id, this message translates to:
  /// **'Ada pekerja tercatat dua kali'**
  String get reasonPekerjaGanda;

  /// reasonUuidBentrok
  ///
  /// In id, this message translates to:
  /// **'Data bentrok dengan data lain — hubungi admin'**
  String get reasonUuidBentrok;

  /// reasonTitikTidakAda
  ///
  /// In id, this message translates to:
  /// **'Titik bor tidak ditemukan atau sudah dihapus'**
  String get reasonTitikTidakAda;

  /// reasonTitikTetap
  ///
  /// In id, this message translates to:
  /// **'Titik catatan cor tidak dapat diganti'**
  String get reasonTitikTetap;

  /// reasonCorSudahAda
  ///
  /// In id, this message translates to:
  /// **'Titik ini sudah punya catatan cor dari HP lain'**
  String get reasonCorSudahAda;

  /// reasonMutuKosong
  ///
  /// In id, this message translates to:
  /// **'Mutu beton belum diisi — isi di catatan cor, atau minta kantor mengisinya di titik/proyek'**
  String get reasonMutuKosong;

  /// reasonPemasokTidakAda
  ///
  /// In id, this message translates to:
  /// **'Pemasok beton tidak ditemukan'**
  String get reasonPemasokTidakAda;

  /// reasonTmGanda
  ///
  /// In id, this message translates to:
  /// **'Nomor urut TM ganda'**
  String get reasonTmGanda;

  /// reasonJamTmTerbalik
  ///
  /// In id, this message translates to:
  /// **'Jam selesai TM lebih awal dari jam mulai'**
  String get reasonJamTmTerbalik;

  /// reasonSegmenGanda
  ///
  /// In id, this message translates to:
  /// **'Posisi pipa tremie ganda'**
  String get reasonSegmenGanda;

  /// reasonSegmenTmAsing
  ///
  /// In id, this message translates to:
  /// **'Pipa tremie dicabut setelah TM yang tidak ada'**
  String get reasonSegmenTmAsing;

  /// reasonGsKosong
  ///
  /// In id, this message translates to:
  /// **'Elevasi GS titik ini belum diisi — isi saat menandai titik dibor'**
  String get reasonGsKosong;

  /// reasonJedaTmAsing
  ///
  /// In id, this message translates to:
  /// **'Ada jeda untuk TM yang tidak ada'**
  String get reasonJedaTmAsing;

  /// reasonJamJedaTerbalik
  ///
  /// In id, this message translates to:
  /// **'Jam jeda tidak masuk akal — periksa jam HP'**
  String get reasonJamJedaTerbalik;

  /// reasonTremieBottomSalah
  ///
  /// In id, this message translates to:
  /// **'Tremie bottom harus paling bawah, hanya satu, dan tidak dicabut'**
  String get reasonTremieBottomSalah;

  /// reasonSoundingKosong
  ///
  /// In id, this message translates to:
  /// **'Sounding sesudah TM belum diisi — wajib sebelum selesai cor'**
  String get reasonSoundingKosong;

  /// reasonLogBorSudahAda
  ///
  /// In id, this message translates to:
  /// **'Titik ini sudah punya catatan bor dari HP lain'**
  String get reasonLogBorSudahAda;

  /// reasonKedalamanMundur
  ///
  /// In id, this message translates to:
  /// **'Ada bacaan bor yang lebih dangkal dari bacaan sebelumnya'**
  String get reasonKedalamanMundur;

  /// reasonBorKosong
  ///
  /// In id, this message translates to:
  /// **'Catatan bor belum punya satu pun bacaan kedalaman'**
  String get reasonBorKosong;

  /// reasonEntriGanda
  ///
  /// In id, this message translates to:
  /// **'Ada bacaan bor tercatat dua kali'**
  String get reasonEntriGanda;

  /// reasonBerkasHilang
  ///
  /// In id, this message translates to:
  /// **'Berkas foto hilang dari HP'**
  String get reasonBerkasHilang;

  /// reasonWithDetail
  ///
  /// In id, this message translates to:
  /// **'{reason} ({detail})'**
  String reasonWithDetail(String reason, String detail);

  /// entityWorker
  ///
  /// In id, this message translates to:
  /// **'Pekerja'**
  String get entityWorker;

  /// entityAttendance
  ///
  /// In id, this message translates to:
  /// **'Absen'**
  String get entityAttendance;

  /// entityDrillMark
  ///
  /// In id, this message translates to:
  /// **'Tanda bor'**
  String get entityDrillMark;

  /// entityDrillLog
  ///
  /// In id, this message translates to:
  /// **'Catatan bor'**
  String get entityDrillLog;

  /// entityCasting
  ///
  /// In id, this message translates to:
  /// **'Catatan cor'**
  String get entityCasting;

  /// pauseCabutTremie
  ///
  /// In id, this message translates to:
  /// **'Cabut tremie'**
  String get pauseCabutTremie;

  /// pauseTungguTm
  ///
  /// In id, this message translates to:
  /// **'Tunggu TM'**
  String get pauseTungguTm;

  /// pauseKendalaAlat
  ///
  /// In id, this message translates to:
  /// **'Kendala alat'**
  String get pauseKendalaAlat;

  /// drillLogNotOnPhone
  ///
  /// In id, this message translates to:
  /// **'Catatan bor tidak ditemukan di HP ini.'**
  String get drillLogNotOnPhone;

  /// pointNotFoundPull
  ///
  /// In id, this message translates to:
  /// **'Titik bor tidak ditemukan. Tarik data terbaru dulu.'**
  String get pointNotFoundPull;

  /// pointHasDrillLog
  ///
  /// In id, this message translates to:
  /// **'Titik {code} sudah punya catatan bor{by}. Satu titik hanya boleh satu catatan bor.'**
  String pointHasDrillLog(String code, String by);

  /// pointAlreadyCast
  ///
  /// In id, this message translates to:
  /// **'Titik {code} sudah dicor.'**
  String pointAlreadyCast(String code);

  /// drillHeldByOther
  ///
  /// In id, this message translates to:
  /// **'Catatan bor ini dipegang {who} — ubah dari HP pemegangnya.'**
  String drillHeldByOther(String who);

  /// operatorSaved
  ///
  /// In id, this message translates to:
  /// **'Operator bor disimpan.'**
  String get operatorSaved;

  /// readingDeleted
  ///
  /// In id, this message translates to:
  /// **'Bacaan dihapus.'**
  String get readingDeleted;

  /// readingRecorded
  ///
  /// In id, this message translates to:
  /// **'Tercatat {depth} jam {time}.'**
  String readingRecorded(String depth, String time);

  /// drillFinishNotStored
  ///
  /// In id, this message translates to:
  /// **'Status selesai belum tersimpan. Coba tekan \"Selesai bor\" sekali lagi.'**
  String get drillFinishNotStored;

  /// drillFinished
  ///
  /// In id, this message translates to:
  /// **'{code} selesai dibor {depth}.'**
  String drillFinished(String code, String depth);

  /// drillReopened
  ///
  /// In id, this message translates to:
  /// **'Catatan bor dibuka lagi.'**
  String get drillReopened;

  /// drillOf
  ///
  /// In id, this message translates to:
  /// **'Bor {code}'**
  String drillOf(String code);

  /// drillHandedOverBody
  ///
  /// In id, this message translates to:
  /// **'Catatan bor ini dilanjutkan dari HP {who}. Di HP ini hanya bisa dilihat; perubahan dibuat di HP pemegangnya.'**
  String drillHandedOverBody(String who);

  /// drilledToDepth
  ///
  /// In id, this message translates to:
  /// **'Selesai dibor {depth}'**
  String drilledToDepth(String depth);

  /// drilledBodyOk
  ///
  /// In id, this message translates to:
  /// **'Titik ini sudah ditandai dibor; catatan cor bisa dimulai.'**
  String get drilledBodyOk;

  /// readingsSection
  ///
  /// In id, this message translates to:
  /// **'Bacaan'**
  String get readingsSection;

  /// readingsCount
  ///
  /// In id, this message translates to:
  /// **'{n} kali'**
  String readingsCount(int n);

  /// noReadingsYet
  ///
  /// In id, this message translates to:
  /// **'Belum ada bacaan. Tekan \"Catat kedalaman\" setiap kali kedalaman dibaca.'**
  String get noReadingsYet;

  /// finishDrilling
  ///
  /// In id, this message translates to:
  /// **'Selesai bor'**
  String get finishDrilling;

  /// recordDepth
  ///
  /// In id, this message translates to:
  /// **'Catat kedalaman'**
  String get recordDepth;

  /// drillOperatorLabel
  ///
  /// In id, this message translates to:
  /// **'OPERATOR BOR'**
  String get drillOperatorLabel;

  /// notPicked
  ///
  /// In id, this message translates to:
  /// **'Belum dipilih'**
  String get notPicked;

  /// pick
  ///
  /// In id, this message translates to:
  /// **'Pilih'**
  String get pick;

  /// change
  ///
  /// In id, this message translates to:
  /// **'Ganti'**
  String get change;

  /// finalDepthLabel
  ///
  /// In id, this message translates to:
  /// **'KEDALAMAN AKHIR'**
  String get finalDepthLabel;

  /// currentDepthLabel
  ///
  /// In id, this message translates to:
  /// **'KEDALAMAN SEKARANG'**
  String get currentDepthLabel;

  /// planNotComputable
  ///
  /// In id, this message translates to:
  /// **'rencana belum bisa dihitung'**
  String get planNotComputable;

  /// ofPlanned
  ///
  /// In id, this message translates to:
  /// **'dari {planned} rencana'**
  String ofPlanned(String planned);

  /// startedAt
  ///
  /// In id, this message translates to:
  /// **'mulai {time}'**
  String startedAt(String time);

  /// runningFor
  ///
  /// In id, this message translates to:
  /// **'sudah {duration}'**
  String runningFor(String duration);

  /// deeperThanPlan
  ///
  /// In id, this message translates to:
  /// **'{over} lebih dalam dari rencana.'**
  String deeperThanPlan(String over);

  /// hoursMinutes
  ///
  /// In id, this message translates to:
  /// **'{h} j {m} m'**
  String hoursMinutes(int h, int m);

  /// minutesOnly
  ///
  /// In id, this message translates to:
  /// **'{m} menit'**
  String minutesOnly(int m);

  /// depthGain
  ///
  /// In id, this message translates to:
  /// **'+{gain} dalam {duration}'**
  String depthGain(String gain, String duration);

  /// readingTime
  ///
  /// In id, this message translates to:
  /// **'Jam bacaan'**
  String get readingTime;

  /// depthInvalid
  ///
  /// In id, this message translates to:
  /// **'Isi kedalaman (m), lebih dari 0.'**
  String get depthInvalid;

  /// timeInFuture
  ///
  /// In id, this message translates to:
  /// **'Jamnya di masa depan. Periksa jam bacaan.'**
  String get timeInFuture;

  /// editReading
  ///
  /// In id, this message translates to:
  /// **'Ubah bacaan'**
  String get editReading;

  /// lastReadingWas
  ///
  /// In id, this message translates to:
  /// **'Bacaan terakhir {depth} jam {time}'**
  String lastReadingWas(String depth, String time);

  /// plannedIs
  ///
  /// In id, this message translates to:
  /// **'rencana {planned}'**
  String plannedIs(String planned);

  /// editTime
  ///
  /// In id, this message translates to:
  /// **'Ubah jam'**
  String get editTime;

  /// depthFromGs
  ///
  /// In id, this message translates to:
  /// **'Kedalaman dari GS'**
  String get depthFromGs;

  /// noteOptional
  ///
  /// In id, this message translates to:
  /// **'Catatan (boleh kosong)'**
  String get noteOptional;

  /// drillNoteHint
  ///
  /// In id, this message translates to:
  /// **'mis. ketemu batu, ganti mata bor'**
  String get drillNoteHint;

  /// deleteThisReading
  ///
  /// In id, this message translates to:
  /// **'Hapus bacaan ini'**
  String get deleteThisReading;

  /// finishDrillingOf
  ///
  /// In id, this message translates to:
  /// **'Selesai bor {code}?'**
  String finishDrillingOf(String code);

  /// finishDrillBody
  ///
  /// In id, this message translates to:
  /// **'Kedalaman akhir {depth} (bacaan terdalam). Titik ditandai sudah dibor dan catatan cor bisa dimulai.'**
  String finishDrillBody(String depth);

  /// shallowerThanPlan
  ///
  /// In id, this message translates to:
  /// **'Masih {short} lebih dangkal dari rencana'**
  String shallowerThanPlan(String short);

  /// shallowerBody
  ///
  /// In id, this message translates to:
  /// **'Rencana {planned}. Pastikan memang berhenti di sini.'**
  String shallowerBody(String planned);

  /// operatorNameRequired
  ///
  /// In id, this message translates to:
  /// **'Isi nama operator.'**
  String get operatorNameRequired;

  /// operatorExists
  ///
  /// In id, this message translates to:
  /// **'Sudah ada \"{name}\". Pilih dari daftar bila orangnya sama, atau tekan Simpan sekali lagi bila memang orang lain.'**
  String operatorExists(String name);

  /// drillOperator
  ///
  /// In id, this message translates to:
  /// **'Operator bor'**
  String get drillOperator;

  /// newOperator
  ///
  /// In id, this message translates to:
  /// **'Operator baru'**
  String get newOperator;

  /// checkFirst
  ///
  /// In id, this message translates to:
  /// **'Periksa dulu'**
  String get checkFirst;

  /// operatorName
  ///
  /// In id, this message translates to:
  /// **'Nama operator'**
  String get operatorName;

  /// phoneOptional
  ///
  /// In id, this message translates to:
  /// **'No. HP (boleh kosong)'**
  String get phoneOptional;

  /// backToList
  ///
  /// In id, this message translates to:
  /// **'Kembali ke daftar'**
  String get backToList;

  /// searchName
  ///
  /// In id, this message translates to:
  /// **'Cari nama'**
  String get searchName;

  /// noMatchAddNew
  ///
  /// In id, this message translates to:
  /// **'Belum ada yang cocok. Tambahkan operator baru.'**
  String get noMatchAddNew;

  /// queueTitle
  ///
  /// In id, this message translates to:
  /// **'Belum terkirim'**
  String get queueTitle;

  /// queueLoadError
  ///
  /// In id, this message translates to:
  /// **'Daftar yang belum terkirim gagal dibaca'**
  String get queueLoadError;

  /// lastSendFailed
  ///
  /// In id, this message translates to:
  /// **'Kiriman terakhir gagal'**
  String get lastSendFailed;

  /// queueCount
  ///
  /// In id, this message translates to:
  /// **'{docs} data · {photos} foto'**
  String queueCount(int docs, int photos);

  /// notSentSinceOpen
  ///
  /// In id, this message translates to:
  /// **'Belum dikirim sejak aplikasi dibuka'**
  String get notSentSinceOpen;

  /// lastTriedAt
  ///
  /// In id, this message translates to:
  /// **'Terakhir dicoba pukul {time}'**
  String lastTriedAt(String time);

  /// allSent
  ///
  /// In id, this message translates to:
  /// **'Semua sudah terkirim.'**
  String get allSent;

  /// photosSection
  ///
  /// In id, this message translates to:
  /// **'Foto'**
  String get photosSection;

  /// photoLine
  ///
  /// In id, this message translates to:
  /// **'{kind} · {kb} kB · {time}'**
  String photoLine(String kind, String kb, String time);

  /// photoFace
  ///
  /// In id, this message translates to:
  /// **'Wajah pekerja'**
  String get photoFace;

  /// photoCheckIn
  ///
  /// In id, this message translates to:
  /// **'Absen masuk'**
  String get photoCheckIn;

  /// photoCheckOut
  ///
  /// In id, this message translates to:
  /// **'Absen pulang'**
  String get photoCheckOut;

  /// photoTicketKind
  ///
  /// In id, this message translates to:
  /// **'Surat jalan TM'**
  String get photoTicketKind;

  /// photoSlumpKind
  ///
  /// In id, this message translates to:
  /// **'Uji slump TM'**
  String get photoSlumpKind;

  /// changedAt
  ///
  /// In id, this message translates to:
  /// **'Diubah {time} · {id}'**
  String changedAt(String time, String id);

  /// retryAt
  ///
  /// In id, this message translates to:
  /// **'Dicoba lagi pukul {time}'**
  String retryAt(String time);

  /// discardTitle
  ///
  /// In id, this message translates to:
  /// **'Buang dari HP?'**
  String get discardTitle;

  /// discardBody
  ///
  /// In id, this message translates to:
  /// **'Data ini tidak akan dikirim lagi. Tidak dapat dibatalkan.'**
  String get discardBody;

  /// discard
  ///
  /// In id, this message translates to:
  /// **'Buang'**
  String get discard;

  /// unsavedTitle
  ///
  /// In id, this message translates to:
  /// **'Tinggalkan tanpa menyimpan?'**
  String get unsavedTitle;

  /// unsavedBody
  ///
  /// In id, this message translates to:
  /// **'Ada isian di lembar ini yang belum tersimpan, termasuk foto yang baru diambil. Foto yang dibuang tidak akan menempel ke TM ini.'**
  String get unsavedBody;

  /// discarded
  ///
  /// In id, this message translates to:
  /// **'Dibuang dari HP.'**
  String get discarded;

  /// queuedResend
  ///
  /// In id, this message translates to:
  /// **'Dicoba kirim ulang sekarang.'**
  String get queuedResend;

  /// resend
  ///
  /// In id, this message translates to:
  /// **'Kirim ulang'**
  String get resend;

  /// fillEmailPassword
  ///
  /// In id, this message translates to:
  /// **'Isi email dan kata sandi.'**
  String get fillEmailPassword;

  /// loginNeedsSignal
  ///
  /// In id, this message translates to:
  /// **'Masuk perlu sinyal. Sesudah masuk sekali, aplikasi dapat dipakai tanpa sinyal.'**
  String get loginNeedsSignal;

  /// accountOnOtherPhone
  ///
  /// In id, this message translates to:
  /// **'Akun ini masih dipakai di HP lain'**
  String get accountOnOtherPhone;

  /// oneAccountOnePhone
  ///
  /// In id, this message translates to:
  /// **'Satu akun hanya boleh dipakai di satu HP, supaya catatan lapangan tidak bercabang.{last}'**
  String oneAccountOnePhone(String last);

  /// lastActiveSuffix
  ///
  /// In id, this message translates to:
  /// **' HP itu terakhir aktif {when}.'**
  String lastActiveSuffix(String when);

  /// oldPhoneKeepsData
  ///
  /// In id, this message translates to:
  /// **'Data di HP lama tidak hilang'**
  String get oldPhoneKeepsData;

  /// oldPhoneKeepsDataBody
  ///
  /// In id, this message translates to:
  /// **'HP itu masih dapat mengirim sisa catatannya, hanya tidak boleh mencatat yang baru. Bila HP itu yang sebenarnya Anda pakai, batalkan saja dan masuk dari sana.'**
  String get oldPhoneKeepsDataBody;

  /// moveToThisPhone
  ///
  /// In id, this message translates to:
  /// **'Pindahkan ke HP ini'**
  String get moveToThisPhone;

  /// minutesAgo
  ///
  /// In id, this message translates to:
  /// **'{n} menit lalu'**
  String minutesAgo(int n);

  /// hoursAgo
  ///
  /// In id, this message translates to:
  /// **'{n} jam lalu'**
  String hoursAgo(int n);

  /// daysAgo
  ///
  /// In id, this message translates to:
  /// **'{n} hari lalu'**
  String daysAgo(int n);

  /// justNow
  ///
  /// In id, this message translates to:
  /// **'barusan'**
  String get justNow;

  /// loginTagline
  ///
  /// In id, this message translates to:
  /// **'Absensi kru & catatan pengecoran'**
  String get loginTagline;

  /// dataSafeHere
  ///
  /// In id, this message translates to:
  /// **'Data di HP ini aman'**
  String get dataSafeHere;

  /// signInAgainToSend
  ///
  /// In id, this message translates to:
  /// **'Masuk lagi dengan akun yang sama supaya sisanya terkirim.'**
  String get signInAgainToSend;

  /// cannotSignInYet
  ///
  /// In id, this message translates to:
  /// **'Belum dapat masuk'**
  String get cannotSignInYet;

  /// email
  ///
  /// In id, this message translates to:
  /// **'Email'**
  String get email;

  /// password
  ///
  /// In id, this message translates to:
  /// **'Kata sandi'**
  String get password;

  /// signIn
  ///
  /// In id, this message translates to:
  /// **'Masuk'**
  String get signIn;

  /// phoneReplacedTitle
  ///
  /// In id, this message translates to:
  /// **'HP ini sudah digantikan'**
  String get phoneReplacedTitle;

  /// accountUsedElsewhere
  ///
  /// In id, this message translates to:
  /// **'Akun ini dipakai di HP lain'**
  String get accountUsedElsewhere;

  /// phoneReplacedBody
  ///
  /// In id, this message translates to:
  /// **'Akun Anda dipakai masuk di HP lain, jadi HP ini tidak lagi menerima catatan baru. Sisa yang belum terkirim tetap dikirim dari sini. Bila HP ini yang Anda pakai, masuk lagi di HP ini.'**
  String get phoneReplacedBody;

  /// accountUsedElsewhereBody
  ///
  /// In id, this message translates to:
  /// **'Akun Anda dipakai masuk di HP lain{who}. Kirim sisa data dari HP ini, lalu lanjutkan di HP itu. Mulai {until} HP ini tidak lagi menerima catatan baru.'**
  String accountUsedElsewhereBody(String who, String until);

  /// inParens
  ///
  /// In id, this message translates to:
  /// **' ({what})'**
  String inParens(String what);

  /// signInOnThisPhone
  ///
  /// In id, this message translates to:
  /// **'Masuk di HP ini'**
  String get signInOnThisPhone;

  /// sessionExpired
  ///
  /// In id, this message translates to:
  /// **'Sesi berakhir — masuk lagi'**
  String get sessionExpired;

  /// sessionExpiredBody
  ///
  /// In id, this message translates to:
  /// **'Data di HP ini AMAN dan tetap dapat diisi. Masuk lagi supaya sisanya dapat dikirim.'**
  String get sessionExpiredBody;

  /// clockOffTitle
  ///
  /// In id, this message translates to:
  /// **'Jam HP {drift} dari jam server'**
  String clockOffTitle(String drift);

  /// clockOffBody
  ///
  /// In id, this message translates to:
  /// **'Semua jam bacaan bor dan jam TM diambil dari jam HP ini. Nyalakan \"Tanggal & waktu otomatis\" di pengaturan HP, lalu tarik data lagi.'**
  String get clockOffBody;

  /// rejectedCount
  ///
  /// In id, this message translates to:
  /// **'{n} data ditolak server'**
  String rejectedCount(int n);

  /// rejectedBody
  ///
  /// In id, this message translates to:
  /// **'Buka \"Pending\" untuk melihat sebabnya dan memperbaikinya.'**
  String get rejectedBody;

  /// view
  ///
  /// In id, this message translates to:
  /// **'Lihat'**
  String get view;

  /// sending
  ///
  /// In id, this message translates to:
  /// **'Mengirim…'**
  String get sending;

  /// staleUnsent
  ///
  /// In id, this message translates to:
  /// **'Lebih dari sehari belum terkirim: {docs} data, {photos} foto'**
  String staleUnsent(int docs, int photos);

  /// unsent
  ///
  /// In id, this message translates to:
  /// **'Belum terkirim: {docs} data, {photos} foto'**
  String unsent(int docs, int photos);

  /// staleUnsentBody
  ///
  /// In id, this message translates to:
  /// **'Cari tempat bersinyal atau WiFi, lalu tekan Kirim. Bila tetap tidak terkirim, hubungi admin TerraBot.'**
  String get staleUnsentBody;

  /// offlineAutoSend
  ///
  /// In id, this message translates to:
  /// **'Tidak ada sinyal. Dikirim otomatis begitu HP mendapat sinyal, walau aplikasi ditutup.'**
  String get offlineAutoSend;

  /// autoSendOnSignal
  ///
  /// In id, this message translates to:
  /// **'Dikirim otomatis begitu ada sinyal.'**
  String get autoSendOnSignal;

  /// send
  ///
  /// In id, this message translates to:
  /// **'Kirim'**
  String get send;

  /// updateAvailableTitle
  ///
  /// In id, this message translates to:
  /// **'Versi {version} sudah tersedia'**
  String updateAvailableTitle(String version);

  /// updateAvailableBody
  ///
  /// In id, this message translates to:
  /// **'Aplikasi tetap bisa dipakai seperti biasa. Perbarui kalau sempat — lebih enak dilakukan sebelum mulai kerja daripada di tengah pengecoran.'**
  String get updateAvailableBody;

  /// updateNow
  ///
  /// In id, this message translates to:
  /// **'Perbarui'**
  String get updateNow;

  /// updateTitle
  ///
  /// In id, this message translates to:
  /// **'Perbarui TerraBot Field'**
  String get updateTitle;

  /// updateBody
  ///
  /// In id, this message translates to:
  /// **'Versi di HP ini {current} sudah tidak dilayani server. Pasang versi {min} atau yang lebih baru untuk lanjut bekerja.'**
  String updateBody(String current, String min);

  /// unsentSafeHere
  ///
  /// In id, this message translates to:
  /// **'{n} data belum terkirim — AMAN di HP ini'**
  String unsentSafeHere(int n);

  /// installOverBody
  ///
  /// In id, this message translates to:
  /// **'Pasang versi baru DI ATAS app ini. JANGAN uninstall dulu: uninstall menghapus semua data yang belum terkirim. Setelah diperbarui, data langsung terkirim sendiri.'**
  String get installOverBody;

  /// downloadNew
  ///
  /// In id, this message translates to:
  /// **'Unduh versi baru'**
  String get downloadNew;

  /// askAdminApk
  ///
  /// In id, this message translates to:
  /// **'Minta file app terbaru ke admin'**
  String get askAdminApk;

  /// askAdminApkBody
  ///
  /// In id, this message translates to:
  /// **'Admin TerraBot akan mengirim file APK atau tautannya.'**
  String get askAdminApkBody;

  /// checkAgain
  ///
  /// In id, this message translates to:
  /// **'Periksa lagi'**
  String get checkAgain;

  /// keepRunningTitle
  ///
  /// In id, this message translates to:
  /// **'Biarkan TerraBot Field jalan'**
  String get keepRunningTitle;

  /// keepRunningBody
  ///
  /// In id, this message translates to:
  /// **'HP ini mematikan aplikasi yang tidak sedang dibuka. Tanpa pengaturan di bawah, getar pengingat cor (20 menit, jeda) dan kirim otomatis TIDAK jalan saat layar mati.'**
  String get keepRunningBody;

  /// openAutostart
  ///
  /// In id, this message translates to:
  /// **'Buka pengaturan Mulai otomatis'**
  String get openAutostart;

  /// openBattery
  ///
  /// In id, this message translates to:
  /// **'Buka pengaturan Baterai aplikasi'**
  String get openBattery;

  /// setBatteryOnce
  ///
  /// In id, this message translates to:
  /// **'Atur baterai HP sekali saja'**
  String get setBatteryOnce;

  /// setBatteryBody
  ///
  /// In id, this message translates to:
  /// **'Supaya getar pengingat cor dan kirim otomatis tetap jalan saat layar mati.'**
  String get setBatteryBody;

  /// setUp
  ///
  /// In id, this message translates to:
  /// **'Atur'**
  String get setUp;

  /// thisPeriod
  ///
  /// In id, this message translates to:
  /// **'Periode ini'**
  String get thisPeriod;

  /// fullRecap
  ///
  /// In id, this message translates to:
  /// **'Rekap lengkap'**
  String get fullRecap;

  /// fullRecapBody
  ///
  /// In id, this message translates to:
  /// **'Semua titik sejak awal proyek sampai {to}'**
  String fullRecapBody(String to);

  /// excelSubject
  ///
  /// In id, this message translates to:
  /// **'Rekapitulasi Data Tiang'**
  String get excelSubject;

  /// excelFailed
  ///
  /// In id, this message translates to:
  /// **'Excel gagal diunduh: {error}'**
  String excelFailed(String error);

  /// reportsTitle
  ///
  /// In id, this message translates to:
  /// **'Laporan lapangan'**
  String get reportsTitle;

  /// presetToday
  ///
  /// In id, this message translates to:
  /// **'Hari ini'**
  String get presetToday;

  /// presetYesterday
  ///
  /// In id, this message translates to:
  /// **'Kemarin'**
  String get presetYesterday;

  /// presetWeek
  ///
  /// In id, this message translates to:
  /// **'7 hari'**
  String get presetWeek;

  /// pickDate
  ///
  /// In id, this message translates to:
  /// **'Pilih tanggal'**
  String get pickDate;

  /// pickRange
  ///
  /// In id, this message translates to:
  /// **'Pilih rentang'**
  String get pickRange;

  /// rangeTooLong
  ///
  /// In id, this message translates to:
  /// **'Rentang paling lama {max} hari.'**
  String rangeTooLong(String max);

  /// dateRange
  ///
  /// In id, this message translates to:
  /// **'{from} – {to}'**
  String dateRange(String from, String to);

  /// preparingExcel
  ///
  /// In id, this message translates to:
  /// **'Menyiapkan Excel…'**
  String get preparingExcel;

  /// downloadExcel
  ///
  /// In id, this message translates to:
  /// **'Unduh Excel (Rekapitulasi Data Tiang)'**
  String get downloadExcel;

  /// reportLoadError
  ///
  /// In id, this message translates to:
  /// **'Laporan gagal dibaca'**
  String get reportLoadError;

  /// statDrilledPoints
  ///
  /// In id, this message translates to:
  /// **'Titik dibor'**
  String get statDrilledPoints;

  /// statCastPoints
  ///
  /// In id, this message translates to:
  /// **'Titik dicor'**
  String get statCastPoints;

  /// statCastSub
  ///
  /// In id, this message translates to:
  /// **'{vol} m³ · {trucks} TM'**
  String statCastSub(String vol, String trucks);

  /// noPointsThatDay
  ///
  /// In id, this message translates to:
  /// **'Belum ada titik yang dibor atau dicor pada tanggal ini.'**
  String get noPointsThatDay;

  /// projectNo
  ///
  /// In id, this message translates to:
  /// **'Proyek #{id}'**
  String projectNo(String id);

  /// pullToReload
  ///
  /// In id, this message translates to:
  /// **'Tarik ke bawah untuk memuat ulang. Data dari semua HP yang sudah terkirim.'**
  String get pullToReload;

  /// pointsSuffix
  ///
  /// In id, this message translates to:
  /// **'{n} titik'**
  String pointsSuffix(String n);

  /// drilledCount
  ///
  /// In id, this message translates to:
  /// **'Dibor ({n})'**
  String drilledCount(int n);

  /// castCount
  ///
  /// In id, this message translates to:
  /// **'Dicor ({n})'**
  String castCount(int n);

  /// noLog
  ///
  /// In id, this message translates to:
  /// **'tanpa catatan'**
  String get noLog;

  /// operatorShort
  ///
  /// In id, this message translates to:
  /// **'op. {name}'**
  String operatorShort(String name);

  /// statusDone
  ///
  /// In id, this message translates to:
  /// **'Selesai'**
  String get statusDone;

  /// statusChecked
  ///
  /// In id, this message translates to:
  /// **'Diperiksa'**
  String get statusChecked;

  /// theoreticalOf
  ///
  /// In id, this message translates to:
  /// **'seharusnya {vol} m³{over}'**
  String theoreticalOf(String vol, String over);

  /// percentParens
  ///
  /// In id, this message translates to:
  /// **' ({sign}{percent}%)'**
  String percentParens(String sign, String percent);

  /// resumePouring
  ///
  /// In id, this message translates to:
  /// **'Lanjutkan cor'**
  String get resumePouring;

  /// pauseReminderMin
  ///
  /// In id, this message translates to:
  /// **'{body} · {min} menit'**
  String pauseReminderMin(String body, int min);

  /// idleReminderMin
  ///
  /// In id, this message translates to:
  /// **'{body} · {min} menit sejak TM terakhir'**
  String idleReminderMin(String body, int min);

  /// drillSnoozeAction
  ///
  /// In id, this message translates to:
  /// **'Diamkan sampai besok'**
  String get drillSnoozeAction;

  /// activityTodayTitle
  ///
  /// In id, this message translates to:
  /// **'Hari ini'**
  String get activityTodayTitle;

  /// activityTodayMore
  ///
  /// In id, this message translates to:
  /// **'+{n} lagi — buka Laporan untuk daftar lengkapnya'**
  String activityTodayMore(int n);

  /// activityTodayDone
  ///
  /// In id, this message translates to:
  /// **'beres {jam}'**
  String activityTodayDone(String jam);

  /// activityTodayRunning
  ///
  /// In id, this message translates to:
  /// **'masih jalan · terakhir {jam}'**
  String activityTodayRunning(String jam);

  /// drillIdleTitle
  ///
  /// In id, this message translates to:
  /// **'Catatan bor {code} belum diisi'**
  String drillIdleTitle(String code);

  /// drillIdleBody
  ///
  /// In id, this message translates to:
  /// **'Sudah {since} sejak bacaan terakhir ({time}). Catat kedalaman sekarang, atau tekan Selesai bor bila sudah selesai.'**
  String drillIdleBody(String since, String time);

  /// hoursText
  ///
  /// In id, this message translates to:
  /// **'{h} jam'**
  String hoursText(int h);

  /// minutesText
  ///
  /// In id, this message translates to:
  /// **'{m} menit'**
  String minutesText(int m);

  /// hoursMinutesText
  ///
  /// In id, this message translates to:
  /// **'{h} jam {m} menit'**
  String hoursMinutesText(int h, int m);

  /// unsentTitle
  ///
  /// In id, this message translates to:
  /// **'Ada data belum terkirim'**
  String get unsentTitle;

  /// unsentBody
  ///
  /// In id, this message translates to:
  /// **'Sejak {since}. Buka TerraBot Field di tempat bersinyal supaya terkirim.'**
  String unsentBody(String since);

  /// badgeSent
  ///
  /// In id, this message translates to:
  /// **'Terkirim'**
  String get badgeSent;

  /// badgeRejected
  ///
  /// In id, this message translates to:
  /// **'Ditolak'**
  String get badgeRejected;

  /// badgeWaiting
  ///
  /// In id, this message translates to:
  /// **'Menunggu data'**
  String get badgeWaiting;

  /// badgeFailedRetry
  ///
  /// In id, this message translates to:
  /// **'Gagal, diulang'**
  String get badgeFailedRetry;

  /// badgeUnsent
  ///
  /// In id, this message translates to:
  /// **'Belum terkirim'**
  String get badgeUnsent;

  /// powerXiaomi1
  ///
  /// In id, this message translates to:
  /// **'Mulai otomatis (Autostart): NYALAKAN untuk TerraBot Field.'**
  String get powerXiaomi1;

  /// powerXiaomi2
  ///
  /// In id, this message translates to:
  /// **'Penghemat baterai: pilih \"Tanpa batasan\" (No restrictions).'**
  String get powerXiaomi2;

  /// powerOppo1
  ///
  /// In id, this message translates to:
  /// **'Mulai otomatis / Izinkan auto-launch: NYALAKAN untuk TerraBot Field.'**
  String get powerOppo1;

  /// powerOppo2
  ///
  /// In id, this message translates to:
  /// **'Penggunaan baterai: izinkan \"Aktivitas latar belakang\" dan \"Mulai otomatis\".'**
  String get powerOppo2;

  /// powerVivo1
  ///
  /// In id, this message translates to:
  /// **'Auto-start / Latar belakang: IZINKAN untuk TerraBot Field.'**
  String get powerVivo1;

  /// powerVivo2
  ///
  /// In id, this message translates to:
  /// **'Baterai → Konsumsi daya latar tinggi: IZINKAN.'**
  String get powerVivo2;

  /// powerHuawei1
  ///
  /// In id, this message translates to:
  /// **'Peluncuran aplikasi: matikan \"Kelola otomatis\", lalu nyalakan Mulai otomatis, Mulai sekunder, dan Jalankan di latar.'**
  String get powerHuawei1;

  /// powerSamsung1
  ///
  /// In id, this message translates to:
  /// **'Baterai: pilih \"Tidak dibatasi\" (Unrestricted).'**
  String get powerSamsung1;

  /// powerSamsung2
  ///
  /// In id, this message translates to:
  /// **'Pastikan TerraBot Field TIDAK ada di daftar \"Aplikasi tidur\" / \"Aplikasi tidur nyenyak\".'**
  String get powerSamsung2;

  /// powerGeneric
  ///
  /// In id, this message translates to:
  /// **'Baterai: pilih \"Tanpa batasan\" / \"Tidak dioptimalkan\" untuk TerraBot Field.'**
  String get powerGeneric;

  /// soundDeeperThanBottom
  ///
  /// In id, this message translates to:
  /// **'Lebih dalam dari dasar lubang ({bottom} m). Periksa lagi.'**
  String soundDeeperThanBottom(String bottom);

  /// soundDeeperThanBefore
  ///
  /// In id, this message translates to:
  /// **'Lebih dalam dari muka beton sebelum TM ini ({before} m). Beton tidak mungkin turun; periksa lagi.'**
  String soundDeeperThanBefore(String before);

  /// readingShallower
  ///
  /// In id, this message translates to:
  /// **'Lebih dangkal dari bacaan jam {time} ({depth}). Lubang tidak bisa makin dangkal.'**
  String readingShallower(String time, String depth);

  /// readingDeeperThanNext
  ///
  /// In id, this message translates to:
  /// **'Lebih dalam dari bacaan berikutnya jam {time} ({depth}). Periksa jamnya.'**
  String readingDeeperThanNext(String time, String depth);

  /// depthFarFromPlan
  ///
  /// In id, this message translates to:
  /// **'{depth} m terlalu jauh dari rencana {planned} m (paling dalam {max} m). Periksa angkanya, titiknya, atau elevasi GS.'**
  String depthFarFromPlan(String depth, String planned, String max);

  /// numberInvalid
  ///
  /// In id, this message translates to:
  /// **'Isi angka lebih dari 0, paling besar {max}.'**
  String numberInvalid(String max);

  /// castAlreadyDone
  ///
  /// In id, this message translates to:
  /// **'Cor titik ini sudah selesai.'**
  String get castAlreadyDone;

  /// noTruckPouring
  ///
  /// In id, this message translates to:
  /// **'Tidak ada TM yang sedang dicor.'**
  String get noTruckPouring;

  /// truckAlreadyPaused
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} sudah dijeda.'**
  String truckAlreadyPaused(int seq);

  /// truckNotPaused
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} tidak sedang dijeda.'**
  String truckNotPaused(int seq);

  /// photoUnreadable
  ///
  /// In id, this message translates to:
  /// **'Foto tidak dapat dibaca.'**
  String get photoUnreadable;

  /// photoCompressFailed
  ///
  /// In id, this message translates to:
  /// **'Foto tidak dapat dikompres.'**
  String get photoCompressFailed;

  /// workersTitle
  ///
  /// In id, this message translates to:
  /// **'Pekerja'**
  String get workersTitle;

  /// newWorker
  ///
  /// In id, this message translates to:
  /// **'Pekerja baru'**
  String get newWorker;

  /// workersLoadError
  ///
  /// In id, this message translates to:
  /// **'Daftar pekerja gagal dibaca'**
  String get workersLoadError;

  /// workersAllBody
  ///
  /// In id, this message translates to:
  /// **'Semua pekerja perusahaan. Siapa pun dapat mengabsen dan mengubahnya.'**
  String get workersAllBody;

  /// workersNoProjectBody
  ///
  /// In id, this message translates to:
  /// **'Tanpa proyek utama dan tidak diabsen di mana pun {days} hari terakhir.'**
  String workersNoProjectBody(String days);

  /// workersProjectBody
  ///
  /// In id, this message translates to:
  /// **'Proyek utamanya {code}, atau diabsen di {code} {days} hari terakhir.'**
  String workersProjectBody(String code, String days);

  /// workersCount
  ///
  /// In id, this message translates to:
  /// **'{n} pekerja'**
  String workersCount(int n);

  /// noWorkersYet
  ///
  /// In id, this message translates to:
  /// **'Belum ada pekerja. Daftarkan pekerja baru dengan tombol di bawah.'**
  String get noWorkersYet;

  /// searchNameOrPhone
  ///
  /// In id, this message translates to:
  /// **'Cari nama atau no. HP'**
  String get searchNameOrPhone;

  /// allCount
  ///
  /// In id, this message translates to:
  /// **'Semua ({n})'**
  String allCount(int n);

  /// withoutProject
  ///
  /// In id, this message translates to:
  /// **'Tanpa proyek ({n})'**
  String withoutProject(int n);

  /// noMatchingWorkers
  ///
  /// In id, this message translates to:
  /// **'Tidak ada pekerja yang cocok.'**
  String get noMatchingWorkers;

  /// mainProjectIs
  ///
  /// In id, this message translates to:
  /// **'Proyek utama {code}'**
  String mainProjectIs(String code);

  /// lastSeenAt
  ///
  /// In id, this message translates to:
  /// **'Terakhir di {code} · {date}'**
  String lastSeenAt(String code, String date);

  /// cameraFailed
  ///
  /// In id, this message translates to:
  /// **'Kamera gagal: {error}'**
  String cameraFailed(String error);

  /// workerNameRequired
  ///
  /// In id, this message translates to:
  /// **'Isi nama pekerja.'**
  String get workerNameRequired;

  /// workerSaved
  ///
  /// In id, this message translates to:
  /// **'{name} disimpan. Terkirim otomatis saat ada sinyal.'**
  String workerSaved(String name);

  /// mainProjectOptional
  ///
  /// In id, this message translates to:
  /// **'Proyek utama (opsional)'**
  String get mainProjectOptional;

  /// noMainProject
  ///
  /// In id, this message translates to:
  /// **'Tanpa proyek utama'**
  String get noMainProject;

  /// andOthers
  ///
  /// In id, this message translates to:
  /// **'\n• dan {n} lainnya'**
  String andOthers(int n);

  /// maybeRegistered
  ///
  /// In id, this message translates to:
  /// **'Mungkin sudah terdaftar'**
  String get maybeRegistered;

  /// maybeRegisteredBody
  ///
  /// In id, this message translates to:
  /// **'Nama atau nomor HP ini mirip pekerja yang sudah ada:\n{names}\n\nKalau orangnya sama, batalkan dan pakai pekerja yang sudah ada. Kalau memang orang lain, tekan tombol simpan sekali lagi.'**
  String maybeRegisteredBody(String names);

  /// needsFixing
  ///
  /// In id, this message translates to:
  /// **'Perlu diperbaiki'**
  String get needsFixing;

  /// viewOnlyWorkerBody
  ///
  /// In id, this message translates to:
  /// **'Akun Anda tidak punya izin mendaftarkan atau mengubah pekerja. Minta kantor menambahkan izinnya.'**
  String get viewOnlyWorkerBody;

  /// noFaceDetected
  ///
  /// In id, this message translates to:
  /// **'Wajah tidak terdeteksi'**
  String get noFaceDetected;

  /// facesDetected
  ///
  /// In id, this message translates to:
  /// **'{n} wajah terdeteksi'**
  String facesDetected(int n);

  /// facePhotoBody
  ///
  /// In id, this message translates to:
  /// **'Foto wajah dipakai kantor untuk mencocokkan kru. Ambil ulang dengan satu wajah, menghadap kamera.'**
  String get facePhotoBody;

  /// retake
  ///
  /// In id, this message translates to:
  /// **'Ulang'**
  String get retake;

  /// fullName
  ///
  /// In id, this message translates to:
  /// **'Nama lengkap'**
  String get fullName;

  /// phoneOptional2
  ///
  /// In id, this message translates to:
  /// **'No. HP (opsional)'**
  String get phoneOptional2;

  /// workerNoteHint
  ///
  /// In id, this message translates to:
  /// **'Catatan (mis. tukang besi, operator)'**
  String get workerNoteHint;

  /// saveAsNewWorker
  ///
  /// In id, this message translates to:
  /// **'Tetap simpan sebagai pekerja baru'**
  String get saveAsNewWorker;

  /// attendanceTitle
  ///
  /// In id, this message translates to:
  /// **'Absensi kru'**
  String get attendanceTitle;

  /// attendToday
  ///
  /// In id, this message translates to:
  /// **'Absen hari ini'**
  String get attendToday;

  /// attendanceLoadError
  ///
  /// In id, this message translates to:
  /// **'Absen gagal dibaca'**
  String get attendanceLoadError;

  /// attendanceHistory
  ///
  /// In id, this message translates to:
  /// **'Riwayat absen'**
  String get attendanceHistory;

  /// otherProject
  ///
  /// In id, this message translates to:
  /// **'proyek lain'**
  String get otherProject;

  /// attendanceHistoryBody
  ///
  /// In id, this message translates to:
  /// **'Absen yang dibuat dari HP ini'**
  String get attendanceHistoryBody;

  /// noAttendanceYet
  ///
  /// In id, this message translates to:
  /// **'Belum ada absen.'**
  String get noAttendanceYet;

  /// failedWith
  ///
  /// In id, this message translates to:
  /// **'Gagal: {error}'**
  String failedWith(String error);

  /// photoInGallery
  ///
  /// In id, this message translates to:
  /// **'Foto tersimpan di galeri HP (album \"{album}\").'**
  String photoInGallery(String album);

  /// galleryDenied
  ///
  /// In id, this message translates to:
  /// **'Absen tersimpan, tapi foto tidak masuk galeri: izin galeri ditolak.'**
  String get galleryDenied;

  /// galleryFailed
  ///
  /// In id, this message translates to:
  /// **'Absen tersimpan, tapi foto gagal disimpan ke galeri HP.'**
  String get galleryFailed;

  /// saveCrewTicks
  ///
  /// In id, this message translates to:
  /// **'Simpan centang kru?'**
  String get saveCrewTicks;

  /// saveCrewTicksBody
  ///
  /// In id, this message translates to:
  /// **'Ada perubahan kru yang belum disimpan.'**
  String get saveCrewTicksBody;

  /// crewAttendance
  ///
  /// In id, this message translates to:
  /// **'Absen kru'**
  String get crewAttendance;

  /// saveWithCount
  ///
  /// In id, this message translates to:
  /// **'Simpan · {n} kru'**
  String saveWithCount(int n);

  /// rejectedByOffice
  ///
  /// In id, this message translates to:
  /// **'Ditolak kantor'**
  String get rejectedByOffice;

  /// approvedByOffice
  ///
  /// In id, this message translates to:
  /// **'Sudah disetujui kantor'**
  String get approvedByOffice;

  /// attendanceLocked
  ///
  /// In id, this message translates to:
  /// **'Absen ini tidak dapat diubah lagi dari HP.'**
  String get attendanceLocked;

  /// projectLabel
  ///
  /// In id, this message translates to:
  /// **'Proyek'**
  String get projectLabel;

  /// projectNoLocation
  ///
  /// In id, this message translates to:
  /// **'Lokasi proyek belum diisi kantor'**
  String get projectNoLocation;

  /// projectNoLocationBody
  ///
  /// In id, this message translates to:
  /// **'Absen tetap tersimpan; jarak ke proyek tidak dapat diperiksa.'**
  String get projectNoLocationBody;

  /// checkIn
  ///
  /// In id, this message translates to:
  /// **'Absen masuk'**
  String get checkIn;

  /// checkOut
  ///
  /// In id, this message translates to:
  /// **'Absen pulang'**
  String get checkOut;

  /// savedWithoutLocation
  ///
  /// In id, this message translates to:
  /// **'Tersimpan tanpa lokasi'**
  String get savedWithoutLocation;

  /// savedWithoutLocationBody
  ///
  /// In id, this message translates to:
  /// **'{problem} Kantor akan melihat absen ini bertanda \"tanpa lokasi\".'**
  String savedWithoutLocationBody(String problem);

  /// crewPresent
  ///
  /// In id, this message translates to:
  /// **'Kru hadir ({n})'**
  String crewPresent(int n);

  /// noWorkersTitle
  ///
  /// In id, this message translates to:
  /// **'Belum ada pekerja'**
  String get noWorkersTitle;

  /// noWorkersBody
  ///
  /// In id, this message translates to:
  /// **'Daftarkan pekerja baru dulu. Pekerja yang didaftarkan di sini langsung dapat diabsen, walau belum terkirim.'**
  String get noWorkersBody;

  /// thisProject
  ///
  /// In id, this message translates to:
  /// **'proyek ini'**
  String get thisProject;

  /// searchWorkerName
  ///
  /// In id, this message translates to:
  /// **'Cari nama pekerja'**
  String get searchWorkerName;

  /// noWorkersForProject
  ///
  /// In id, this message translates to:
  /// **'Belum ada pekerja {code}'**
  String noWorkersForProject(String code);

  /// noWorkersForProjectBody
  ///
  /// In id, this message translates to:
  /// **'Belum ada yang proyek utamanya {code} atau diabsen di sini {days} hari terakhir. Centang dari daftar semua pekerja di bawah; setelah terkirim, mereka muncul paling atas di sini.'**
  String noWorkersForProjectBody(String code, String days);

  /// unknownWorker
  ///
  /// In id, this message translates to:
  /// **'Pekerja tidak dikenal'**
  String get unknownWorker;

  /// otherWorkers
  ///
  /// In id, this message translates to:
  /// **'Pekerja lain ({n})'**
  String otherWorkers(int n);

  /// noWorkerByName
  ///
  /// In id, this message translates to:
  /// **'Tidak ada pekerja dengan nama itu.'**
  String get noWorkerByName;

  /// flaggedForOffice
  ///
  /// In id, this message translates to:
  /// **'Ditandai untuk diperiksa kantor'**
  String get flaggedForOffice;

  /// flagOutsideRadius
  ///
  /// In id, this message translates to:
  /// **'• Lokasi absen di luar radius proyek'**
  String get flagOutsideRadius;

  /// flagNoProjectLocation
  ///
  /// In id, this message translates to:
  /// **'• Lokasi proyek belum diisi kantor'**
  String get flagNoProjectLocation;

  /// flagNoLocation
  ///
  /// In id, this message translates to:
  /// **'• Absen tanpa lokasi GPS'**
  String get flagNoLocation;

  /// flagMockLocation
  ///
  /// In id, this message translates to:
  /// **'• HP melaporkan lokasi palsu'**
  String get flagMockLocation;

  /// flagClockOff
  ///
  /// In id, this message translates to:
  /// **'• Jam HP berbeda jauh dari jam server'**
  String get flagClockOff;

  /// flagClockUnverified
  ///
  /// In id, this message translates to:
  /// **'• Jam HP tidak dapat diverifikasi (HP dinyalakan ulang)'**
  String get flagClockUnverified;

  /// flagClockEdited
  ///
  /// In id, this message translates to:
  /// **'• Jam diubah manual'**
  String get flagClockEdited;

  /// flagFaceCountOff
  ///
  /// In id, this message translates to:
  /// **'• Jumlah wajah di foto berbeda dengan jumlah kru'**
  String get flagFaceCountOff;

  /// flagPhotoPending
  ///
  /// In id, this message translates to:
  /// **'• Foto masih menunggu terkirim'**
  String get flagPhotoPending;

  /// fullDay
  ///
  /// In id, this message translates to:
  /// **'Penuh'**
  String get fullDay;

  /// halfDay
  ///
  /// In id, this message translates to:
  /// **'½ hari'**
  String get halfDay;

  /// overtime
  ///
  /// In id, this message translates to:
  /// **'Lembur'**
  String get overtime;

  /// hoursShort
  ///
  /// In id, this message translates to:
  /// **'{h} j'**
  String hoursShort(String h);

  /// crewPhotoOf
  ///
  /// In id, this message translates to:
  /// **'Foto kru · {what}'**
  String crewPhotoOf(String what);

  /// atTime
  ///
  /// In id, this message translates to:
  /// **'Pukul {time}'**
  String atTime(String time);

  /// withinRadius
  ///
  /// In id, this message translates to:
  /// **'{m} m dari proyek ✓'**
  String withinRadius(String m);

  /// outsideRadius
  ///
  /// In id, this message translates to:
  /// **'{m} m dari proyek — di luar radius {radius} m'**
  String outsideRadius(String m, String radius);

  /// noLocation
  ///
  /// In id, this message translates to:
  /// **'Tanpa lokasi'**
  String get noLocation;

  /// mockLocation
  ///
  /// In id, this message translates to:
  /// **'Lokasi palsu terdeteksi'**
  String get mockLocation;

  /// facesInPhoto
  ///
  /// In id, this message translates to:
  /// **'{n} wajah di foto'**
  String facesInPhoto(int n);

  /// longPressRetake
  ///
  /// In id, this message translates to:
  /// **'Tekan lama untuk foto ulang'**
  String get longPressRetake;

  /// levelRefTitle
  ///
  /// In id, this message translates to:
  /// **'Patokan elevasi'**
  String get levelRefTitle;

  /// levelRefColTip
  ///
  /// In id, this message translates to:
  /// **'COL {col} · Tip {tip}'**
  String levelRefColTip(String col, String tip);

  /// notSet
  ///
  /// In id, this message translates to:
  /// **'belum ada'**
  String get notSet;

  /// levelRefNoGs
  ///
  /// In id, this message translates to:
  /// **'Isi GS dulu untuk melihat kedalaman COL dan rencana bor.'**
  String get levelRefNoGs;

  /// levelRefGs
  ///
  /// In id, this message translates to:
  /// **'GS {gs}'**
  String levelRefGs(String gs);

  /// levelRefColBelow
  ///
  /// In id, this message translates to:
  /// **'• COL {d} di bawah GS'**
  String levelRefColBelow(String d);

  /// levelRefPlanned
  ///
  /// In id, this message translates to:
  /// **'• Rencana bor {d}'**
  String levelRefPlanned(String d);

  /// levelRefFooter
  ///
  /// In id, this message translates to:
  /// **'Kedalaman bor diukur dari GS sampai dasar lubang.'**
  String get levelRefFooter;

  /// projectsMissingHome
  ///
  /// In id, this message translates to:
  /// **'Tarik ke bawah untuk mengambilnya dari server. Perlu sinyal sekali saja; sesudahnya dapat dipakai tanpa sinyal.'**
  String get projectsMissingHome;

  /// noFieldAccess
  ///
  /// In id, this message translates to:
  /// **'Akun ini belum punya akses lapangan'**
  String get noFieldAccess;

  /// noFieldAccessBody
  ///
  /// In id, this message translates to:
  /// **'Minta admin TerraBot menambahkan divisi Field Engineer ke akun Anda, lalu tarik ke bawah.'**
  String get noFieldAccessBody;

  /// volumePouredHere
  ///
  /// In id, this message translates to:
  /// **'Volume tertuang di titik ini'**
  String get volumePouredHere;

  /// volumeSharedHint
  ///
  /// In id, this message translates to:
  /// **'Bawaannya satu TM penuh. Bila TM ini dibagi dengan lubang lain, isi porsi yang masuk ke titik ini saja.'**
  String get volumeSharedHint;

  /// overuseAheadTitle
  ///
  /// In id, this message translates to:
  /// **'Beton akan lewat {percent}% dari seharusnya'**
  String overuseAheadTitle(String percent);

  /// overuseAheadBody
  ///
  /// In id, this message translates to:
  /// **'Terpakai {used} m³ dari {theoretical} m³ yang seharusnya setelah TM ini. Paling sering sebabnya TM dibagi dengan lubang lain — isi porsinya saja bila begitu.'**
  String overuseAheadBody(String used, String theoretical);

  /// overuseAfterTitle
  ///
  /// In id, this message translates to:
  /// **'Beton jauh di atas seharusnya'**
  String get overuseAfterTitle;

  /// overuseAfterBody
  ///
  /// In id, this message translates to:
  /// **'Sampai TM #{seq}, beton terpakai {percent}% di atas seharusnya. Sebelum dicatat sebagai lubang membesar, periksa dulu: apakah ada TM yang dibagi dengan lubang lain?'**
  String overuseAfterBody(int seq, String percent);

  /// fixTruckVolume
  ///
  /// In id, this message translates to:
  /// **'Betulkan volume TM'**
  String get fixTruckVolume;

  /// holeReallyWider
  ///
  /// In id, this message translates to:
  /// **'Lubang memang membesar'**
  String get holeReallyWider;

  /// later
  ///
  /// In id, this message translates to:
  /// **'Nanti saja'**
  String get later;

  /// widerHoleNote
  ///
  /// In id, this message translates to:
  /// **'TM #{seq}: beton {percent}% di atas teoritis — lubang membesar (diperiksa di lapangan).'**
  String widerHoleNote(int seq, String percent);

  /// pullNowTitle
  ///
  /// In id, this message translates to:
  /// **'Cabut tremie sekarang?'**
  String get pullNowTitle;

  /// pullNowBody
  ///
  /// In id, this message translates to:
  /// **'TM #{seq} selesai, tertanam {emb}. Cabut {which} supaya tertanam jadi {after}.'**
  String pullNowBody(int seq, String emb, String which, String after);

  /// pulledAlready
  ///
  /// In id, this message translates to:
  /// **'Sudah dicabut'**
  String get pulledAlready;

  /// notYetPull
  ///
  /// In id, this message translates to:
  /// **'Belum dicabut'**
  String get notYetPull;

  /// Penanda tetap di catatan log. SAMA di tiga bahasa: dipakai layar untuk tahu pertanyaan overbreak sudah dijawab, jadi menerjemahkannya akan membuat pertanyaan itu muncul lagi di bahasa lain.
  ///
  /// In id, this message translates to:
  /// **'[overbreak diperiksa]'**
  String get overbreakCheckedTag;

  /// excelOptionsTitle
  ///
  /// In id, this message translates to:
  /// **'Unduh Excel'**
  String get excelOptionsTitle;

  /// excelPeriodLabel
  ///
  /// In id, this message translates to:
  /// **'Rentang'**
  String get excelPeriodLabel;

  /// excelSheetsLabel
  ///
  /// In id, this message translates to:
  /// **'Lembar yang dibuat'**
  String get excelSheetsLabel;

  /// sheetPiles
  ///
  /// In id, this message translates to:
  /// **'Rekap tiang'**
  String get sheetPiles;

  /// sheetPilesBody
  ///
  /// In id, this message translates to:
  /// **'Satu baris per titik: kedalaman, volume, tanggal.'**
  String get sheetPilesBody;

  /// sheetConcrete
  ///
  /// In id, this message translates to:
  /// **'Mutu beton'**
  String get sheetConcrete;

  /// sheetConcreteBody
  ///
  /// In id, this message translates to:
  /// **'Hanya titik yang sudah dicor, beserta kuat tekannya.'**
  String get sheetConcreteBody;

  /// sheetOperators
  ///
  /// In id, this message translates to:
  /// **'Rekap operator'**
  String get sheetOperators;

  /// sheetOperatorsBody
  ///
  /// In id, this message translates to:
  /// **'Meter bor aktual vs teoritis per operator, plus satu lembar tiap operator.'**
  String get sheetOperatorsBody;

  /// pickAtLeastOneSheet
  ///
  /// In id, this message translates to:
  /// **'Pilih minimal satu lembar.'**
  String get pickAtLeastOneSheet;

  /// download
  ///
  /// In id, this message translates to:
  /// **'Unduh'**
  String get download;

  /// Button that takes the photo again, next to its preview
  ///
  /// In id, this message translates to:
  /// **'Ulangi'**
  String get retakePhoto;

  /// Hint under a photo thumbnail
  ///
  /// In id, this message translates to:
  /// **'Ketuk untuk memperbesar'**
  String get tapToEnlarge;

  /// The photo belongs to this log but its file is on another phone
  ///
  /// In id, this message translates to:
  /// **'Foto tidak ada di HP ini'**
  String get photoNotOnThisPhone;

  /// Button next to GS that opens the correction dialog
  ///
  /// In id, this message translates to:
  /// **'Koreksi'**
  String get correct;

  /// Leaves the drill log when GS is not confirmed
  ///
  /// In id, this message translates to:
  /// **'Keluar'**
  String get backOut;

  /// Label of the ground-level row in the drill log
  ///
  /// In id, this message translates to:
  /// **'Muka tanah (GS)'**
  String get gsRowLabel;

  /// Planned drill length under the GS row
  ///
  /// In id, this message translates to:
  /// **'Panjang bor rencana {depth}'**
  String plannedDrillOf(String depth);

  /// Title of the GS dialog shown before drilling starts
  ///
  /// In id, this message translates to:
  /// **'Konfirmasi sebelum bor {code}'**
  String confirmBeforeDrilling(String code);

  /// Body of that dialog
  ///
  /// In id, this message translates to:
  /// **'Masukkan hasil koreksi GS di titik ini. Panjang bor rencana dihitung dari angka ini, jadi harus benar sebelum mata bor turun.'**
  String get confirmBeforeDrillingBody;

  /// Title when GS is being corrected later
  ///
  /// In id, this message translates to:
  /// **'Koreksi GS'**
  String get correctGsTitle;

  /// Body of the GS correction dialog
  ///
  /// In id, this message translates to:
  /// **'Surveyor merevisi tembakannya? Ubah GS di sini; panjang bor rencana dan kedalaman cut-off ikut terhitung ulang.'**
  String get correctGsBody;

  /// Names the colleague whose phone shows the handover code
  ///
  /// In id, this message translates to:
  /// **'Kodenya ada di HP {name}'**
  String codeHeldBy(String name);

  /// Tells the receiver exactly what the holder must do; there is no push request
  ///
  /// In id, this message translates to:
  /// **'Minta {name} membuka titik ini di HP-nya lalu menekan \"Oper ke rekan\". Kode 6 angka akan muncul di layarnya untuk disebutkan. Tidak ada permintaan yang terkirim otomatis.'**
  String codeHeldByBody(String name);

  /// Button in the code dialog that asks the holder instead of typing a code
  ///
  /// In id, this message translates to:
  /// **'Minta ke pemegang'**
  String get askHolder;

  /// Progress while the handover request is sent
  ///
  /// In id, this message translates to:
  /// **'Mengirim permintaan…'**
  String get sendingRequest;

  /// Confirmation that the request reached the server
  ///
  /// In id, this message translates to:
  /// **'Permintaan terkirim'**
  String get requestSentTitle;

  /// Explains what happens next after asking the holder
  ///
  /// In id, this message translates to:
  /// **'{name} mendapat pemberitahuan di HP-nya. Begitu disetujui, catatan ini pindah ke HP Anda — tidak perlu kode.'**
  String requestSentBody(String name);

  /// Progress while the holder approves
  ///
  /// In id, this message translates to:
  /// **'Memindahkan catatan…'**
  String get handingOver;

  /// Progress while the holder rejects
  ///
  /// In id, this message translates to:
  /// **'Menolak permintaan…'**
  String get rejectingRequest;

  /// Snack on the old holder phone once the log has moved
  ///
  /// In id, this message translates to:
  /// **'Catatan {code} sudah pindah ke {name}.'**
  String logHandedTo(String code, String name);

  /// Snack after the holder rejects
  ///
  /// In id, this message translates to:
  /// **'Permintaan {name} ditolak.'**
  String requestRejected(String name);

  /// Notification title and banner title on the holder phone
  ///
  /// In id, this message translates to:
  /// **'{name} minta oper'**
  String handoverRequestTitle(String name);

  /// Notification body on the holder phone
  ///
  /// In id, this message translates to:
  /// **'Titik {code} — buka untuk menyetujui atau menolak.'**
  String handoverRequestBody(String code);

  /// Banner body asking the holder to approve or reject
  ///
  /// In id, this message translates to:
  /// **'{name} sedang di titik {code} dan menunggu jawaban. Disetujui berarti catatan ini langsung pindah ke HP-nya, dan layar ini ditutup.'**
  String handoverRequestPrompt(String name, String code);

  /// Button that grants the handover
  ///
  /// In id, this message translates to:
  /// **'Setujui'**
  String get approve;

  /// Button that refuses the handover
  ///
  /// In id, this message translates to:
  /// **'Tolak'**
  String get reject;

  /// Label of the drilling progress card on a point held elsewhere
  ///
  /// In id, this message translates to:
  /// **'Kemajuan bor'**
  String get drillProgressLabel;

  /// Label of the casting progress card on a point held elsewhere
  ///
  /// In id, this message translates to:
  /// **'Kemajuan cor'**
  String get castProgressLabel;

  /// Deepest reading against the planned drill length
  ///
  /// In id, this message translates to:
  /// **'{depth} dari {planned} rencana'**
  String drillProgressMain(String depth, String planned);

  /// Truck count and volume against the theoretical volume
  ///
  /// In id, this message translates to:
  /// **'TM ke-{n} · {vol} m³ dari {theoretical} m³ teoritis'**
  String castProgressMain(String n, String vol, String theoretical);

  /// Shown when the holder has sent no records yet
  ///
  /// In id, this message translates to:
  /// **'Belum ada catatan'**
  String get progressNothingYet;

  /// logGoneResynced
  ///
  /// In id, this message translates to:
  /// **'Catatannya sudah tidak ada di server — kemungkinan dihapus dari kantor. Titik ini baru saja ditarik ulang; silakan buka lagi.'**
  String get logGoneResynced;

  /// Shown when there is no timestamp at all
  ///
  /// In id, this message translates to:
  /// **'Catatannya sudah dibuka, catatan pertama belum masuk'**
  String get progressNoSync;

  /// When the last record was made, and how long ago
  ///
  /// In id, this message translates to:
  /// **'Catatan terakhir {time} · {age}'**
  String progressLastAt(String time, String age);

  /// Warns that the figures are only as fresh as the holder phone last sync
  ///
  /// In id, this message translates to:
  /// **'Sejauh yang sudah terkirim HP pemegangnya. Kalau HP-nya sedang tanpa sinyal, keadaan sebenarnya bisa lebih maju.'**
  String get progressAsSent;

  /// Tooltip of the refresh button that pulls from the server
  ///
  /// In id, this message translates to:
  /// **'Muat ulang'**
  String get refresh;

  /// Button that opens the server-side history of this pile point
  ///
  /// In id, this message translates to:
  /// **'Lihat riwayat titik'**
  String get pointHistoryOpen;

  /// Title of the point history screen
  ///
  /// In id, this message translates to:
  /// **'Riwayat {code}'**
  String pointHistoryTitle(String code);

  /// Shown when the history request fails
  ///
  /// In id, this message translates to:
  /// **'Riwayat tidak bisa dibuka'**
  String get pointHistoryErrorTitle;

  /// Explains the history screen needs connectivity
  ///
  /// In id, this message translates to:
  /// **'Layar ini membaca langsung dari server, jadi perlu sinyal. Tarik ke bawah untuk mencoba lagi.'**
  String get pointHistoryErrorBody;

  /// Empty state of the point history screen
  ///
  /// In id, this message translates to:
  /// **'Belum ada catatan cor di server untuk titik ini.'**
  String get pointHistoryNoCasting;

  /// Heading of the audit trail section
  ///
  /// In id, this message translates to:
  /// **'Jejak koreksi'**
  String get pointHistoryTrail;

  /// Badge on a record that has been deleted
  ///
  /// In id, this message translates to:
  /// **'Dihapus'**
  String get deletedLabel;

  /// Badge on a record created or edited from the web office app
  ///
  /// In id, this message translates to:
  /// **'Dari kantor'**
  String get fromOffice;

  /// How many mixer trucks the casting log has
  ///
  /// In id, this message translates to:
  /// **'{n} TM'**
  String trucksCount(int n);

  /// Label of the actual concrete volume
  ///
  /// In id, this message translates to:
  /// **'Volume terpakai'**
  String get volumeUsed;

  /// Label of the theoretical concrete volume
  ///
  /// In id, this message translates to:
  /// **'Volume teoritis'**
  String get volumeTheoretical;

  /// Label of the overuse percentage
  ///
  /// In id, this message translates to:
  /// **'Kelebihan pakai'**
  String get overusePercent;

  /// Label of the casting start and end time
  ///
  /// In id, this message translates to:
  /// **'Mulai – selesai cor'**
  String get castStartEnd;

  /// Badge on a drilling row whose hole is drilled but whose drill log was reopened and never closed again
  ///
  /// In id, this message translates to:
  /// **'Catatan belum ditutup'**
  String get drillLogNotClosed;

  /// Tremie embedment in fresh concrete before this truck is poured
  ///
  /// In id, this message translates to:
  /// **'Tremie tertanam awal'**
  String get embedBeforeLabel;

  /// Tremie embedment in fresh concrete after this truck is poured
  ///
  /// In id, this message translates to:
  /// **'Tremie tertanam akhir'**
  String get embedAfterLabel;

  /// One-line summary of the tremie string
  ///
  /// In id, this message translates to:
  /// **'{n} batang · {total} m · ujung bawah {gap} di atas dasar lubang'**
  String tremieSummary(int n, String total, String gap);

  /// A tremie section that was never pulled out
  ///
  /// In id, this message translates to:
  /// **'masih terpasang'**
  String get tremieStillFitted;

  /// When a tremie section was removed
  ///
  /// In id, this message translates to:
  /// **'dicabut setelah TM {seq}'**
  String tremiePulledAfter(int seq);

  /// Banner title on a point whose drilling and casting have been confirmed
  ///
  /// In id, this message translates to:
  /// **'Titik sudah dikonfirmasi'**
  String get pointConfirmedTitle;

  /// Who confirmed the point and when, and what that means
  ///
  /// In id, this message translates to:
  /// **'Dikonfirmasi {who}, {when}. Data bor dan cor titik ini tidak dapat diubah lagi sampai konfirmasinya dibuka dari kantor.'**
  String pointConfirmedBody(String who, String when);

  /// Server rejected the push because the point is already confirmed
  ///
  /// In id, this message translates to:
  /// **'Titik ini sudah dikonfirmasi kantor — minta kantor membuka konfirmasinya dulu'**
  String get reasonTitikDikonfirmasi;

  /// Heading of the drilling section on the point history screen
  ///
  /// In id, this message translates to:
  /// **'Pengeboran'**
  String get drillSection;

  /// Heading of the casting section on the point history screen
  ///
  /// In id, this message translates to:
  /// **'Pengecoran'**
  String get castSection;

  /// Deepest depth ever read on a drill log
  ///
  /// In id, this message translates to:
  /// **'Terdalam'**
  String get deepestLabel;

  /// Time from the first reading to the last
  ///
  /// In id, this message translates to:
  /// **'Lama bor'**
  String get drillDurationLabel;

  /// Final depth divided by the drilling time
  ///
  /// In id, this message translates to:
  /// **'Laju rata-rata'**
  String get avgRateLabel;

  /// The segment between two readings where drilling was slowest
  ///
  /// In id, this message translates to:
  /// **'Ruas paling lambat'**
  String get slowestSegmentLabel;

  /// A drilling rate
  ///
  /// In id, this message translates to:
  /// **'{v} m/jam'**
  String metresPerHour(String v);

  /// Time actually spent drilling — stops excluded
  ///
  /// In id, this message translates to:
  /// **'Lama mengebor'**
  String get drillEffectiveLabel;

  /// Shown small under the effective drilling time
  ///
  /// In id, this message translates to:
  /// **'dari total {total}'**
  String drillOfTotal(String total);

  /// Depth divided by the effective drilling time
  ///
  /// In id, this message translates to:
  /// **'Laju bor'**
  String get drillEffectiveRateLabel;

  /// Shown small under the drilling rate
  ///
  /// In id, this message translates to:
  /// **'{laju} m/jam termasuk berhenti'**
  String drillRateTotal(String laju);

  /// Heading of the list of stops
  ///
  /// In id, this message translates to:
  /// **'{n} kali berhenti · {lama}'**
  String drillStops(String n, String lama);

  /// denahTitle
  ///
  /// In id, this message translates to:
  /// **'Denah titik'**
  String get denahTitle;

  /// denahLabelToggle
  ///
  /// In id, this message translates to:
  /// **'Kode titik'**
  String get denahLabelToggle;

  /// Denah titik: denahRotate
  ///
  /// In id, this message translates to:
  /// **'Putar 90°'**
  String get denahRotate;

  /// Denah titik: denahFit
  ///
  /// In id, this message translates to:
  /// **'Pas layar'**
  String get denahFit;

  /// denahDeviationToggle
  ///
  /// In id, this message translates to:
  /// **'Garis simpangan'**
  String get denahDeviationToggle;

  /// denahDrilled
  ///
  /// In id, this message translates to:
  /// **'Sudah dibor'**
  String get denahDrilled;

  /// denahNoCoordTitle
  ///
  /// In id, this message translates to:
  /// **'{n} titik tidak tergambar'**
  String denahNoCoordTitle(String n);

  /// denahNoCoordBody
  ///
  /// In id, this message translates to:
  /// **'Titik ini belum punya koordinat X/Y — rencana maupun aktual — jadi tidak ada tempatnya di denah. Kantor yang mengisinya lewat impor Excel.'**
  String get denahNoCoordBody;

  /// denahEmptyTitle
  ///
  /// In id, this message translates to:
  /// **'Belum ada koordinat'**
  String get denahEmptyTitle;

  /// denahEmptyBody
  ///
  /// In id, this message translates to:
  /// **'Tidak ada satu pun titik proyek ini yang koordinat X/Y-nya terisi, jadi denahnya belum dapat digambar. Koordinat rencananya diisi dari kantor.'**
  String get denahEmptyBody;

  /// drillPlanRef
  ///
  /// In id, this message translates to:
  /// **'{v} rencana'**
  String drillPlanRef(String v);

  /// deviationStopTitle
  ///
  /// In id, this message translates to:
  /// **'Simpangan {v} melewati toleransi'**
  String deviationStopTitle(String v);

  /// deviationStopBody
  ///
  /// In id, this message translates to:
  /// **'Toleransi proyek {batas}; titik ini lewat {lewat}. Periksa dulu hasil ukur dan koordinat rencananya sebelum lubang ini dicor — sesudah dicor, satu-satunya pilihan yang tersisa adalah perkuatan, dan itu bukan keputusan dari HP.'**
  String deviationStopBody(String batas, String lewat);

  /// deviationStopSave
  ///
  /// In id, this message translates to:
  /// **'Simpan apa adanya'**
  String get deviationStopSave;

  /// deviationStopRecheck
  ///
  /// In id, this message translates to:
  /// **'Periksa lagi'**
  String get deviationStopRecheck;

  /// filterDrilling
  ///
  /// In id, this message translates to:
  /// **'Sedang dibor'**
  String get filterDrilling;

  /// filterCasting
  ///
  /// In id, this message translates to:
  /// **'Sedang dicor'**
  String get filterCasting;

  /// progressIdle
  ///
  /// In id, this message translates to:
  /// **'Berhenti sejak {jam} · {lama} tanpa bacaan baru'**
  String progressIdle(String jam, String lama);

  /// readingTableTitle
  ///
  /// In id, this message translates to:
  /// **'Bacaan ({n})'**
  String readingTableTitle(String n);

  /// readingColTime
  ///
  /// In id, this message translates to:
  /// **'Jam'**
  String get readingColTime;

  /// readingColDepth
  ///
  /// In id, this message translates to:
  /// **'Kedalaman'**
  String get readingColDepth;

  /// readingColAdded
  ///
  /// In id, this message translates to:
  /// **'Tambah'**
  String get readingColAdded;

  /// readingColRate
  ///
  /// In id, this message translates to:
  /// **'Laju'**
  String get readingColRate;

  /// readingNotPlotted
  ///
  /// In id, this message translates to:
  /// **'Tidak tergambar di kurva — jam atau kedalamannya tidak terbaca.'**
  String get readingNotPlotted;

  /// activityTitle
  ///
  /// In id, this message translates to:
  /// **'Aktivitas lapangan'**
  String get activityTitle;

  /// activityToday
  ///
  /// In id, this message translates to:
  /// **'Hari ini · ketuk untuk pilih tanggal'**
  String get activityToday;

  /// activityPick
  ///
  /// In id, this message translates to:
  /// **'Ketuk untuk pilih tanggal'**
  String get activityPick;

  /// activityPrevDay
  ///
  /// In id, this message translates to:
  /// **'Hari sebelumnya'**
  String get activityPrevDay;

  /// activityNextDay
  ///
  /// In id, this message translates to:
  /// **'Hari berikutnya'**
  String get activityNextDay;

  /// activityEmptyTitle
  ///
  /// In id, this message translates to:
  /// **'Tidak ada catatan pada hari ini'**
  String get activityEmptyTitle;

  /// activityEmptyBody
  ///
  /// In id, this message translates to:
  /// **'Tidak ada pengeboran maupun pengecoran yang tercatat. Pilih hari lain dengan panah di atas.'**
  String get activityEmptyBody;

  /// activityDrilled
  ///
  /// In id, this message translates to:
  /// **'titik dibor'**
  String get activityDrilled;

  /// activityPoured
  ///
  /// In id, this message translates to:
  /// **'titik dicor'**
  String get activityPoured;

  /// activityAllProjects
  ///
  /// In id, this message translates to:
  /// **'Semua proyek'**
  String get activityAllProjects;

  /// activityNoProject
  ///
  /// In id, this message translates to:
  /// **'Tanpa proyek'**
  String get activityNoProject;

  /// activitySeeAll
  ///
  /// In id, this message translates to:
  /// **'Lihat semua'**
  String get activitySeeAll;

  /// Shown instead of the curve when there are fewer than two usable readings
  ///
  /// In id, this message translates to:
  /// **'Kurvanya perlu sedikitnya dua bacaan yang jam dan kedalamannya terbaca.'**
  String get curveNeedsTwo;

  /// A reading that cannot be plotted, shown so somebody can fix it
  ///
  /// In id, this message translates to:
  /// **'Bacaan ini jam atau kedalamannya tidak terbaca - betulkan dari kantor.'**
  String get readingUnreadable;

  /// How many audit entries the collapsed trail holds
  ///
  /// In id, this message translates to:
  /// **'{n} perubahan'**
  String trailCount(int n);

  /// Title of the two-question sheet shown before the first truck
  ///
  /// In id, this message translates to:
  /// **'Sebelum TM pertama'**
  String get pourStartTitle;

  /// Question 1: what the QS can see, instead of a depth they must work out
  ///
  /// In id, this message translates to:
  /// **'Pipa tremie menyembul berapa meter di atas tanah?'**
  String get stickOutQuestion;

  /// Label of the stick-out field
  ///
  /// In id, this message translates to:
  /// **'Menyembul di atas tanah'**
  String get stickOutField;

  /// Shows the installed tremie length the depth is derived from
  ///
  /// In id, this message translates to:
  /// **'Pipa yang sudah tersusun {panjang}.'**
  String stickOutBasis(String panjang);

  /// What the app worked out from the stick-out, shown back for confirmation
  ///
  /// In id, this message translates to:
  /// **'Berarti ujung tremie di {dalam}, yaitu {celah} di atas dasar lubang.'**
  String stickOutResult(String dalam, String celah);

  /// The stick-out field was left empty
  ///
  /// In id, this message translates to:
  /// **'Isi dulu berapa meter pipa yang menyembul.'**
  String get stickOutRequired;

  /// The derived tremie bottom sits implausibly far above the hole bottom
  ///
  /// In id, this message translates to:
  /// **'Ujung tremie jadi {celah} di atas dasar lubang. Terlalu tinggi — periksa lagi.'**
  String stickOutTooHigh(String celah);

  /// The derived tremie bottom sits below the hole bottom
  ///
  /// In id, this message translates to:
  /// **'Ujung tremie jadi lebih dalam dari dasar lubang. Periksa lagi.'**
  String get stickOutTooDeep;

  /// Question 2 of the before-first-truck sheet
  ///
  /// In id, this message translates to:
  /// **'Mutu beton TM hari ini berapa?'**
  String get gradeQuestion;

  /// Go to the next question
  ///
  /// In id, this message translates to:
  /// **'Lanjut'**
  String get nextStep;

  /// Go back to the previous question
  ///
  /// In id, this message translates to:
  /// **'Kembali'**
  String get backStep;

  /// A truck's overbreak ratio jumped away from this pile's own pattern
  ///
  /// In id, this message translates to:
  /// **'Sounding tidak cocok dengan volume beton'**
  String get ratioOddTitle;

  /// Explains the jump by naming this truck and the earlier ones
  ///
  /// In id, this message translates to:
  /// **'TM ini keluar {ini}, padahal TM sebelumnya {pola}. Lubangnya sudah selesai dibor sebelum beton pertama masuk, jadi bentuknya tidak berubah di tengah cor — paling sering sebabnya sounding kebaca salah.'**
  String ratioOddBody(String ini, String pola);

  /// Same warning when there is no earlier truck to compare against
  ///
  /// In id, this message translates to:
  /// **'TM ini keluar {ini}, dan belum ada TM sebelumnya sebagai pembanding. Wajarnya antara −20% dan +100%; di luar itu biasanya soundingnya yang kebaca salah.'**
  String ratioOddAlone(String ini);

  /// Primary action: go back and measure the sounding again
  ///
  /// In id, this message translates to:
  /// **'Ukur ulang'**
  String get remeasure;

  /// Secondary action: keep the number as typed
  ///
  /// In id, this message translates to:
  /// **'Tetap simpan'**
  String get saveAnyway;

  /// Step 1 of the arriving-truck questions
  ///
  /// In id, this message translates to:
  /// **'TM-nya nomor lambung berapa?'**
  String get qTruckNo;

  /// Step 2 of the arriving-truck questions
  ///
  /// In id, this message translates to:
  /// **'Berapa kubik beton di TM ini?'**
  String get qVolume;

  /// Step 3 of the arriving-truck questions
  ///
  /// In id, this message translates to:
  /// **'Beton dari pemasok mana?'**
  String get qSupplier;

  /// Step 4 — the slump TESTED on site, not the one printed on the delivery note
  ///
  /// In id, this message translates to:
  /// **'Slump hasil ujinya berapa?'**
  String get qSlump;

  /// Last step of the arriving-truck questions
  ///
  /// In id, this message translates to:
  /// **'Foto surat jalannya'**
  String get qPhoto;

  /// Shown on the last step when the supplier was carried over and not asked again
  ///
  /// In id, this message translates to:
  /// **'Masih {nama}, sama seperti TM sebelumnya.'**
  String supplierSameAsBefore(String nama);

  /// Reopen a question that was answered from the previous truck
  ///
  /// In id, this message translates to:
  /// **'Ubah'**
  String get changeIt;

  /// Sheet that collects whatever is still missing before a casting log may be closed
  ///
  /// In id, this message translates to:
  /// **'Lengkapi dulu'**
  String get lengkapiTitle;

  /// One line under the title of the completion sheet
  ///
  /// In id, this message translates to:
  /// **'Catatan cor belum bisa ditutup. Isi yang kurang di bawah ini, lalu lanjut.'**
  String get lengkapiBody;

  /// The sounding taken before the first truck, asked at closing time when it was skipped
  ///
  /// In id, this message translates to:
  /// **'Sebelum TM pertama dituang, dari muka tanah ke muka beton berapa meter?'**
  String get qSoundingAwal;

  /// Measured depth of the tremie bottom end when casting starts
  ///
  /// In id, this message translates to:
  /// **'Kedalaman ujung tremie dari GS'**
  String get tremieDepthField;

  /// Helper under the tremie depth field
  ///
  /// In id, this message translates to:
  /// **'Diukur saat tremie sudah tersusun, sebelum TM pertama. Dasar lubang {dasar}; celahnya dihitung dari sini.'**
  String tremieDepthHint(String dasar);

  /// The tremie depth field was left empty
  ///
  /// In id, this message translates to:
  /// **'Isi kedalaman ujung tremie dulu.'**
  String get tremieDepthRequired;

  /// The typed tremie depth is not plausible
  ///
  /// In id, this message translates to:
  /// **'Ujung tremie harus di antara dasar lubang ({dasar}) dan 5 m di atasnya.'**
  String tremieDepthInvalid(String dasar);

  /// Blocks finishing the casting until the first truck's before-sounding is recorded
  ///
  /// In id, this message translates to:
  /// **'Sounding sebelum TM #1 belum diisi — tanpa itu tertanam awalnya tidak pernah ada.'**
  String get soundingBeforeNeeded;

  /// Server rejected the casting because the first before-sounding is missing
  ///
  /// In id, this message translates to:
  /// **'Sounding sebelum TM pertama belum diisi'**
  String get reasonSoundingAwalKosong;

  /// Server rejected the measured tremie depth
  ///
  /// In id, this message translates to:
  /// **'Kedalaman ujung tremie tidak masuk akal terhadap dasar lubang'**
  String get reasonTremieDalamSalah;

  /// actualX
  ///
  /// In id, this message translates to:
  /// **'X aktual'**
  String get actualX;

  /// actualY
  ///
  /// In id, this message translates to:
  /// **'Y aktual'**
  String get actualY;

  /// actualXRequired
  ///
  /// In id, this message translates to:
  /// **'X aktual — wajib'**
  String get actualXRequired;

  /// actualYRequired
  ///
  /// In id, this message translates to:
  /// **'Y aktual — wajib'**
  String get actualYRequired;

  /// actualXYRequiredMsg
  ///
  /// In id, this message translates to:
  /// **'Isi X dan Y aktual pusat lubang. Diukur setelah pengeboran selesai.'**
  String get actualXYRequiredMsg;

  /// actualXYBothMsg
  ///
  /// In id, this message translates to:
  /// **'X dan Y harus diisi dua-duanya.'**
  String get actualXYBothMsg;

  /// actualXYInvalid
  ///
  /// In id, this message translates to:
  /// **'Koordinat tidak sah.'**
  String get actualXYInvalid;

  /// designXYTitle
  ///
  /// In id, this message translates to:
  /// **'Koordinat rencana'**
  String get designXYTitle;

  /// designXYBody
  ///
  /// In id, this message translates to:
  /// **'X {x} · Y {y}'**
  String designXYBody(String x, String y);

  /// deviationBody
  ///
  /// In id, this message translates to:
  /// **'Simpangan {simpangan}, toleransi {toleransi}.'**
  String deviationBody(String simpangan, String toleransi);

  /// deviationOverTitle
  ///
  /// In id, this message translates to:
  /// **'Simpangan {simpangan} melewati toleransi'**
  String deviationOverTitle(String simpangan);

  /// deviationOverBody
  ///
  /// In id, this message translates to:
  /// **'Toleransi proyek ini {toleransi}. Periksa angkanya sebelum menyimpan — kalau benar, laporkan ke kantor.'**
  String deviationOverBody(String toleransi);

  /// castDoneTitle
  ///
  /// In id, this message translates to:
  /// **'Sudah selesai dicor'**
  String get castDoneTitle;

  /// castDoneVolume
  ///
  /// In id, this message translates to:
  /// **'Beton terkirim'**
  String get castDoneVolume;

  /// castDonePlanned
  ///
  /// In id, this message translates to:
  /// **'Teoritis rencana'**
  String get castDonePlanned;

  /// castDoneVsPlanned
  ///
  /// In id, this message translates to:
  /// **'{rencana} m³ ({selisih}%)'**
  String castDoneVsPlanned(String rencana, String selisih);

  /// castDoneTrucks
  ///
  /// In id, this message translates to:
  /// **'Jumlah TM'**
  String get castDoneTrucks;

  /// castDoneTopDepth
  ///
  /// In id, this message translates to:
  /// **'Muka beton terakhir tercatat'**
  String get castDoneTopDepth;

  /// castDoneHoleDepth
  ///
  /// In id, this message translates to:
  /// **'Kedalaman lubang'**
  String get castDoneHoleDepth;

  /// castDoneAt
  ///
  /// In id, this message translates to:
  /// **'Selesai cor'**
  String get castDoneAt;

  /// finishTruckAction
  ///
  /// In id, this message translates to:
  /// **'Selesai TM'**
  String get finishTruckAction;

  /// notifSoundingDue
  ///
  /// In id, this message translates to:
  /// **'TM {seq} selesai — sounding belum diisi'**
  String notifSoundingDue(String seq);

  /// notifSoundingDueBody
  ///
  /// In id, this message translates to:
  /// **'Buka catatan cor di HP dan isi sounding muka beton sesudah tuang. Tertanam tremie dan pemeriksaan volume dihitung dari angka itu.'**
  String get notifSoundingDueBody;

  /// No description provided for @drillLockedConfirmedTitle.
  ///
  /// In id, this message translates to:
  /// **'Sudah diperiksa kantor — terkunci'**
  String get drillLockedConfirmedTitle;

  /// No description provided for @drillLockedConfirmedBody.
  ///
  /// In id, this message translates to:
  /// **'Titik ini sudah diperiksa dan disetujui, jadi catatan bornya tidak bisa diubah lagi. Kalau ada angka yang salah, minta kantor membuka konfirmasinya dulu.'**
  String get drillLockedConfirmedBody;

  /// No description provided for @drillLockedCastTitle.
  ///
  /// In id, this message translates to:
  /// **'Sudah dicor — terkunci'**
  String get drillLockedCastTitle;

  /// No description provided for @drillLockedCastBody.
  ///
  /// In id, this message translates to:
  /// **'Betonnya sudah masuk, jadi catatan bor ini tertutup untuk selamanya. Tidak ada lagi yang bisa diubah di layar ini.'**
  String get drillLockedCastBody;

  /// No description provided for @drillNeedGsTitle.
  ///
  /// In id, this message translates to:
  /// **'Isi ground level dulu'**
  String get drillNeedGsTitle;

  /// No description provided for @drillNeedGsBody.
  ///
  /// In id, this message translates to:
  /// **'Semua kedalaman dihitung turun dari ground level, jadi belum ada yang bisa dicatat sebelum itu terisi. Ketuk baris ground level di atas untuk mengisinya.'**
  String get drillNeedGsBody;

  /// No description provided for @blockedNeedGs.
  ///
  /// In id, this message translates to:
  /// **'Isi ground level dulu — ketuk baris di atas.'**
  String get blockedNeedGs;

  /// No description provided for @blockedConfirmed.
  ///
  /// In id, this message translates to:
  /// **'Sudah diperiksa kantor; catatan ini tidak bisa diubah lagi.'**
  String get blockedConfirmed;

  /// No description provided for @blockedCast.
  ///
  /// In id, this message translates to:
  /// **'Sudah dicor; catatan bor sudah tertutup untuk selamanya.'**
  String get blockedCast;

  /// No description provided for @blockedNeedTremie.
  ///
  /// In id, this message translates to:
  /// **'Susun pipa tremie dulu, baru tambah TM.'**
  String get blockedNeedTremie;

  /// No description provided for @tremieDepthFirst.
  ///
  /// In id, this message translates to:
  /// **'Ukur tremie dulu'**
  String get tremieDepthFirst;

  /// No description provided for @blockedNeedTremieDepth.
  ///
  /// In id, this message translates to:
  /// **'Ukur kedalaman ujung tremie dulu. Begitu beton masuk, angkanya tidak bisa diukur lagi.'**
  String get blockedNeedTremieDepth;

  /// No description provided for @drillReopenConfirmTitle.
  ///
  /// In id, this message translates to:
  /// **'Buka lagi catatan bor ini?'**
  String get drillReopenConfirmTitle;

  /// No description provided for @drillReopenConfirmBody.
  ///
  /// In id, this message translates to:
  /// **'Catatan ini sudah ditutup. Kalau dibuka lagi, kedalamannya bisa ditambah dan diubah, dan kantor akan melihat bahwa catatan ini pernah dibuka ulang. Lakukan hanya kalau memang ada angka yang salah.'**
  String get drillReopenConfirmBody;

  /// No description provided for @castReopenConfirmTitle.
  ///
  /// In id, this message translates to:
  /// **'Buka lagi catatan cor ini?'**
  String get castReopenConfirmTitle;

  /// No description provided for @castReopenConfirmBody.
  ///
  /// In id, this message translates to:
  /// **'Catatan ini sudah ditutup. Kalau dibuka lagi, TM dan volumenya bisa ditambah dan diubah, dan kantor akan melihat bahwa catatan ini pernah dibuka ulang. Lakukan hanya kalau memang ada angka yang salah.'**
  String get castReopenConfirmBody;

  /// supplierLocal
  ///
  /// In id, this message translates to:
  /// **'Lokal (site-mix, diaduk di lokasi)'**
  String get supplierLocal;

  /// supplierMustBePicked
  ///
  /// In id, this message translates to:
  /// **'Pilih pemasok dari daftar. Kalau pemasoknya belum ada di daftar, minta kantor menambahkannya — jangan diketik sendiri.'**
  String get supplierMustBePicked;

  /// supplierMissingTitle
  ///
  /// In id, this message translates to:
  /// **'Pemasoknya tidak ada di daftar?'**
  String get supplierMissingTitle;

  /// supplierMissingBody
  ///
  /// In id, this message translates to:
  /// **'Jangan diketik sendiri. Hubungi kantor supaya pemasoknya ditandai \"Pemasok beton\" dan PO proyek ini diterbitkan — nama yang diketik sendiri tidak pernah masuk rekap pemasok dan tidak cocok dengan surat jalan.'**
  String get supplierMissingBody;

  /// supplierTypedBefore
  ///
  /// In id, this message translates to:
  /// **'Nama ini diketik tangan pada versi lama — pilih pemasok yang benar dari daftar'**
  String get supplierTypedBefore;

  /// supplierLocalConfirmTitle
  ///
  /// In id, this message translates to:
  /// **'Pakai beton Lokal (site-mix)?'**
  String get supplierLocalConfirmTitle;

  /// supplierLocalConfirmBody
  ///
  /// In id, this message translates to:
  /// **'Artinya betonnya diaduk di lokasi, bukan dikirim batching plant — jadi catatan ini tidak akan punya pemasok dan tidak akan cocok dengan surat jalan mana pun. Kalau betonnya datang pakai TM, pilih pemasoknya dari daftar.'**
  String get supplierLocalConfirmBody;

  /// supplierLocalConfirmYes
  ///
  /// In id, this message translates to:
  /// **'Ya, site-mix'**
  String get supplierLocalConfirmYes;

  /// watchOpen
  ///
  /// In id, this message translates to:
  /// **'Pantau sekarang'**
  String get watchOpen;

  /// watchTitle
  ///
  /// In id, this message translates to:
  /// **'Pantau {code}'**
  String watchTitle(String code);

  /// watchAsOf
  ///
  /// In id, this message translates to:
  /// **'per {jam} · {menit} menit lalu'**
  String watchAsOf(String jam, int menit);

  /// watchNoTimestamp
  ///
  /// In id, this message translates to:
  /// **'Belum ada catatan berjam dari HP pemegangnya'**
  String get watchNoTimestamp;

  /// watchOfflineTitle
  ///
  /// In id, this message translates to:
  /// **'Tidak bisa menarik data'**
  String get watchOfflineTitle;

  /// watchOfflineBody
  ///
  /// In id, this message translates to:
  /// **'Pantau membaca langsung dari server, jadi butuh sinyal. Tarik ke bawah untuk mencoba lagi.'**
  String get watchOfflineBody;

  /// watchNothingTitle
  ///
  /// In id, this message translates to:
  /// **'Belum ada yang dikerjakan di titik ini'**
  String get watchNothingTitle;

  /// watchNothingBody
  ///
  /// In id, this message translates to:
  /// **'Begitu HP pemegangnya mengirim bacaan atau TM pertama, kemajuannya muncul di sini.'**
  String get watchNothingBody;

  /// watchCastRunning
  ///
  /// In id, this message translates to:
  /// **'Sedang dicor'**
  String get watchCastRunning;

  /// watchCastDone
  ///
  /// In id, this message translates to:
  /// **'Cor selesai'**
  String get watchCastDone;

  /// watchPouringNow
  ///
  /// In id, this message translates to:
  /// **'TM {seq} sedang dituang'**
  String watchPouringNow(String seq);

  /// watchTrucks
  ///
  /// In id, this message translates to:
  /// **'TM masuk'**
  String get watchTrucks;

  /// watchVolume
  ///
  /// In id, this message translates to:
  /// **'Volume'**
  String get watchVolume;

  /// watchConcreteLevel
  ///
  /// In id, this message translates to:
  /// **'Muka beton dari GS'**
  String get watchConcreteLevel;

  /// watchNotSounded
  ///
  /// In id, this message translates to:
  /// **'belum disounding'**
  String get watchNotSounded;

  /// watchEmbedment
  ///
  /// In id, this message translates to:
  /// **'Tremie tertanam'**
  String get watchEmbedment;

  /// watchDrillRunning
  ///
  /// In id, this message translates to:
  /// **'Sedang dibor'**
  String get watchDrillRunning;

  /// watchDrillDone
  ///
  /// In id, this message translates to:
  /// **'Bor selesai'**
  String get watchDrillDone;

  /// watchCurveWaitTitle
  ///
  /// In id, this message translates to:
  /// **'Kurvanya butuh dua bacaan'**
  String get watchCurveWaitTitle;

  /// watchCurveWaitBody
  ///
  /// In id, this message translates to:
  /// **'Dengan satu bacaan belum ada rentang waktu yang bisa digambar. Muncul sendiri begitu bacaan kedua masuk.'**
  String get watchCurveWaitBody;

  /// watchDepth
  ///
  /// In id, this message translates to:
  /// **'Kedalaman'**
  String get watchDepth;

  /// watchRate
  ///
  /// In id, this message translates to:
  /// **'Laju rata-rata'**
  String get watchRate;

  /// watchReadings
  ///
  /// In id, this message translates to:
  /// **'Bacaan'**
  String get watchReadings;

  /// truckTableTitle
  ///
  /// In id, this message translates to:
  /// **'Truk mixer ({n})'**
  String truckTableTitle(String n);

  /// truckColSeq
  ///
  /// In id, this message translates to:
  /// **'TM'**
  String get truckColSeq;

  /// truckColPour
  ///
  /// In id, this message translates to:
  /// **'Tuang'**
  String get truckColPour;

  /// truckColVolume
  ///
  /// In id, this message translates to:
  /// **'Volume'**
  String get truckColVolume;

  /// truckColCumulative
  ///
  /// In id, this message translates to:
  /// **'Kumulatif'**
  String get truckColCumulative;

  /// truckArrivedAt
  ///
  /// In id, this message translates to:
  /// **'datang {jam}'**
  String truckArrivedAt(String jam);

  /// photoExpired
  ///
  /// In id, this message translates to:
  /// **'Foto ini sudah lewat masa simpannya di server.'**
  String get photoExpired;

  /// photoFailed
  ///
  /// In id, this message translates to:
  /// **'Foto tidak dapat dimuat. Periksa sinyal, lalu coba lagi.'**
  String get photoFailed;

  /// truckShare
  ///
  /// In id, this message translates to:
  /// **'Bagikan'**
  String get truckShare;

  /// shareNoPhoto
  ///
  /// In id, this message translates to:
  /// **'Foto surat jalan tidak dapat diambil — teksnya saja yang dibagikan.'**
  String get shareNoPhoto;

  /// sheetSupplier
  ///
  /// In id, this message translates to:
  /// **'Beton per pemasok'**
  String get sheetSupplier;

  /// sheetSupplierBody
  ///
  /// In id, this message translates to:
  /// **'Tiap pemasok satu lembar: TM, surat jalan, volume, dan totalnya.'**
  String get sheetSupplierBody;

  /// Judul banner saat login terkunci sementara (429)
  ///
  /// In id, this message translates to:
  /// **'Terkunci sementara'**
  String get loginLockedTitle;

  /// Isi banner; {sisa} berbentuk "14:03"
  ///
  /// In id, this message translates to:
  /// **'Terlalu banyak percobaan masuk. Tombol Masuk hidup lagi dalam {sisa}. Menekannya sekarang tidak memperpanjang kunci, tetapi juga tidak mempercepatnya.'**
  String loginLockedBody(String sisa);

  /// Tulisan tombol Masuk selama terkunci; {sisa} berbentuk "14:03"
  ///
  /// In id, this message translates to:
  /// **'Tunggu {sisa}'**
  String loginLockedButton(String sisa);

  /// Judul banner saat koordinat diketik tanpa koma
  ///
  /// In id, this message translates to:
  /// **'Komanya terlewat?'**
  String get koordinatKomaJudul;

  /// Isi banner; {nama} sumbu X/Y, {diketik}/{rencana}/{maks} jumlah angka
  ///
  /// In id, this message translates to:
  /// **'{nama} aktual diketik {diketik} angka sebelum koma, sedangkan koordinat rencana titik ini {rencana} angka. Isian berhenti menerima angka pada {maks} — bukan rusak, melainkan penuh. Ketik komanya sesudah {rencana} angka, lalu angka desimalnya.'**
  String koordinatKomaIsi(String nama, int diketik, int rencana, int maks);

  /// Tooltip tombol kosongkan pada isian koordinat
  ///
  /// In id, this message translates to:
  /// **'Kosongkan isian ini'**
  String get koordinatKosongkan;

  /// swipeToFinishDrilling
  ///
  /// In id, this message translates to:
  /// **'Geser untuk selesai bor'**
  String get swipeToFinishDrilling;

  /// swipeToFinishCasting
  ///
  /// In id, this message translates to:
  /// **'Geser untuk selesai cor'**
  String get swipeToFinishCasting;

  /// swipeDone
  ///
  /// In id, this message translates to:
  /// **'Tersimpan'**
  String get swipeDone;

  /// entityGateTicket
  ///
  /// In id, this message translates to:
  /// **'Catatan gerbang'**
  String get entityGateTicket;

  /// gateRecordTruck
  ///
  /// In id, this message translates to:
  /// **'Gerbang: catat TM masuk'**
  String get gateRecordTruck;

  /// gateTitle
  ///
  /// In id, this message translates to:
  /// **'TM masuk gerbang · {code}'**
  String gateTitle(String code);

  /// gateIntroTitle
  ///
  /// In id, this message translates to:
  /// **'Ketik persis seperti di badan truk'**
  String get gateIntroTitle;

  /// gateIntroBody
  ///
  /// In id, this message translates to:
  /// **'Nomor ini yang memasangkan catatan gerbang dengan TM yang dituang di lubang.'**
  String get gateIntroBody;

  /// gateVolume
  ///
  /// In id, this message translates to:
  /// **'Volume di surat jalan'**
  String get gateVolume;

  /// gateGrade
  ///
  /// In id, this message translates to:
  /// **'Mutu beton (fc\')'**
  String get gateGrade;

  /// gateGradeInvalid
  ///
  /// In id, this message translates to:
  /// **'Mutu beton tidak masuk akal (1–150 MPa).'**
  String get gateGradeInvalid;

  /// gateRejected
  ///
  /// In id, this message translates to:
  /// **'TM ini ditolak di gerbang'**
  String get gateRejected;

  /// gateRejectedTitle
  ///
  /// In id, this message translates to:
  /// **'TM yang ditolak tidak dituang'**
  String get gateRejectedTitle;

  /// gateRejectedBody
  ///
  /// In id, this message translates to:
  /// **'Catatannya tetap tersimpan sebagai bukti, tetapi volumenya tidak masuk ke log cor titik ini.'**
  String get gateRejectedBody;

  /// gateRejectReason
  ///
  /// In id, this message translates to:
  /// **'Alasan ditolak'**
  String get gateRejectReason;

  /// gateRejectReasonRequired
  ///
  /// In id, this message translates to:
  /// **'Isi alasan TM ini ditolak.'**
  String get gateRejectReasonRequired;

  /// gateTruckRequired
  ///
  /// In id, this message translates to:
  /// **'Isi nomor lambung TM.'**
  String get gateTruckRequired;

  /// gatePhotoRequired
  ///
  /// In id, this message translates to:
  /// **'Foto surat jalannya dulu.'**
  String get gatePhotoRequired;

  /// gateSaved
  ///
  /// In id, this message translates to:
  /// **'TM {truck} dicatat. Terkirim otomatis saat ada sinyal.'**
  String gateSaved(String truck);

  /// startPourOnlyLog
  ///
  /// In id, this message translates to:
  /// **'Mulai log cor — di lubang saja'**
  String get startPourOnlyLog;

  /// pourTruckNoTitle
  ///
  /// In id, this message translates to:
  /// **'Nomor TM adalah kuncinya'**
  String get pourTruckNoTitle;

  /// pourTruckNoBody
  ///
  /// In id, this message translates to:
  /// **'Pilih nomor TM yang sudah dicatat di gerbang, atau ketik persis seperti di badan truk. Volume, slump, dan surat jalannya menempel dari catatan gerbang lewat nomor ini.'**
  String get pourTruckNoBody;

  /// pourTruckNoBodyEmpty
  ///
  /// In id, this message translates to:
  /// **'Catatan gerbang untuk titik ini belum sampai ke HP ini. Ketik nomor TM persis seperti di badan truk; volume, slump, dan surat jalannya menempel dari catatan gerbang lewat nomor ini.'**
  String get pourTruckNoBodyEmpty;

  /// gateQGrade
  ///
  /// In id, this message translates to:
  /// **'Mutu betonnya berapa?'**
  String get gateQGrade;

  /// gateQSummary
  ///
  /// In id, this message translates to:
  /// **'Sudah benar semua?'**
  String get gateQSummary;

  /// gateRejectAction
  ///
  /// In id, this message translates to:
  /// **'Tolak TM ini'**
  String get gateRejectAction;

  /// gateOtherPileTitle
  ///
  /// In id, this message translates to:
  /// **'TM {truck} juga dituang ke lubang lain?'**
  String gateOtherPileTitle(String truck);

  /// gateOtherPileBody
  ///
  /// In id, this message translates to:
  /// **'Kalau satu TM dibagi ke dua lubang, catat juga di lubang berikutnya. Nomor TM, foto surat jalan, slump, dan mutunya disalin — tinggal isi volumenya.'**
  String get gateOtherPileBody;

  /// gateOtherPileNo
  ///
  /// In id, this message translates to:
  /// **'Tidak, selesai'**
  String get gateOtherPileNo;

  /// gateOtherPilePick
  ///
  /// In id, this message translates to:
  /// **'Ya — ketuk lubang berikutnya:'**
  String get gateOtherPilePick;

  /// gateOtherPileSearch
  ///
  /// In id, this message translates to:
  /// **'Cari kode titik'**
  String get gateOtherPileSearch;

  /// gateCopiedTitle
  ///
  /// In id, this message translates to:
  /// **'TM {truck} lanjut ke titik ini'**
  String gateCopiedTitle(String truck);

  /// gateCopiedBody
  ///
  /// In id, this message translates to:
  /// **'Isi volume yang dituang DI TITIK INI saja, bukan seluruh isi TM.'**
  String get gateCopiedBody;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['en', 'id', 'zh'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'en':
      return AppLocalizationsEn();
    case 'id':
      return AppLocalizationsId();
    case 'zh':
      return AppLocalizationsZh();
  }

  throw FlutterError(
    'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
    'an issue with the localizations generation tool. Please file an issue '
    'on GitHub with a reproducible sample app and the gen-l10n configuration '
    'that was used.',
  );
}
