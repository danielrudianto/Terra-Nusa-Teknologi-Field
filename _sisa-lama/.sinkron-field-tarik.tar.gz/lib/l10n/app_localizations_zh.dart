// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Chinese (`zh`).
class AppLocalizationsZh extends AppLocalizations {
  AppLocalizationsZh([String locale = 'zh']) : super(locale);

  @override
  String get appTitle => 'TerraBot Field';

  @override
  String get navHome => '首页';

  @override
  String get navAttendance => '考勤';

  @override
  String get navCasting => '浇筑';

  @override
  String get navQueue => '待发送';

  @override
  String get navSettings => '设置';

  @override
  String get navAttendanceSoon => '考勤功能尚未开放——敬请期待。';

  @override
  String get comingSoon => '敬请期待';

  @override
  String homeGreeting(String name) {
    return '你好，$name';
  }

  @override
  String get homeTagline => '辛苦了。没有信号也会先存在手机里。';

  @override
  String get homePickProject => '选择我的项目';

  @override
  String get homeAllSent => '全部已发送';

  @override
  String homePending(int count) {
    return '$count 项待发送';
  }

  @override
  String get homeWatched => '正在跟进';

  @override
  String homeWatchedCount(int count) {
    return '$count 条记录';
  }

  @override
  String get homeDrillRunning => '钻孔记录进行中';

  @override
  String get homeCastRunning => '浇筑记录进行中';

  @override
  String get labelDrill => '钻孔';

  @override
  String get labelCast => '浇筑';

  @override
  String get shortcutAttendance => '班组考勤';

  @override
  String get shortcutAttendanceBody => '上下班拍照，勾选到场的班组成员';

  @override
  String get shortcutCasting => '钻孔与浇筑记录';

  @override
  String get shortcutCastingBody => '逐桩记录钻孔深度、罐车、导管与测绳';

  @override
  String get shortcutWorkers => '工人';

  @override
  String get shortcutWorkersBody => '按项目查看全部工人，登记新工人';

  @override
  String get shortcutReports => '现场报表';

  @override
  String get shortcutReportsBody => '今天、昨天或一周内已钻孔与已浇筑的桩';

  @override
  String get settingsLanguage => '语言';

  @override
  String get settingsLanguageBody => '应用显示语言。现场专业术语在各语言中保持一致。';

  @override
  String get languageSystem => '跟随手机';

  @override
  String get languageIndonesian => 'Indonesia';

  @override
  String get languageEnglish => 'English';

  @override
  String get languageChinese => '中文';

  @override
  String get settingsTitle => '设置';

  @override
  String settingsLevel(String n) {
    return '等级 $n';
  }

  @override
  String get sectionAppearance => '显示';

  @override
  String get sectionMyProject => '我的项目';

  @override
  String get sectionNotifications => '通知';

  @override
  String get sectionAccount => '账号';

  @override
  String get sectionAbout => '关于';

  @override
  String get settingsTheme => '主题';

  @override
  String get themeSystem => '跟随手机';

  @override
  String get themeLight => '浅色';

  @override
  String get themeDark => '深色';

  @override
  String get settingsAccent => '强调色';

  @override
  String get accentBlue => '蓝色';

  @override
  String get accentOrange => '橙色';

  @override
  String get accentTeal => '青色';

  @override
  String get accentPurple => '紫色';

  @override
  String get settingsTextSize => '文字大小';

  @override
  String get textSizeNormal => '标准';

  @override
  String get textSizeLarge => '大';

  @override
  String get textSizeHuge => '特大';

  @override
  String get myProjectBodyAttendance => '考勤、新增工人和灌注记录默认使用此项目，各页面仍可更改。';

  @override
  String get myProjectBody => '钻孔与灌注桩位列表将优先显示此项目。';

  @override
  String get myProjectSaved => '已保存我的项目。';

  @override
  String get myProjectCleared => '已清除我的项目。';

  @override
  String get projectsLoadFailed => '无法读取项目列表';

  @override
  String get projectsMissingTitle => '手机上还没有项目列表';

  @override
  String get projectsMissingBody => '在首页下拉即可从服务器获取，只需一次网络连接。';

  @override
  String get notifTitle => '震动提醒';

  @override
  String get notifOn =>
      '已开启。罐车超过 20 分钟及浇筑暂停期间手机会振动。已与手机配对的手表同样会收到提醒和\"结束罐车\"按钮——此处无需额外设置。';

  @override
  String get notifOff => '已关闭。点按授权；否则灌注提醒不会出现。';

  @override
  String get notifBlockedTitle => '提醒将不会出现';

  @override
  String get notifBlockedBody =>
      '本手机尚未允许 TerraBot Field 显示通知。超过 20 分钟的罐车、暂停的浇筑、未关闭的钻孔记录，所有提醒都不会响。请点按「允许」。';

  @override
  String get notifAllow => '允许';

  @override
  String get notifAllowManual =>
      '通知仍被手机关闭。请打开手机设置 → 应用 → TerraBot Field → 通知，并将其打开。';

  @override
  String get powerTitle => '电池与自启动';

  @override
  String get powerOk => '无限制。息屏时提醒与自动上传仍会运行。';

  @override
  String get powerRestricted => '仍被系统限制。点按设置，以免错过灌注提醒。';

  @override
  String get reloadPermissions => '重新载入权限';

  @override
  String get reloadPermissionsBody => '当办公室更改您的等级或部门后使用。';

  @override
  String get permissionsReloaded => '权限已重新载入。';

  @override
  String logoutPendingTitle(int docs, int photos) {
    return '仍有 $docs 条记录和 $photos 张照片未上传';
  }

  @override
  String get logoutPendingBody => '退出不会删除它们，重新登录后会继续上传。但在本机登录的其他人无法上传这些数据。';

  @override
  String get logout => '退出';

  @override
  String get logoutConfirm => '退出登录？';

  @override
  String get logoutConfirmBody => '重新登录需要网络连接。';

  @override
  String get cancel => '取消';

  @override
  String get appVersion => '应用版本';

  @override
  String serverLabel(String host) {
    return '服务器 $host';
  }

  @override
  String deviceIdLabel(String id) {
    return '设备 ID $id';
  }

  @override
  String get sendLog => '发送日志给管理员';

  @override
  String get sendLogBody => '应用出现问题时：发送本机错误日志，不含个人数据。';

  @override
  String get noLogYet => '本机尚无错误日志。';

  @override
  String logShareFailed(String error) {
    return '日志分享失败：$error';
  }

  @override
  String get castingTitle => '灌注记录';

  @override
  String get projectsLoadError => '无法读取项目';

  @override
  String get pickProject => '选择项目';

  @override
  String get pickProjectBody => '桩位由办公室依施工图录入';

  @override
  String get noCastingProjects => '手机上还没有灌注项目。有网络时下拉获取。';

  @override
  String get myProjectTag => '我的项目';

  @override
  String pointCount(int n) {
    return '$n 个桩位';
  }

  @override
  String get pointsTitle => '钻孔桩位';

  @override
  String pointsTitleOf(String code) {
    return '$code · 钻孔桩位';
  }

  @override
  String get toTop => '回到顶部';

  @override
  String get pointsLoadError => '无法读取桩位';

  @override
  String get noPointsTitle => '还没有钻孔桩位';

  @override
  String get noPointsBody => '桩位由办公室录入（在 TerraBot 网页端导入 Excel）。在上一页下拉以获取最新数据。';

  @override
  String get searchPointCode => '搜索桩位编号';

  @override
  String get clear => '清除';

  @override
  String get filterAll => '全部';

  @override
  String get filterUndrilled => '未钻孔';

  @override
  String get filterDrilled => '已钻孔';

  @override
  String get filterCast => '已灌注';

  @override
  String castProgress(int done, int total) {
    return '$total 个桩位中已灌注 $done 个';
  }

  @override
  String get noMatchingPoints => '没有匹配的桩位。';

  @override
  String get stageCasting => '正在灌注';

  @override
  String get stageCast => '已灌注';

  @override
  String stageDrilled(String depth) {
    return '已钻 $depth';
  }

  @override
  String get stageDrilling => '正在钻孔';

  @override
  String get stageUndrilled => '未钻孔';

  @override
  String get gsMissingShort => '地面标高未填';

  @override
  String pointHeading(String code) {
    return '桩位 $code';
  }

  @override
  String get fieldDiameter => '桩径';

  @override
  String get fieldLevels => '地面 / 截桩 / 桩端标高';

  @override
  String get fieldCutOffDepth => '自地面起截桩深度';

  @override
  String get fieldPlannedDrill => '设计钻孔长度';

  @override
  String get fieldPlannedEff => '设计有效桩长';

  @override
  String get fieldPlannedVol => '设计理论方量';

  @override
  String get fieldActualDrill => '实际钻孔深度';

  @override
  String get gsMissingTitle => '地面标高未填写';

  @override
  String get gsMissingBody => '尚无法计算自地面起的深度，须填写地面标高后方可开始灌注记录。标记该桩已钻孔时一并填写。';

  @override
  String get notFilled => '未填写';

  @override
  String get castLogExists => '该桩位已有灌注记录';

  @override
  String get castLogOnMyOther => '灌注记录在您的另一台手机上';

  @override
  String get castLogElsewhere => '正在由其他手机记录灌注';

  @override
  String castLogHeldBody(String who) {
    return '灌注记录由 $who 持有。一个桩位只能有一份灌注记录。若该记录有误，请先让办公室删除。';
  }

  @override
  String get logIsMineBody => '该记录由您本人的账号持有，只是内容不在本机。无需交接码即可取回。';

  @override
  String castLogHandoverBody(String who) {
    return '灌注记录由 $who 持有。一个桩位只能有一份灌注记录。若要在本机继续，请让对方点按\"交接给同事\"并在此输入验证码。';
  }

  @override
  String get takeToThisPhone => '取到本机';

  @override
  String get continueHereCode => '在本机继续（交接码）';

  @override
  String get drillLogOnMyOther => '钻孔记录在您的另一台手机上';

  @override
  String get drillLogElsewhere => '正在由其他手机记录钻孔';

  @override
  String drillLogHandoverBody(String who) {
    return '钻孔记录由 $who 持有。一个桩位只能有一份钻孔记录。若要在本机继续，请让对方点按\"交接给同事\"并在此输入验证码。';
  }

  @override
  String get drillFirstTitle => '请先记录钻孔';

  @override
  String get castAfterDrillLog => '钻孔记录以\"完成钻孔\"结束后，方可开始灌注记录。';

  @override
  String get castAfterDrilled => '该桩位完成钻孔后方可开始灌注记录：可通过钻孔记录，或直接标记。';

  @override
  String get viewOnlyTitle => '仅可查看';

  @override
  String get viewOnlyCastBody => '此账号无权记录灌注。';

  @override
  String get continueDrillLog => '继续钻孔记录';

  @override
  String get viewDrillLog => '查看钻孔记录';

  @override
  String get startDrillLog => '开始钻孔记录';

  @override
  String get markDrilledNoLog => '标记为已钻孔（无记录）';

  @override
  String get correctDrillGs => '修正钻孔深度 / 地面标高';

  @override
  String get openCastLog => '打开灌注记录';

  @override
  String get startCastLog => '开始灌注记录';

  @override
  String get confirmPointCodeTitle => '请输入桩号';

  @override
  String get confirmPointCodeBody => '请看您即将灌注的桩，而不是手机上的列表。您在此输入的桩号可防止记录录入邻桩。';

  @override
  String get confirmPointCodeField => '桩号';

  @override
  String get confirmPointCodeConfirm => '正确，开始灌注';

  @override
  String confirmPointCodeMismatch(String selected, String typed) {
    return '您在列表中选择了 $selected，但输入的是 $typed。如果 $typed 才是正确的，请关闭此窗口并在列表中选择它。';
  }

  @override
  String get colleague => '同事';

  @override
  String markedDrilled(String code, String depth) {
    return '$code 已标记为钻孔 $depth。';
  }

  @override
  String get gsInvalid => '地面标高无效。';

  @override
  String get gsRequiredMsg => '请填写该桩位的地面标高，否则无法开始灌注记录。';

  @override
  String get drillDepthInvalid => '请填写钻孔深度（米），须大于 0。';

  @override
  String drillDepthTooDeep(String max) {
    return '最大深度为 $max，请检查数值。';
  }

  @override
  String markDrilledTitle(String code) {
    return '标记 $code 已钻孔';
  }

  @override
  String get checkInput => '请检查填写内容';

  @override
  String get gsFieldRequired => '地面标高（米）— 必填';

  @override
  String get gsField => '地面标高（米）';

  @override
  String get cutOffAboveGsTitle => '截桩标高高于地面';

  @override
  String cutOffAboveGsBody(String col) {
    return '截桩标高 $col 高于此地面标高。保存前请确认地面标高数值无误。';
  }

  @override
  String get drillDepthField => '钻孔深度（米）';

  @override
  String beyondPlanTitle(String over) {
    return '超出设计 $over';
  }

  @override
  String beyondPlanBody(String planned) {
    return '设计值 $planned。略微超出可以接受；请确认确需钻得更深。';
  }

  @override
  String get save => '保存';

  @override
  String get drillLogWord => '钻孔记录';

  @override
  String get castLogWord => '灌注记录';

  @override
  String sendingFirst(String log) {
    return '正在先上传$log…';
  }

  @override
  String get sendBeforeHandoverTitle => '交接前请先上传';

  @override
  String sendBeforeHandoverBody(String log) {
    return '该$log尚未上传到服务器，因此无法交接。请稍候连上网络后重试——同事将收到最新的完整内容。';
  }

  @override
  String get understood => '明白';

  @override
  String get askingCode => '正在获取交接码…';

  @override
  String handoverTitle(String log, String code) {
    return '交接$log $code';
  }

  @override
  String handoverBody(String code) {
    return '请同事在其手机上打开桩位 $code 并选择\"在本机继续\"，然后告知此验证码：';
  }

  @override
  String codeValidFor(int minutes) {
    return '有效期 $minutes 分钟，一次性使用';
  }

  @override
  String get codeValidBody => '对方输入后，记录即转交给他，本机转为只读。本机拍摄的照片仍从这里上传。';

  @override
  String get done => '完成';

  @override
  String takeLogHere(String log, String code) {
    return '将$log $code 取到本机';
  }

  @override
  String takeLogHereBody(String log) {
    return '该$log确实由您的账号持有，只是内容不在本机，无需交接码。\n\n若该记录正在您的另一台手机上打开，请只在一台手机上继续，以免填写冲突。';
  }

  @override
  String takingLog(String log) {
    return '正在获取$log…';
  }

  @override
  String logNowHere(String log, String code) {
    return '$log $code 现由本机持有。';
  }

  @override
  String continueLog(String log, String code) {
    return '继续$log $code';
  }

  @override
  String get enterHandoverCode => '请输入记录持有人告知的 6 位交接码（对方在其手机上点按\"交接给同事\"）。';

  @override
  String get takeOver => '接管';

  @override
  String get castLogNotOnPhone => '本机未找到该灌注记录。';

  @override
  String get pointNotOnPhone => '本机没有该桩位。有网络时请拉取最新数据。';

  @override
  String gsMissingFor(String code) {
    return '桩位 $code 的地面标高未填写。请返回桩位列表，选择\"标记为已钻孔\"并填写。';
  }

  @override
  String pointHasCastLog(String code, String by) {
    return '桩位 $code 已有灌注记录$by。一个桩位只能有一份灌注记录。';
  }

  @override
  String byWhom(String who) {
    return '（$who）';
  }

  @override
  String pointNotDrilled(String code) {
    return '桩位 $code 尚未标记为已钻孔。请返回桩位列表，选择\"标记为已钻孔\"并填写深度。';
  }

  @override
  String get notSignedIn => '未登录——未保存任何内容。';

  @override
  String get lockedByOffice => '该灌注记录已经办公室审核——无法再修改。';

  @override
  String heldByOther(String who) {
    return '该灌注记录由 $who 持有——请在持有者手机上修改。';
  }

  @override
  String get tremieTooLongTitle => '导管过长';

  @override
  String tremieTooLongAdd(String len, String stick, String max, String need) {
    return '加上这节 $len 米后，导管顶端高出地面 $stick（最高 $max，即料斗高度）。本孔只需 $need 导管。请重新核对已装节数。';
  }

  @override
  String get tremieBottomTitle => '导管底节';

  @override
  String get lengthM => '长度（米）';

  @override
  String get tremieBottomHint => '装在最底部的尖头节。请为本次灌注测量其长度。';

  @override
  String get topSegmentRemoved => '已从组装中移除最顶节。';

  @override
  String get segmentLength => '节长';

  @override
  String get dontPullYet => '暂不可拔管';

  @override
  String get embedTooShortTitle => '埋深不足';

  @override
  String embedAfterRemoval(String len, String after, String min) {
    return '拔掉这节 $len 米后，导管在混凝土中仅埋深 $after（至少需 $min）。新混凝土可能冲破混凝土面并与泥浆混合。';
  }

  @override
  String estimateSoundFirst(String text) {
    return '$text\n\n该混凝土面为估算值。如有疑问请先测绳探测。';
  }

  @override
  String get tickAnyway => '仍然勾选';

  @override
  String get pullUndone => '已取消拔管；该节重新装回。';

  @override
  String get pullTickTitle => '记录该节已拔出？';

  @override
  String pullTickBody(int pos, String panjang, int seq, String sisa) {
    return '第 $pos 节（$panjang 米）将记录为在第 $seq 车后拔出，埋深剩余 $sisa。该记录将作为证据写入成桩记录。';
  }

  @override
  String pullTickAfterPour(int seq) {
    return '第 $seq 车已浇筑完毕。若导管并未真正拔出，请勿记录。';
  }

  @override
  String pullRecorded(int seq) {
    return '该节记录为在第 $seq 车后拔出。';
  }

  @override
  String truckSaved(int seq) {
    return '第 $seq 车已保存。';
  }

  @override
  String truckUpdated(int seq) {
    return '第 $seq 车已更新。';
  }

  @override
  String get atCutOffTitle => '混凝土已达截桩标高';

  @override
  String atCutOffBody(String level, String cutoff, String over) {
    return '混凝土面自地面 $level，截桩标高 $cutoff$over。该桩通常到此即可结束。';
  }

  @override
  String overBy(String over) {
    return '（超出 $over）';
  }

  @override
  String get estimateFromVolume => '该数值由方量估算。请测绳探测以确认。';

  @override
  String get finishCasting => '完成灌注';

  @override
  String get addTruckAnyway => '仍然增加罐车';

  @override
  String soundingAfter(String seq) {
    return '第 $seq 车后测绳';
  }

  @override
  String soundingBefore(String seq) {
    return '第 $seq 车前测绳';
  }

  @override
  String get soundingQuestion => '自地面向下至混凝土面，多少米？';

  @override
  String get concreteDepthField => '自地面至混凝土面';

  @override
  String soundingHint(String est) {
    return '必须实测。按方量估算：$est。';
  }

  @override
  String soundingMissing(int seq) {
    return '第 $seq 车的测绳尚未填写。下一车之前必须填写。';
  }

  @override
  String truckStartTime(String seq) {
    return '第 $seq 车开始时间';
  }

  @override
  String truckEndTime(String seq) {
    return '第 $seq 车结束时间';
  }

  @override
  String soundingCleared(String seq) {
    return '已清除第 $seq 车的测绳。';
  }

  @override
  String soundingSaved(String seq, String value) {
    return '第 $seq 车测绳已保存：$value。';
  }

  @override
  String get tremieNotAtBottom => '导管未到孔底';

  @override
  String tremieTooLongNow(
    String fitted,
    String stick,
    String max,
    String need,
  ) {
    return '已装 $fitted，顶端高出地面 $stick（最高 $max）。本孔只需 $need。请先拆除多余节数。';
  }

  @override
  String tremieShortBody(String fitted, String need) {
    return '已装 $fitted，需 $need（孔底减去间隙）。请先加节：从高处倾落的混凝土会与泥浆混合。';
  }

  @override
  String notifPouring(String seq) {
    return '正在灌注第 $seq 车';
  }

  @override
  String notifTapToOpen(String vol) {
    return '$vol m³ · 点按打开灌注记录';
  }

  @override
  String pourStarted(String seq) {
    return '第 $seq 车已开始。计时器在通知栏运行。';
  }

  @override
  String notifTruckLate(String seq, int min, String code) {
    return '第 $seq 车已 $min 分钟 · $code';
  }

  @override
  String get notifTruckLateBody => '尚未灌注完成。请检查混凝土面与导管位置。';

  @override
  String notifPausedTitle(int seq) {
    return '第 $seq 车已暂停';
  }

  @override
  String notifPausedBody(String reason) {
    return '$reason · 点按继续';
  }

  @override
  String notifStillPaused(int seq, String code) {
    return '第 $seq 车仍在暂停 · $code';
  }

  @override
  String get notifStillPausedBody => '已恢复灌注？请在灌注记录中点按\"继续\"';

  @override
  String pourPaused(String reason) {
    return '灌注已暂停：$reason。';
  }

  @override
  String pourResumed(int seq) {
    return '第 $seq 车已继续。';
  }

  @override
  String notifNoNextTruck(String code) {
    return '还没有下一车 · $code';
  }

  @override
  String get notifNoNextTruckBody => '注意冷缝。请确认罐车到达时间';

  @override
  String truckFinished(int seq) {
    return '第 $seq 车灌注完成。';
  }

  @override
  String get castDataSaved => '灌注资料已保存。';

  @override
  String get finishNotStored => '完成状态未保存。请再次点按\"完成灌注\"。';

  @override
  String castFinished(String code) {
    return '$code 灌注完成。有网络时将自动上传。';
  }

  @override
  String get castReopened => '灌注记录已重新打开。完成后别忘了结束灌注。';

  @override
  String get cleanTremieTitle => '清洗导管与料斗';

  @override
  String get beforeNextUse => '下次使用前';

  @override
  String get cleanWhy => '残留在管内或接头处硬化的混凝土会在下次灌注时堵塞导管。';

  @override
  String get cleanStep1 => '冲洗料斗与每节导管，直至无混凝土残留。';

  @override
  String get cleanStep2 => '清洁接头与橡胶密封圈；损坏的密封圈须更换。';

  @override
  String get cleanStep3 => '请立即进行，以免混凝土硬化。';

  @override
  String get cleanStep4 => '归位码放，勿随意置于地面。';

  @override
  String get cleanedOk => '好的，已清洗';

  @override
  String castOf(String code) {
    return '$code 灌注';
  }

  @override
  String get handOverToMate => '交接给同事';

  @override
  String handedOverTo(String who) {
    return '已交接给 $who';
  }

  @override
  String handedOverBody(String who) {
    return '该灌注记录在 $who 的手机上继续。本机仅可查看；修改须在持有者手机上进行。';
  }

  @override
  String get rejectedByServer => '服务器已拒绝';

  @override
  String get reviewedByOffice => '办公室已审核';

  @override
  String officeNote(String note) {
    return '备注：$note';
  }

  @override
  String get cannotChangeAnymore => '该灌注记录无法再修改。';

  @override
  String get gradeMissingTitle => '混凝土强度等级（fc′）未填写';

  @override
  String get gradeMissingBody => '该桩位与项目均无默认强度等级。请在灌注资料中填写，否则服务器将拒收该记录。';

  @override
  String get finishNeedsGrade => '请先填写混凝土等级';

  @override
  String get fill => '填写';

  @override
  String get drillDepthUnmarked => '钻孔深度未标记';

  @override
  String get drillDepthUnmarkedBody => '计算采用设计钻孔长度。请在桩位列表标记实际深度，以便截桩建议准确。';

  @override
  String get tremieSection => '导管';

  @override
  String tremieSectionBody(String gap) {
    return '节数由下至上。下端距孔底 $gap。';
  }

  @override
  String get trucksSection => '混凝土罐车';

  @override
  String trucksSectionBody(int n, String vol) {
    return '$n 车 · $vol m³';
  }

  @override
  String get noTrucksYet => '还没有罐车';

  @override
  String get noTrucksReadOnly => '该灌注记录没有罐车。';

  @override
  String get noTrucksTremieFirst => '请先组装导管，首车到场时点按\"第 1 车到达\"。';

  @override
  String get noTrucksTapArrived => '首车到场时点按下方\"第 1 车到达\"。';

  @override
  String get pause => '暂停';

  @override
  String get resume => '继续';

  @override
  String finishTruck(String seq) {
    return '完成第 $seq 车';
  }

  @override
  String startTruck(String seq) {
    return '开始灌注第 $seq 车';
  }

  @override
  String get tremieFirst => '请先组装导管';

  @override
  String truckArrived(int seq) {
    return '第 $seq 车到达';
  }

  @override
  String get castDone => '灌注完成';

  @override
  String get savedAutoSend => '已保存，将自动上传。';

  @override
  String get reopen => '重新打开';

  @override
  String planNoPull(int seq) {
    return '第 $seq 车计划：无需拔管';
  }

  @override
  String planTitle(int seq) {
    return '第 $seq 车计划';
  }

  @override
  String planCutLine(String vol, String which, String before, String after) {
    return '• 约 $vol m³ 后：拔 $which → 埋深 $before → $after m';
  }

  @override
  String get joinThen => '，然后 ';

  @override
  String warnEmbedShort(String emb) {
    return '⚠ 本车前埋深仅 $emb m——请核对测绳。';
  }

  @override
  String warnNoSafePull(String vol) {
    return '⚠ 约 $vol m³ 后埋深超过 6 m，且没有可安全拔出的节段。';
  }

  @override
  String planEnd(String level, String emb, String cut) {
    return '本车结束估算：混凝土面 $level，埋深 $emb$cut。';
  }

  @override
  String get cutOffReachedSuffix => '——已达截桩标高';

  @override
  String usingOverbreak(String ratio) {
    return '采用前几车测绳得出的超灌系数 $ratio。';
  }

  @override
  String embedTitle(String emb, String est) {
    return '埋深 $emb$est';
  }

  @override
  String get estimateSuffix => '（估算）';

  @override
  String get notSoundedYet => '混凝土面尚未测绳——该数值由方量推算。拔管前请先测绳。';

  @override
  String get dontPullUnderOne => '不足 1 m：请勿拔管。导管可能脱离混凝土。';

  @override
  String get noPullNeeded => '目前无需拔管。';

  @override
  String pullSuggestion(String which, String after) {
    return '建议：拔 $which → 埋深 $after。拔出后请在导管列表中勾选。';
  }

  @override
  String get tick => '勾选';

  @override
  String get cellGrade => '强度 fc′';

  @override
  String get cellSupplier => '供应商';

  @override
  String get cellHoleBottom => '孔底';

  @override
  String get cellCutOff => '截桩标高';

  @override
  String get cellConcreteLevel => '混凝土面';

  @override
  String get cellTheoretical => '理论';

  @override
  String get cellUsed => '已用';

  @override
  String get cellOveruse => '超用';

  @override
  String get estimatedFootnote => '* 由方量估算';

  @override
  String tremieNeedFrom(String need) {
    return '需 $need。请先装底节（尖头）。';
  }

  @override
  String tremieOverLong(String stick, String max) {
    return '过长：顶端高出地面 $stick（最高 $max）。请拆除最顶节。';
  }

  @override
  String tremieAtBottom(String stick) {
    return '已到孔底。顶端高出地面 $stick（料斗处）。';
  }

  @override
  String tremieShortBy(String missing) {
    return '距孔底还差 $missing。';
  }

  @override
  String ofNeeded(String need) {
    return '共需 $need';
  }

  @override
  String get fitBottomPiece => '安装导管底节';

  @override
  String get other => '其他';

  @override
  String get removeTop => '移除顶节';

  @override
  String get pullTremieTitle => '拔导管';

  @override
  String get pullTremieBody => '对本车后拔出的每节点按\"拔出\"。上方示意图将随之更新。';

  @override
  String tremieBottomOf(String len) {
    return '导管底节 · $len m';
  }

  @override
  String pipeOf(String len) {
    return '管节 $len m';
  }

  @override
  String pulledAfterTruck(String seq) {
    return '第 $seq 车后拔出';
  }

  @override
  String get lowest => '最底部';

  @override
  String get pull => '拔出';

  @override
  String truckHeading(int seq, String vol) {
    return '第 $seq 车 · $vol m³';
  }

  @override
  String hullNo(String no) {
    return '车号 $no';
  }

  @override
  String ticketNo(String no) {
    return '送货单 $no';
  }

  @override
  String slumpOf(String cm) {
    return '坍落度 $cm cm';
  }

  @override
  String get tremieFitted => '已装导管';

  @override
  String get start => '开始';

  @override
  String get finish => '结束';

  @override
  String pausesCount(int n, String total) {
    return '$n 次 · $total';
  }

  @override
  String pauseLine(String reason, String from, String to) {
    return '$reason · $from–$to';
  }

  @override
  String get now => '现在';

  @override
  String get soundingBeforeLabel => '灌注前测绳';

  @override
  String get soundingAfterLabel => '灌注后测绳';

  @override
  String get soundingAfterRequired => '灌注后测绳为必填。请点按上方行。';

  @override
  String get overbreakRatio => '孔径大于设计';

  @override
  String get deliveryNote => '送货单';

  @override
  String get slumpTest => '坍落度试验';

  @override
  String get pausedLabel => '已暂停';

  @override
  String overMinutes(int min) {
    return '超过 $min 分钟';
  }

  @override
  String get pourTime => '灌注时间';

  @override
  String pauseTruckTitle(int seq) {
    return '暂停第 $seq 车';
  }

  @override
  String get pauseTruckBody => '为何暂停？灌注计时将停止，手机每 3 分钟震动一次，直到您点按\"继续\"。';

  @override
  String volumeInvalid(String max) {
    return '请填写罐车方量（m³），最大 $max。';
  }

  @override
  String volumeUnusual(String vol) {
    return '$vol m³ 大于常见值（5–7 m³）。请核对送货单；若无误，请再次点按\"保存罐车\"。';
  }

  @override
  String get slumpInvalid => '坍落度不合理（0–40 cm）。';

  @override
  String editTruck(int seq) {
    return '修改第 $seq 车';
  }

  @override
  String get photoTicket => '送货单照片';

  @override
  String get photoSlump => '坍落度试验照片';

  @override
  String get hullNoField => '罐车车号';

  @override
  String get truckSupplier => '本车混凝土供应商';

  @override
  String get otherTypeName => '其他——请输入名称';

  @override
  String get otherSupplierName => '其他供应商名称';

  @override
  String get volumeField => '方量';

  @override
  String get slumpField => '坍落度';

  @override
  String get soundingBeforeOptional => '灌注前测绳（可选）';

  @override
  String estimateHint(String value) {
    return '估算 $value';
  }

  @override
  String get saveChanges => '保存修改';

  @override
  String get saveTruck => '保存罐车';

  @override
  String get castDataTitle => '灌注资料';

  @override
  String defaultGrade(String grade) {
    return '默认强度 fc′ $grade MPa';
  }

  @override
  String get defaultGradeBody => '来自桩位/项目。仅当到场混凝土不同时才需填写。';

  @override
  String get suppliersWithPo => '本项目有混凝土采购单的供应商';

  @override
  String get noPoYet => '本项目尚无混凝土采购单';

  @override
  String get suppliersWithPoBody =>
      '作为每车的默认值；每车仍可单独选择供应商。列表中没有？请选择\"其他\"并输入名称，并告知办公室。';

  @override
  String get noPoYetBody => '显示全部混凝土供应商；办公室开具采购单后列表会自动收窄。每车仍可单独选择供应商。';

  @override
  String get noteField => '备注';

  @override
  String hangAboveGs(String top, String bottom) {
    return '高出地面 $top–$bottom m';
  }

  @override
  String hangAcrossGs(String top, String bottom) {
    return '自高出地面 $top m 至深度 $bottom m';
  }

  @override
  String hangDepth(String top, String bottom) {
    return '深度 $top–$bottom m';
  }

  @override
  String get stopTremieBlocked => '导管堵塞／混凝土卡住';

  @override
  String get stopNoTruck => '罐车未到／混凝土用尽';

  @override
  String get stopHoleCollapse => '孔壁坍塌';

  @override
  String get stopPlantWeather => '设备故障或天气';

  @override
  String labelDetail(String label, String detail) {
    return '$label——$detail';
  }

  @override
  String stoppedBeforeCutOff(String missing, String vol, String why) {
    return '灌注在达到截桩标高前停止（尚差 $missing ≈ $vol m³）：$why';
  }

  @override
  String get belowCutOffTitle => '混凝土未达截桩标高';

  @override
  String finishCastingOf(String code) {
    return '结束 $code 的灌注？';
  }

  @override
  String shortfallTitle(String vol, int trucks) {
    return '尚差 $vol m³（约再 $trucks 车）';
  }

  @override
  String shortfallLine1(String level, String cutoff, String missing) {
    return '混凝土面自地面 $level，截桩标高 $cutoff——尚差 $missing。';
  }

  @override
  String shortfallLine2(String poured, String theoretical, String percent) {
    return '已灌注 $poured m³，理论约 $theoretical m³$percent。';
  }

  @override
  String percentSuffix(String percent) {
    return '（$percent%）';
  }

  @override
  String get estimateSoundToBeSure => '该数值由方量估算——请先测绳确认。';

  @override
  String get shortPileWarning =>
      '在截桩标高以下结束的桩即为短桩，且混凝土会硬化——无法撤销。若确实停止灌注，请选择原因，办公室需要知晓。若是误触，请选择\"尚未——继续灌注\"。';

  @override
  String get reasonRequired => '原因（必填）';

  @override
  String get detailOptional => '说明（可选）';

  @override
  String get reasonHint => '例如：第 3 节导管堵塞，混凝土已硬化';

  @override
  String get shortABitBody => '仅略低于截桩标高——高出部分本就会被凿除。该桩位标记为已灌注；在办公室审核前记录仍可修正。';

  @override
  String get finishedBody => '该桩位标记为已灌注。在办公室审核前记录仍可修正。';

  @override
  String get finishAnyway => '仍然结束';

  @override
  String get notYetKeepPouring => '尚未——继续灌注';

  @override
  String get notYet => '尚未';

  @override
  String get castLogTitle => '灌注记录';

  @override
  String overuseTitle(String percent) {
    return '混凝土用量超理论值 $percent%';
  }

  @override
  String overuseBody(String level, String used, String theoretical) {
    return '至混凝土面 $level：已用 $used m³，理论 $theoretical m³。孔壁可能超挖或坍塌，请报告主管。';
  }

  @override
  String get gapInvalid => '导管底部间隙须为 0–5 m。';

  @override
  String get reasonTidakValid => '数据无效';

  @override
  String get reasonTidakBerhak => '您的账号无权保存此数据';

  @override
  String get reasonBukanMilik => '该数据属于其他用户';

  @override
  String get reasonDioper => '该记录已交接——只能在持有者手机上修改';

  @override
  String get reasonSudahDihapus => '该数据已在办公室删除';

  @override
  String get reasonSudahDitinjau => '考勤已经办公室审核——无法再修改';

  @override
  String get reasonSudahDiperiksa => '灌注记录已经办公室审核——无法再修改';

  @override
  String get reasonSudahDicor => '该桩位已记录为已灌注';

  @override
  String get reasonProyekTidakAda => '项目未找到或已关闭';

  @override
  String get reasonProyekTanggalTetap => '考勤的项目与日期上传后不可更改';

  @override
  String get reasonTanggalDepan => '考勤日期在未来——请检查手机时间';

  @override
  String get reasonAbsenSudahAda => '该项目与日期下已有您的考勤';

  @override
  String get reasonWorkerBelumAda => '等待新工人数据先行上传';

  @override
  String get reasonPekerjaDihapus => '有工人已被办公室删除';

  @override
  String get reasonPekerjaBukanKru => '有工人不属于您的班组';

  @override
  String get reasonPekerjaGanda => '有工人重复登记';

  @override
  String get reasonUuidBentrok => '数据与其他数据冲突——请联系管理员';

  @override
  String get reasonTitikTidakAda => '桩位未找到或已删除';

  @override
  String get reasonTitikTetap => '灌注记录的桩位不可更改';

  @override
  String get reasonCorSudahAda => '该桩位已有来自其他手机的灌注记录';

  @override
  String get reasonMutuKosong => '混凝土强度（fc′）未填写——请在灌注记录中填写，或请办公室在桩位/项目中设置';

  @override
  String get reasonPemasokTidakAda => '未找到混凝土供应商';

  @override
  String get reasonTmGanda => '罐车序号重复';

  @override
  String get reasonJamTmTerbalik => '罐车结束时间早于开始时间';

  @override
  String get reasonSegmenGanda => '导管节位置重复';

  @override
  String get reasonSegmenTmAsing => '在不存在的罐车之后拔管';

  @override
  String get reasonGsKosong => '该桩位地面标高未填写——标记已钻孔时填写';

  @override
  String get reasonJedaTmAsing => '存在不存在罐车的暂停记录';

  @override
  String get reasonJamJedaTerbalik => '暂停时间不合理——请检查手机时间';

  @override
  String get reasonTremieBottomSalah => '底节必须在最下方、仅一节且未拔出';

  @override
  String get reasonSoundingKosong => '罐车后测绳未填写——结束灌注前必填';

  @override
  String get reasonLogBorSudahAda => '该桩位已有来自其他手机的钻孔记录';

  @override
  String get reasonKedalamanMundur => '有钻孔读数浅于前一次读数';

  @override
  String get reasonBorKosong => '钻孔记录没有任何深度读数';

  @override
  String get reasonEntriGanda => '有钻孔读数重复记录';

  @override
  String get reasonBerkasHilang => '照片文件已从手机丢失';

  @override
  String reasonWithDetail(String reason, String detail) {
    return '$reason（$detail）';
  }

  @override
  String get entityWorker => '工人';

  @override
  String get entityAttendance => '考勤';

  @override
  String get entityDrillMark => '钻孔标记';

  @override
  String get entityDrillLog => '钻孔记录';

  @override
  String get entityCasting => '灌注记录';

  @override
  String get pauseCabutTremie => '拔导管';

  @override
  String get pauseTungguTm => '等待罐车';

  @override
  String get pauseKendalaAlat => '设备故障';

  @override
  String get drillLogNotOnPhone => '本机未找到该钻孔记录。';

  @override
  String get pointNotFoundPull => '未找到桩位。请先拉取最新数据。';

  @override
  String pointHasDrillLog(String code, String by) {
    return '桩位 $code 已有钻孔记录$by。一个桩位只能有一份钻孔记录。';
  }

  @override
  String pointAlreadyCast(String code) {
    return '桩位 $code 已灌注。';
  }

  @override
  String drillHeldByOther(String who) {
    return '该钻孔记录由 $who 持有——请在持有者手机上修改。';
  }

  @override
  String get operatorSaved => '钻机操作员已保存。';

  @override
  String get readingDeleted => '读数已删除。';

  @override
  String readingRecorded(String depth, String time) {
    return '已记录 $depth，时间 $time。';
  }

  @override
  String get drillFinishNotStored => '完成状态未保存。请再次点按\"完成钻孔\"。';

  @override
  String drillFinished(String code, String depth) {
    return '$code 钻孔完成，深度 $depth。';
  }

  @override
  String get drillReopened => '钻孔记录已重新打开。';

  @override
  String drillOf(String code) {
    return '$code 钻孔';
  }

  @override
  String drillHandedOverBody(String who) {
    return '该钻孔记录在 $who 的手机上继续。本机仅可查看；修改须在持有者手机上进行。';
  }

  @override
  String drilledToDepth(String depth) {
    return '钻孔完成 $depth';
  }

  @override
  String get drilledBodyOk => '该桩位已标记为已钻孔；可开始灌注记录。';

  @override
  String get readingsSection => '读数';

  @override
  String readingsCount(int n) {
    return '$n 次';
  }

  @override
  String get noReadingsYet => '还没有读数。每次读取深度时请点按\"记录深度\"。';

  @override
  String get finishDrilling => '完成钻孔';

  @override
  String get recordDepth => '记录深度';

  @override
  String get drillOperatorLabel => '钻机操作员';

  @override
  String get notPicked => '未选择';

  @override
  String get pick => '选择';

  @override
  String get change => '更换';

  @override
  String get finalDepthLabel => '最终深度';

  @override
  String get currentDepthLabel => '当前深度';

  @override
  String get planNotComputable => '暂无法计算设计值';

  @override
  String ofPlanned(String planned) {
    return '设计 $planned';
  }

  @override
  String startedAt(String time) {
    return '开始 $time';
  }

  @override
  String runningFor(String duration) {
    return '已 $duration';
  }

  @override
  String deeperThanPlan(String over) {
    return '比设计深 $over。';
  }

  @override
  String hoursMinutes(int h, int m) {
    return '$h 小时 $m 分';
  }

  @override
  String minutesOnly(int m) {
    return '$m 分钟';
  }

  @override
  String depthGain(String gain, String duration) {
    return '$duration 内 +$gain';
  }

  @override
  String get readingTime => '读数时间';

  @override
  String get depthInvalid => '请填写深度（米），须大于 0。';

  @override
  String get timeInFuture => '该时间在未来。请检查读数时间。';

  @override
  String get editReading => '修改读数';

  @override
  String lastReadingWas(String depth, String time) {
    return '上次读数 $depth，时间 $time';
  }

  @override
  String plannedIs(String planned) {
    return '设计 $planned';
  }

  @override
  String get editTime => '修改时间';

  @override
  String get depthFromGs => '自地面深度';

  @override
  String get noteOptional => '备注（可选）';

  @override
  String get drillNoteHint => '例如：遇到岩石，更换钻头';

  @override
  String get deleteThisReading => '删除此读数';

  @override
  String finishDrillingOf(String code) {
    return '结束 $code 的钻孔？';
  }

  @override
  String finishDrillBody(String depth) {
    return '最终深度 $depth（最深读数）。该桩位标记为已钻孔，可开始灌注记录。';
  }

  @override
  String shallowerThanPlan(String short) {
    return '仍比设计浅 $short';
  }

  @override
  String shallowerBody(String planned) {
    return '设计 $planned。请确认确实在此停止。';
  }

  @override
  String get operatorNameRequired => '请填写操作员姓名。';

  @override
  String operatorExists(String name) {
    return '已存在\"$name\"。若为同一人请从列表选择；若确为他人，请再次点按保存。';
  }

  @override
  String get drillOperator => '钻机操作员';

  @override
  String get newOperator => '新增操作员';

  @override
  String get checkFirst => '请先核对';

  @override
  String get operatorName => '操作员姓名';

  @override
  String get phoneOptional => '手机号（可选）';

  @override
  String get backToList => '返回列表';

  @override
  String get searchName => '搜索姓名';

  @override
  String get noMatchAddNew => '没有匹配项。请新增操作员。';

  @override
  String get queueTitle => '上传队列';

  @override
  String get queueLoadError => '无法读取队列';

  @override
  String get lastSendFailed => '上次上传失败';

  @override
  String queueCount(int docs, int photos) {
    return '$docs 条记录 · $photos 张照片';
  }

  @override
  String get notSentSinceOpen => '自应用打开后尚未上传';

  @override
  String lastTriedAt(String time) {
    return '上次尝试时间 $time';
  }

  @override
  String get allSent => '全部已上传。';

  @override
  String get photosSection => '照片';

  @override
  String photoLine(String kind, String kb, String time) {
    return '$kind · $kb kB · $time';
  }

  @override
  String get photoFace => '工人面部';

  @override
  String get photoCheckIn => '签到';

  @override
  String get photoCheckOut => '签退';

  @override
  String get photoTicketKind => '罐车送货单';

  @override
  String get photoSlumpKind => '罐车坍落度试验';

  @override
  String changedAt(String time, String id) {
    return '修改于 $time · $id';
  }

  @override
  String retryAt(String time) {
    return '将于 $time 重试';
  }

  @override
  String get discardTitle => '从手机丢弃？';

  @override
  String get discardBody => '该数据将不再上传，且无法撤销。';

  @override
  String get discard => '丢弃';

  @override
  String get unsavedTitle => '不保存就离开？';

  @override
  String get unsavedBody => '本页有尚未保存的内容，包括刚拍摄的照片。丢弃后，照片不会附加到这辆车上。';

  @override
  String get discarded => '已从手机丢弃。';

  @override
  String get queuedResend => '已加入队列，正在重新上传。';

  @override
  String get resend => '重新上传';

  @override
  String get fillEmailPassword => '请填写邮箱与密码。';

  @override
  String get loginNeedsSignal => '登录需要网络。登录一次后即可离线使用。';

  @override
  String get accountOnOtherPhone => '该账号仍在另一台手机上登录';

  @override
  String oneAccountOnePhone(String last) {
    return '一个账号只能在一台手机上使用，以免现场记录分叉。$last';
  }

  @override
  String lastActiveSuffix(String when) {
    return '该手机最后活跃于 $when。';
  }

  @override
  String get oldPhoneKeepsData => '旧手机的数据不会丢失';

  @override
  String get oldPhoneKeepsDataBody =>
      '该手机仍可上传其队列，只是不能再记录新内容。若那才是您实际使用的手机，请取消并在那边登录。';

  @override
  String get moveToThisPhone => '转移到本机';

  @override
  String minutesAgo(int n) {
    return '$n 分钟前';
  }

  @override
  String hoursAgo(int n) {
    return '$n 小时前';
  }

  @override
  String daysAgo(int n) {
    return '$n 天前';
  }

  @override
  String get justNow => '刚刚';

  @override
  String get loginTagline => '班组考勤与灌注记录';

  @override
  String get dataSafeHere => '本机数据安全';

  @override
  String get signInAgainToSend => '请用同一账号重新登录，以便上传队列。';

  @override
  String get cannotSignInYet => '暂时无法登录';

  @override
  String get email => '邮箱';

  @override
  String get password => '密码';

  @override
  String get signIn => '登录';

  @override
  String get phoneReplacedTitle => '本机已被替换';

  @override
  String get accountUsedElsewhere => '该账号正在另一台手机上使用';

  @override
  String get phoneReplacedBody =>
      '您的账号已在另一台手机登录，本机不再接受新记录。剩余队列仍从这里上传。若本机才是您使用的手机，请在此重新登录。';

  @override
  String accountUsedElsewhereBody(String who, String until) {
    return '您的账号已在另一台手机登录$who。请先从本机上传剩余数据，然后在那台手机继续。自 $until 起本机不再接受新记录。';
  }

  @override
  String inParens(String what) {
    return '（$what）';
  }

  @override
  String get signInOnThisPhone => '在本机登录';

  @override
  String get sessionExpired => '会话已结束——请重新登录';

  @override
  String get sessionExpiredBody => '本机数据安全，仍可继续填写。请重新登录以便上传队列。';

  @override
  String clockOffTitle(String drift) {
    return '手机时间与服务器相差 $drift';
  }

  @override
  String get clockOffBody =>
      '所有钻孔读数时间与罐车时间均取自本机时钟。请在手机设置中开启\"自动日期与时间\"，然后重新拉取数据。';

  @override
  String rejectedCount(int n) {
    return '$n 条记录被服务器拒绝';
  }

  @override
  String get rejectedBody => '打开队列查看原因并修正。';

  @override
  String get view => '查看';

  @override
  String get sending => '正在上传…';

  @override
  String staleUnsent(int docs, int photos) {
    return '超过一天未上传：$docs 条记录，$photos 张照片';
  }

  @override
  String unsent(int docs, int photos) {
    return '未上传：$docs 条记录，$photos 张照片';
  }

  @override
  String get staleUnsentBody =>
      '请到有信号或 WiFi 的地方点按\"上传\"。若仍无法上传，请联系 TerraBot 管理员。';

  @override
  String get offlineAutoSend => '无网络。手机一旦有信号即自动上传，即使应用已关闭。';

  @override
  String get autoSendOnSignal => '有网络时将自动上传。';

  @override
  String get send => '上传';

  @override
  String updateAvailableTitle(String version) {
    return '$version 版本已发布';
  }

  @override
  String get updateAvailableBody => '应用仍可照常使用。有空时更新即可 — 开工前更新比浇筑途中更方便。';

  @override
  String get updateNow => '更新';

  @override
  String get updateTitle => '更新 TerraBot Field';

  @override
  String updateBody(String current, String min) {
    return '本机版本 $current 已不再受服务器支持。请安装 $min 或更新版本以继续工作。';
  }

  @override
  String unsentSafeHere(int n) {
    return '$n 条记录未上传——在本机安全保存';
  }

  @override
  String get installOverBody =>
      '请在本应用之上直接安装新版本。请勿先卸载：卸载会删除所有未上传的数据。更新后数据将自动上传。';

  @override
  String get downloadNew => '下载新版本';

  @override
  String get askAdminApk => '向管理员索取最新安装包';

  @override
  String get askAdminApkBody => 'TerraBot 管理员会发送 APK 文件或链接。';

  @override
  String get checkAgain => '再次检查';

  @override
  String get keepRunningTitle => '让 TerraBot Field 保持运行';

  @override
  String get keepRunningBody =>
      '本机会关闭未打开的应用。若不进行以下设置，灌注提醒（20 分钟、暂停）与自动上传在息屏时将无法运行。';

  @override
  String get openAutostart => '打开自启动设置';

  @override
  String get openBattery => '打开应用电池设置';

  @override
  String get setBatteryOnce => '手机电池只需设置一次';

  @override
  String get setBatteryBody => '以便息屏时灌注提醒与自动上传仍可运行。';

  @override
  String get setUp => '设置';

  @override
  String get thisPeriod => '本期';

  @override
  String get fullRecap => '完整汇总';

  @override
  String fullRecapBody(String to) {
    return '自项目开始至 $to 的全部桩位';
  }

  @override
  String get excelSubject => '桩基数据汇总';

  @override
  String excelFailed(String error) {
    return 'Excel 下载失败：$error';
  }

  @override
  String get reportsTitle => '现场报表';

  @override
  String get presetToday => '今天';

  @override
  String get presetYesterday => '昨天';

  @override
  String get presetWeek => '7 天';

  @override
  String get pickDate => '选择日期';

  @override
  String get pickRange => '选择日期范围';

  @override
  String rangeTooLong(String max) {
    return '日期范围最长 $max 天。';
  }

  @override
  String dateRange(String from, String to) {
    return '$from – $to';
  }

  @override
  String get preparingExcel => '正在准备 Excel…';

  @override
  String get downloadExcel => '下载 Excel（桩基数据汇总）';

  @override
  String get reportLoadError => '无法读取报表';

  @override
  String get statDrilledPoints => '已钻孔桩位';

  @override
  String get statCastPoints => '已灌注桩位';

  @override
  String statCastSub(String vol, String trucks) {
    return '$vol m³ · $trucks 车';
  }

  @override
  String get noPointsThatDay => '该日期没有钻孔或灌注的桩位。';

  @override
  String projectNo(String id) {
    return '项目 #$id';
  }

  @override
  String get pullToReload => '下拉刷新。数据来自所有已上传的手机。';

  @override
  String pointsSuffix(String n) {
    return '$n 个桩位';
  }

  @override
  String drilledCount(int n) {
    return '已钻孔（$n）';
  }

  @override
  String castCount(int n) {
    return '已灌注（$n）';
  }

  @override
  String get noLog => '无记录';

  @override
  String operatorShort(String name) {
    return '操作员 $name';
  }

  @override
  String get statusDone => '已完成';

  @override
  String get statusChecked => '已审核';

  @override
  String theoreticalOf(String vol, String over) {
    return '理论 $vol m³$over';
  }

  @override
  String percentParens(String sign, String percent) {
    return '（$sign$percent%）';
  }

  @override
  String get resumePouring => '继续灌注';

  @override
  String pauseReminderMin(String body, int min) {
    return '$body · $min 分钟';
  }

  @override
  String idleReminderMin(String body, int min) {
    return '$body · 距上一车 $min 分钟';
  }

  @override
  String get drillSnoozeAction => '静音至明天';

  @override
  String get activityTodayTitle => '今日';

  @override
  String activityTodayMore(int n) {
    return '另有 $n 项——完整列表请打开报表';
  }

  @override
  String activityTodayDone(String jam) {
    return '完成于 $jam';
  }

  @override
  String activityTodayRunning(String jam) {
    return '进行中 · 最近 $jam';
  }

  @override
  String drillIdleTitle(String code) {
    return '钻孔记录 $code 未更新';
  }

  @override
  String drillIdleBody(String since, String time) {
    return '距上次读数已 $since（$time）。请立即记录深度，若已完成请点按\"完成钻孔\"。';
  }

  @override
  String hoursText(int h) {
    return '$h 小时';
  }

  @override
  String minutesText(int m) {
    return '$m 分钟';
  }

  @override
  String hoursMinutesText(int h, int m) {
    return '$h 小时 $m 分钟';
  }

  @override
  String get unsentTitle => '有数据尚未上传';

  @override
  String unsentBody(String since) {
    return '自 $since 起。请在有网络处打开 TerraBot Field 以便上传。';
  }

  @override
  String get badgeSent => '已上传';

  @override
  String get badgeRejected => '已拒绝';

  @override
  String get badgeWaiting => '等待数据';

  @override
  String get badgeFailedRetry => '失败，重试中';

  @override
  String get badgeUnsent => '未上传';

  @override
  String get powerXiaomi1 => '自启动（Autostart）：为 TerraBot Field 开启。';

  @override
  String get powerXiaomi2 => '省电策略：选择\"无限制\"。';

  @override
  String get powerOppo1 => '自启动／允许自动启动：为 TerraBot Field 开启。';

  @override
  String get powerOppo2 => '耗电管理：允许\"后台活动\"与\"自启动\"。';

  @override
  String get powerVivo1 => '自启动／后台运行：允许 TerraBot Field。';

  @override
  String get powerVivo2 => '电池 → 后台高耗电：允许。';

  @override
  String get powerHuawei1 => '应用启动管理：关闭\"自动管理\"，然后开启自动启动、关联启动和后台运行。';

  @override
  String get powerSamsung1 => '电池：选择\"无限制\"。';

  @override
  String get powerSamsung2 => '确保 TerraBot Field 不在\"休眠应用\"／\"深度休眠应用\"名单中。';

  @override
  String get powerGeneric => '电池：为 TerraBot Field 选择\"无限制\"／\"不优化\"。';

  @override
  String soundDeeperThanBottom(String bottom) {
    return '深于孔底（$bottom m）。请重新核对。';
  }

  @override
  String soundDeeperThanBefore(String before) {
    return '深于本车前的混凝土面（$before m）。混凝土不会下降；请重新核对。';
  }

  @override
  String readingShallower(String time, String depth) {
    return '浅于 $time 的读数（$depth）。孔不会变浅。';
  }

  @override
  String readingDeeperThanNext(String time, String depth) {
    return '深于 $time 的下一次读数（$depth）。请检查时间。';
  }

  @override
  String depthFarFromPlan(String depth, String planned, String max) {
    return '$depth m 与设计 $planned m 相差过大（最深 $max m）。请检查数值、桩位或地面标高。';
  }

  @override
  String numberInvalid(String max) {
    return '请输入大于 0 且不超过 $max 的数值。';
  }

  @override
  String get castAlreadyDone => '该桩位的灌注已完成。';

  @override
  String get noTruckPouring => '没有正在灌注的罐车。';

  @override
  String truckAlreadyPaused(int seq) {
    return '第 $seq 车已暂停。';
  }

  @override
  String truckNotPaused(int seq) {
    return '第 $seq 车未处于暂停状态。';
  }

  @override
  String get photoUnreadable => '无法读取该照片。';

  @override
  String get photoCompressFailed => '无法压缩该照片。';

  @override
  String get workersTitle => '工人';

  @override
  String get newWorker => '新增工人';

  @override
  String get workersLoadError => '无法读取工人名单';

  @override
  String get workersAllBody => '公司全部工人。任何人都可为其考勤与修改。';

  @override
  String workersNoProjectBody(String days) {
    return '无主项目，且最近 $days 天内在任何地方都无考勤。';
  }

  @override
  String workersProjectBody(String code, String days) {
    return '主项目为 $code，或最近 $days 天内在 $code 考勤过。';
  }

  @override
  String workersCount(int n) {
    return '$n 名工人';
  }

  @override
  String get noWorkersYet => '还没有工人。请用下方按钮新增。';

  @override
  String get searchNameOrPhone => '搜索姓名或手机号';

  @override
  String allCount(int n) {
    return '全部（$n）';
  }

  @override
  String withoutProject(int n) {
    return '无项目（$n）';
  }

  @override
  String get noMatchingWorkers => '没有匹配的工人。';

  @override
  String mainProjectIs(String code) {
    return '主项目 $code';
  }

  @override
  String lastSeenAt(String code, String date) {
    return '最近在 $code · $date';
  }

  @override
  String cameraFailed(String error) {
    return '相机失败：$error';
  }

  @override
  String get workerNameRequired => '请填写工人姓名。';

  @override
  String workerSaved(String name) {
    return '$name 已保存。有网络时自动上传。';
  }

  @override
  String get mainProjectOptional => '主项目（可选）';

  @override
  String get noMainProject => '无主项目';

  @override
  String andOthers(int n) {
    return '\n• 以及另外 $n 人';
  }

  @override
  String get maybeRegistered => '可能已登记';

  @override
  String maybeRegisteredBody(String names) {
    return '该姓名或手机号与已有工人相似：\n$names\n\n若为同一人，请取消并使用已有记录。若确为他人，请再次点按保存。';
  }

  @override
  String get needsFixing => '需要修正';

  @override
  String get viewOnlyWorkerBody => '您的账号无权登记或修改工人。请联系办公室授予权限。';

  @override
  String get noFaceDetected => '未检测到人脸';

  @override
  String facesDetected(int n) {
    return '检测到 $n 张人脸';
  }

  @override
  String get facePhotoBody => '办公室用面部照片核对班组。请重拍，只含一张正对镜头的人脸。';

  @override
  String get retake => '重拍';

  @override
  String get fullName => '全名';

  @override
  String get phoneOptional2 => '手机号（可选）';

  @override
  String get workerNoteHint => '备注（例如：钢筋工、操作员）';

  @override
  String get saveAsNewWorker => '仍然保存为新工人';

  @override
  String get attendanceTitle => '班组考勤';

  @override
  String get attendToday => '今日考勤';

  @override
  String get attendanceLoadError => '无法读取考勤';

  @override
  String get attendanceHistory => '考勤历史';

  @override
  String get otherProject => '其他项目';

  @override
  String get attendanceHistoryBody => '本机创建的考勤';

  @override
  String get noAttendanceYet => '还没有考勤记录。';

  @override
  String failedWith(String error) {
    return '失败：$error';
  }

  @override
  String photoInGallery(String album) {
    return '照片已保存到手机相册（相册\"$album\"）。';
  }

  @override
  String get galleryDenied => '考勤已保存，但照片未进入相册：相册权限被拒绝。';

  @override
  String get galleryFailed => '考勤已保存，但照片无法保存到相册。';

  @override
  String get saveCrewTicks => '保存班组勾选？';

  @override
  String get saveCrewTicksBody => '有未保存的班组修改。';

  @override
  String get crewAttendance => '班组考勤';

  @override
  String saveWithCount(int n) {
    return '保存 · $n 人';
  }

  @override
  String get rejectedByOffice => '办公室已拒绝';

  @override
  String get approvedByOffice => '办公室已批准';

  @override
  String get attendanceLocked => '该考勤无法再从手机修改。';

  @override
  String get projectLabel => '项目';

  @override
  String get projectNoLocation => '办公室尚未填写项目位置';

  @override
  String get projectNoLocationBody => '考勤仍会保存；但无法核对与项目的距离。';

  @override
  String get checkIn => '签到';

  @override
  String get checkOut => '签退';

  @override
  String get savedWithoutLocation => '已保存但无位置';

  @override
  String savedWithoutLocationBody(String problem) {
    return '$problem 办公室将看到该考勤被标记为\"无位置\"。';
  }

  @override
  String crewPresent(int n) {
    return '在场班组（$n）';
  }

  @override
  String get noWorkersTitle => '还没有工人';

  @override
  String get noWorkersBody => '请先登记工人。在此登记的工人即使尚未上传也可立即考勤。';

  @override
  String get thisProject => '本项目';

  @override
  String get searchWorkerName => '搜索工人姓名';

  @override
  String noWorkersForProject(String code) {
    return '$code 还没有工人';
  }

  @override
  String noWorkersForProjectBody(String code, String days) {
    return '还没有人以 $code 为主项目，或最近 $days 天内在此考勤。请在下方完整名单中勾选；上传后他们将显示在此处最上方。';
  }

  @override
  String get unknownWorker => '未知工人';

  @override
  String otherWorkers(int n) {
    return '其他工人（$n）';
  }

  @override
  String get noWorkerByName => '没有该姓名的工人。';

  @override
  String get flaggedForOffice => '已标记供办公室核查';

  @override
  String get flagOutsideRadius => '• 考勤位置超出项目半径';

  @override
  String get flagNoProjectLocation => '• 办公室尚未填写项目位置';

  @override
  String get flagNoLocation => '• 考勤无 GPS 位置';

  @override
  String get flagMockLocation => '• 手机报告了虚拟位置';

  @override
  String get flagClockOff => '• 手机时间与服务器相差很大';

  @override
  String get flagClockUnverified => '• 无法验证手机时间（手机已重启）';

  @override
  String get flagClockEdited => '• 时间被手动修改';

  @override
  String get flagFaceCountOff => '• 照片人脸数与班组人数不符';

  @override
  String get flagPhotoPending => '• 照片仍在等待上传';

  @override
  String get fullDay => '全天';

  @override
  String get halfDay => '半天';

  @override
  String get overtime => '加班';

  @override
  String hoursShort(String h) {
    return '$h 小时';
  }

  @override
  String crewPhotoOf(String what) {
    return '班组照片 · $what';
  }

  @override
  String atTime(String time) {
    return '$time';
  }

  @override
  String withinRadius(String m) {
    return '距项目 $m m ✓';
  }

  @override
  String outsideRadius(String m, String radius) {
    return '距项目 $m m——超出 $radius m 半径';
  }

  @override
  String get noLocation => '无位置';

  @override
  String get mockLocation => '检测到虚拟位置';

  @override
  String facesInPhoto(int n) {
    return '照片中有 $n 张人脸';
  }

  @override
  String get longPressRetake => '长按可重拍';

  @override
  String get levelRefTitle => '标高基准';

  @override
  String levelRefColTip(String col, String tip) {
    return '截桩标高 $col · 桩端标高 $tip';
  }

  @override
  String get notSet => '未设置';

  @override
  String get levelRefNoGs => '请先填写地面标高，以查看截桩深度与设计钻孔长度。';

  @override
  String levelRefGs(String gs) {
    return '地面标高 $gs';
  }

  @override
  String levelRefColBelow(String d) {
    return '• 截桩标高低于地面 $d';
  }

  @override
  String levelRefPlanned(String d) {
    return '• 设计钻孔 $d';
  }

  @override
  String get levelRefFooter => '钻孔深度自地面标高量至孔底。';

  @override
  String get projectsMissingHome => '下拉以从服务器获取。只需一次网络连接，之后即可离线使用。';

  @override
  String get noFieldAccess => '该账号尚无现场权限';

  @override
  String get noFieldAccessBody =>
      '请联系 TerraBot 管理员为您的账号添加 Field Engineer 部门，然后下拉刷新。';

  @override
  String get volumePouredHere => '本桩位实际灌入方量';

  @override
  String get volumeSharedHint => '默认为整车。若该车与其他孔共用，请只填入本桩位的部分。';

  @override
  String overuseAheadTitle(String percent) {
    return '混凝土将超理论值 $percent%';
  }

  @override
  String overuseAheadBody(String used, String theoretical) {
    return '本车后将用 $used m³，理论 $theoretical m³。最常见原因是罐车与其他孔共用——若如此请只填本桩的部分。';
  }

  @override
  String get overuseAfterTitle => '混凝土远超理论值';

  @override
  String overuseAfterBody(int seq, String percent) {
    return '截至第 $seq 车，混凝土超理论值 $percent%。在记为孔径扩大之前请先确认：是否有罐车与其他桩共用？';
  }

  @override
  String get fixTruckVolume => '更正罐车方量';

  @override
  String get holeReallyWider => '孔确实扩大了';

  @override
  String get later => '稍后';

  @override
  String widerHoleNote(int seq, String percent) {
    return '第 $seq 车：混凝土超理论值 $percent%——孔径扩大（现场已核实）。';
  }

  @override
  String get pullNowTitle => '现在拔导管？';

  @override
  String pullNowBody(int seq, String emb, String which, String after) {
    return '第 $seq 车已完成，埋深 $emb。拔 $which 后埋深为 $after。';
  }

  @override
  String get pulledAlready => '已拔出';

  @override
  String get notYetPull => '尚未拔出';

  @override
  String get overbreakCheckedTag => '[overbreak diperiksa]';

  @override
  String get excelOptionsTitle => '下载 Excel';

  @override
  String get excelPeriodLabel => '范围';

  @override
  String get excelSheetsLabel => '包含的工作表';

  @override
  String get sheetPiles => '桩基汇总';

  @override
  String get sheetPilesBody => '每桩一行：深度、方量、日期。';

  @override
  String get sheetConcrete => '混凝土强度';

  @override
  String get sheetConcreteBody => '仅已灌注的桩位及其抗压强度。';

  @override
  String get sheetOperators => '操作员汇总';

  @override
  String get sheetOperatorsBody => '各操作员的实际与设计米数，另附每位操作员一张明细表。';

  @override
  String get pickAtLeastOneSheet => '请至少选择一个工作表。';

  @override
  String get download => '下载';

  @override
  String get retakePhoto => '重拍';

  @override
  String get tapToEnlarge => '点按放大';

  @override
  String get photoNotOnThisPhone => '此手机上没有该照片';

  @override
  String get correct => '更正';

  @override
  String get backOut => '退出';

  @override
  String get gsRowLabel => '地面标高 (GS)';

  @override
  String plannedDrillOf(String depth) {
    return '计划钻进长度 $depth';
  }

  @override
  String confirmBeforeDrilling(String code) {
    return '开钻前确认 $code';
  }

  @override
  String get confirmBeforeDrillingBody =>
      '请输入该桩点校正后的 GS。计划钻进长度由此算出，必须在下钻前确认无误。';

  @override
  String get correctGsTitle => '更正 GS';

  @override
  String get correctGsBody => '测量员修正了数据？在此修改 GS，计划钻进长度和截桩深度会随之重新计算。';

  @override
  String codeHeldBy(String name) {
    return '验证码在 $name 的手机上';
  }

  @override
  String codeHeldByBody(String name) {
    return '请 $name 在其手机上打开该桩点并点击\"移交给同事\"，屏幕上会显示6位数验证码供口头告知。系统不会自动发送任何请求。';
  }

  @override
  String get askHolder => '向持有人申请';

  @override
  String get sendingRequest => '正在发送申请…';

  @override
  String get requestSentTitle => '申请已发送';

  @override
  String requestSentBody(String name) {
    return '$name 的手机会收到通知。对方同意后，该记录立即转到您的手机，无需验证码。';
  }

  @override
  String get handingOver => '正在移交记录…';

  @override
  String get rejectingRequest => '正在拒绝申请…';

  @override
  String logHandedTo(String code, String name) {
    return '记录 $code 已转给 $name。';
  }

  @override
  String requestRejected(String name) {
    return '已拒绝 $name 的申请。';
  }

  @override
  String handoverRequestTitle(String name) {
    return '$name 申请接手';
  }

  @override
  String handoverRequestBody(String code) {
    return '桩点 $code — 打开以同意或拒绝。';
  }

  @override
  String handoverRequestPrompt(String name, String code) {
    return '$name 正在桩点 $code 等待答复。同意后该记录立即转到对方手机，本页面将关闭。';
  }

  @override
  String get approve => '同意';

  @override
  String get reject => '拒绝';

  @override
  String get drillProgressLabel => '钻进进度';

  @override
  String get castProgressLabel => '浇筑进度';

  @override
  String drillProgressMain(String depth, String planned) {
    return '$depth / 计划 $planned';
  }

  @override
  String castProgressMain(String n, String vol, String theoretical) {
    return '第 $n 车 · $vol m³ / 理论 $theoretical m³';
  }

  @override
  String get progressNothingYet => '尚无记录';

  @override
  String get logGoneResynced => '该日志在服务器上已不存在——可能已从办公室删除。该桩点刚刚重新同步，请重新打开。';

  @override
  String get progressNoSync => '日志已开启，首条记录尚未上传';

  @override
  String progressLastAt(String time, String age) {
    return '最近记录 $time · $age';
  }

  @override
  String get progressAsSent => '以持有人手机已上传的数据为准。若其处于无信号状态，实际进度可能更快。';

  @override
  String get refresh => '刷新';

  @override
  String get pointHistoryOpen => '查看桩点历史';

  @override
  String pointHistoryTitle(String code) {
    return '$code 历史';
  }

  @override
  String get pointHistoryErrorTitle => '无法打开历史记录';

  @override
  String get pointHistoryErrorBody => '此页面直接读取服务器数据，需要网络连接。下拉可重试。';

  @override
  String get pointHistoryNoCasting => '服务器上该桩点尚无浇筑记录。';

  @override
  String get pointHistoryTrail => '修改记录';

  @override
  String get deletedLabel => '已删除';

  @override
  String get fromOffice => '来自办公室';

  @override
  String trucksCount(int n) {
    return '$n 车';
  }

  @override
  String get volumeUsed => '实际用量';

  @override
  String get volumeTheoretical => '理论用量';

  @override
  String get overusePercent => '超用比例';

  @override
  String get castStartEnd => '浇筑起止';

  @override
  String get drillLogNotClosed => '记录未关闭';

  @override
  String get embedBeforeLabel => '浇筑前埋深';

  @override
  String get embedAfterLabel => '浇筑后埋深';

  @override
  String tremieSummary(int n, String total, String gap) {
    return '$n 节 · $total m · 下端距孔底 $gap';
  }

  @override
  String get tremieStillFitted => '仍在孔内';

  @override
  String tremiePulledAfter(int seq) {
    return '第 $seq 车后拔出';
  }

  @override
  String get pointConfirmedTitle => '桩点已确认';

  @override
  String pointConfirmedBody(String who, String when) {
    return '由 $who 于 $when 确认。在办公室撤销确认前，本桩点的钻孔和浇筑数据不可更改。';
  }

  @override
  String get reasonTitikDikonfirmasi => '该桩点已由办公室确认——请先请办公室撤销确认';

  @override
  String get drillSection => '钻孔';

  @override
  String get castSection => '浇筑';

  @override
  String get deepestLabel => '最深';

  @override
  String get drillDurationLabel => '钻孔时长';

  @override
  String get avgRateLabel => '平均速度';

  @override
  String get slowestSegmentLabel => '最慢区段';

  @override
  String metresPerHour(String v) {
    return '$v 米/小时';
  }

  @override
  String get drillEffectiveLabel => '实钻时长';

  @override
  String drillOfTotal(String total) {
    return '共 $total';
  }

  @override
  String get drillEffectiveRateLabel => '钻孔速度';

  @override
  String drillRateTotal(String laju) {
    return '$laju 米/小时（含停钻）';
  }

  @override
  String drillStops(String n, String lama) {
    return '停钻 $n 次 · $lama';
  }

  @override
  String get denahTitle => '桩位平面图';

  @override
  String get denahLabelToggle => '桩号';

  @override
  String get denahRotate => '旋转 90°';

  @override
  String get denahFit => '适应屏幕';

  @override
  String get denahDeviationToggle => '偏差连线';

  @override
  String get denahDrilled => '已钻孔';

  @override
  String denahNoCoordTitle(String n) {
    return '$n 个桩位未绘制';
  }

  @override
  String get denahNoCoordBody =>
      '这些桩位没有 X/Y 坐标（设计与实测均无），因此无法绘制。由办公室通过 Excel 导入填写。';

  @override
  String get denahEmptyTitle => '尚无坐标';

  @override
  String get denahEmptyBody => '本项目没有任何桩位填写了 X/Y 坐标，暂时无法绘制平面图。设计坐标由办公室填写。';

  @override
  String drillPlanRef(String v) {
    return '$v 设计深度';
  }

  @override
  String deviationStopTitle(String v) {
    return '偏差 $v 超出容许值';
  }

  @override
  String deviationStopBody(String batas, String lewat) {
    return '项目容许值为 $batas，本桩超出 $lewat。请在浇筑前复核实测与设计坐标——一旦浇筑，就只剩加固一条路，而那不是用手机做的决定。';
  }

  @override
  String get deviationStopSave => '按原样保存';

  @override
  String get deviationStopRecheck => '重新检查';

  @override
  String get filterDrilling => '正在钻孔';

  @override
  String get filterCasting => '正在浇筑';

  @override
  String progressIdle(String jam, String lama) {
    return '自 $jam 起停工 · $lama 无新读数';
  }

  @override
  String readingTableTitle(String n) {
    return '读数（$n）';
  }

  @override
  String get readingColTime => '时间';

  @override
  String get readingColDepth => '深度';

  @override
  String get readingColAdded => '增加';

  @override
  String get readingColRate => '速度';

  @override
  String get readingNotPlotted => '未绘入曲线——时间或深度无法读取。';

  @override
  String get activityTitle => '现场作业';

  @override
  String get activityToday => '今天 · 点击选择日期';

  @override
  String get activityPick => '点击选择日期';

  @override
  String get activityPrevDay => '前一天';

  @override
  String get activityNextDay => '后一天';

  @override
  String get activityEmptyTitle => '这一天没有记录';

  @override
  String get activityEmptyBody => '没有钻孔或浇筑记录。可用上方箭头选择其他日期。';

  @override
  String get activityDrilled => '个桩已钻孔';

  @override
  String get activityPoured => '个桩已浇筑';

  @override
  String get activityAllProjects => '所有项目';

  @override
  String get activityNoProject => '无项目';

  @override
  String get activitySeeAll => '查看全部';

  @override
  String get curveNeedsTwo => '曲线至少需要两条时间和深度均可读取的记录。';

  @override
  String get readingUnreadable => '该记录的时间或深度无法读取——请从办公室更正。';

  @override
  String trailCount(int n) {
    return '$n 条更改';
  }

  @override
  String get pourStartTitle => '首车罐车之前';

  @override
  String get stickOutQuestion => '导管露出地面多少米？';

  @override
  String get stickOutField => '露出地面';

  @override
  String stickOutBasis(String panjang) {
    return '已组装导管长度 $panjang。';
  }

  @override
  String stickOutResult(String dalam, String celah) {
    return '即导管下端位于 $dalam，在孔底上方 $celah。';
  }

  @override
  String get stickOutRequired => '请先填写露出地面的米数。';

  @override
  String stickOutTooHigh(String celah) {
    return '这样导管下端位于孔底上方 $celah，过高——请再确认。';
  }

  @override
  String get stickOutTooDeep => '这样导管下端会低于孔底。请再确认。';

  @override
  String get gradeQuestion => '今天的混凝土等级是多少？';

  @override
  String get nextStep => '下一步';

  @override
  String get backStep => '返回';

  @override
  String get ratioOddTitle => '声测与混凝土方量不符';

  @override
  String ratioOddBody(String ini, String pola) {
    return '本车为 $ini，而此前各车为 $pola。孔在灌注前已成孔，灌注中途形状不会改变——多数情况是声测读错。';
  }

  @override
  String ratioOddAlone(String ini) {
    return '本车为 $ini，且尚无此前罐车可供比较。常见范围为 −20% 至 +100%，超出时通常是声测读错。';
  }

  @override
  String get remeasure => '重新测量';

  @override
  String get saveAnyway => '仍然保存';

  @override
  String get qTruckNo => '罐车的车号是多少？';

  @override
  String get qVolume => '本车混凝土多少方？';

  @override
  String get qSupplier => '混凝土来自哪家供应商？';

  @override
  String get qSlump => '实测坍落度是多少？';

  @override
  String get qPhoto => '送货单照片';

  @override
  String supplierSameAsBefore(String nama) {
    return '仍为 $nama，与上一车相同。';
  }

  @override
  String get changeIt => '更改';

  @override
  String get lengkapiTitle => '请先补全';

  @override
  String get lengkapiBody => '灌注记录尚不能结束。请先补全下列内容，然后继续。';

  @override
  String get qSoundingAwal => '首车灌注之前，自地面至混凝土面是多少米？';

  @override
  String get tremieDepthField => '导管下端距地面深度';

  @override
  String tremieDepthHint(String dasar) {
    return '导管组装完成后、第一车浇筑前测量。孔底 $dasar；间隙由此计算。';
  }

  @override
  String get tremieDepthRequired => '请先填写导管下端深度。';

  @override
  String tremieDepthInvalid(String dasar) {
    return '导管下端必须位于孔底（$dasar）与其上方 5 米之间。';
  }

  @override
  String get soundingBeforeNeeded => '第 1 车浇筑前的测深尚未填写——缺少它就永远没有浇筑前埋深。';

  @override
  String get reasonSoundingAwalKosong => '第一车浇筑前的测深尚未填写';

  @override
  String get reasonTremieDalamSalah => '导管下端深度与孔底不符';

  @override
  String get actualX => '实际 X';

  @override
  String get actualY => '实际 Y';

  @override
  String get actualXRequired => '实际 X — 必填';

  @override
  String get actualYRequired => '实际 Y — 必填';

  @override
  String get actualXYRequiredMsg => '请填写孔心的实际 X 和 Y 坐标，于钻孔完成后实测。';

  @override
  String get actualXYBothMsg => 'X 和 Y 必须同时填写。';

  @override
  String get actualXYInvalid => '坐标无效。';

  @override
  String get designXYTitle => '设计坐标';

  @override
  String designXYBody(String x, String y) {
    return 'X $x · Y $y';
  }

  @override
  String deviationBody(String simpangan, String toleransi) {
    return '偏差 $simpangan，允许 $toleransi。';
  }

  @override
  String deviationOverTitle(String simpangan) {
    return '偏差 $simpangan 超出允许范围';
  }

  @override
  String deviationOverBody(String toleransi) {
    return '本项目允许偏差为 $toleransi。保存前请核对数值——若数值无误，请上报办公室。';
  }

  @override
  String get castDoneTitle => '浇筑已完成';

  @override
  String get castDoneVolume => '实际供应方量';

  @override
  String get castDonePlanned => '理论设计方量';

  @override
  String castDoneVsPlanned(String rencana, String selisih) {
    return '$rencana m³（$selisih%）';
  }

  @override
  String get castDoneTrucks => '罐车数';

  @override
  String get castDoneTopDepth => '最后记录的混凝土面';

  @override
  String get castDoneHoleDepth => '孔深';

  @override
  String get castDoneAt => '浇筑完成';

  @override
  String get finishTruckAction => '结束罐车';

  @override
  String notifSoundingDue(String seq) {
    return '第 $seq 车已结束——探测尚未填写';
  }

  @override
  String get notifSoundingDueBody =>
      '请在手机上打开浇筑记录，填写浇筑后的混凝土面探测值。导管埋深与方量核对均由该数值计算。';

  @override
  String get drillLockedConfirmedTitle => '办公室已复核——已锁定';

  @override
  String get drillLockedConfirmedBody =>
      '该桩点已复核并通过，钻孔记录不能再修改。如有数据错误，请先让办公室撤销复核。';

  @override
  String get drillLockedCastTitle => '已浇筑——已锁定';

  @override
  String get drillLockedCastBody => '混凝土已灌入，钻孔记录永久关闭。此页面上的内容不能再更改。';

  @override
  String get drillNeedGsTitle => '请先填写地面标高';

  @override
  String get drillNeedGsBody => '所有深度都是从地面标高往下量的，未填写之前无法记录任何数据。请点击上方的地面标高一行填写。';

  @override
  String get blockedNeedGs => '请先填写地面标高——点击上方那一行。';

  @override
  String get blockedConfirmed => '办公室已复核；此记录不能再修改。';

  @override
  String get blockedCast => '已浇筑；钻孔记录已永久关闭。';

  @override
  String get blockedNeedTremie => '请先组好导管，再添加罐车。';

  @override
  String get tremieDepthFirst => '请先测量导管深度';

  @override
  String get blockedNeedTremieDepth => '请先测量导管下端深度。混凝土一旦灌入，该深度便无法再测量。';

  @override
  String get drillReopenConfirmTitle => '重新打开这份钻孔记录？';

  @override
  String get drillReopenConfirmBody =>
      '该记录已关闭。重新打开后可以添加和修改深度数据，办公室也会看到这份记录曾被重新打开。确实有数据错误时才这样做。';

  @override
  String get castReopenConfirmTitle => '重新打开这份浇筑记录？';

  @override
  String get castReopenConfirmBody =>
      '该记录已关闭。重新打开后可以添加和修改罐车与方量数据，办公室也会看到这份记录曾被重新打开。确实有数据错误时才这样做。';

  @override
  String get supplierLocal => '本地（现场搅拌）';

  @override
  String get supplierMustBePicked => '请从列表中选择供应商。若列表中没有，请让办公室添加——不要自行输入名称。';

  @override
  String get supplierMissingTitle => '列表中没有该供应商？';

  @override
  String get supplierMissingBody =>
      '请勿自行输入。请办公室将该供应商标记为\"混凝土供应商\"并开具本项目的采购单——自行输入的名称永远不会进入供应商汇总，也无法与送货单匹配。';

  @override
  String get supplierTypedBefore => '此名称由旧版本手动输入——请从列表中选择正确的供应商';

  @override
  String get supplierLocalConfirmTitle => '使用本地（现场搅拌）混凝土？';

  @override
  String get supplierLocalConfirmBody =>
      '这表示混凝土在现场搅拌，而非由搅拌站配送——因此该记录将没有供应商，也不会与任何送货单匹配。若混凝土由罐车送达，请从列表中选择供应商。';

  @override
  String get supplierLocalConfirmYes => '是，现场搅拌';

  @override
  String get watchOpen => '实时查看';

  @override
  String watchTitle(String code) {
    return '查看 $code';
  }

  @override
  String watchAsOf(String jam, int menit) {
    return '截至 $jam · $menit 分钟前';
  }

  @override
  String get watchNoTimestamp => '持有手机尚未上传带时间的记录';

  @override
  String get watchOfflineTitle => '无法获取数据';

  @override
  String get watchOfflineBody => '实时查看直接读取服务器，需要网络。下拉可重试。';

  @override
  String get watchNothingTitle => '该桩点尚未开始作业';

  @override
  String get watchNothingBody => '持有手机上传第一条读数或第一车后，进度会显示在这里。';

  @override
  String get watchCastRunning => '浇筑中';

  @override
  String get watchCastDone => '浇筑完成';

  @override
  String watchPouringNow(String seq) {
    return '第 $seq 车浇筑中';
  }

  @override
  String get watchTrucks => '已到车数';

  @override
  String get watchVolume => '方量';

  @override
  String get watchConcreteLevel => '自地面的混凝土面';

  @override
  String get watchNotSounded => '尚未测深';

  @override
  String get watchEmbedment => '导管埋深';

  @override
  String get watchDrillRunning => '钻进中';

  @override
  String get watchDrillDone => '钻进完成';

  @override
  String get watchCurveWaitTitle => '曲线需要两条读数';

  @override
  String get watchCurveWaitBody => '仅一条读数没有时间跨度。第二条读数到达后会自动显示。';

  @override
  String get watchDepth => '深度';

  @override
  String get watchRate => '平均速率';

  @override
  String get watchReadings => '读数';

  @override
  String truckTableTitle(String n) {
    return '搅拌车（$n）';
  }

  @override
  String get truckColSeq => '车次';

  @override
  String get truckColPour => '浇筑';

  @override
  String get truckColVolume => '体积';

  @override
  String get truckColCumulative => '累计';

  @override
  String truckArrivedAt(String jam) {
    return '$jam 到场';
  }

  @override
  String get photoExpired => '该照片已超过服务器的保存期限。';

  @override
  String get photoFailed => '无法载入照片。请检查信号后重试。';

  @override
  String get truckShare => '分享';

  @override
  String get shareNoPhoto => '无法获取送货单照片——仅分享文字。';

  @override
  String get sheetSupplier => '按供应商分的混凝土';

  @override
  String get sheetSupplierBody => '每个供应商一张表：车次、送货单、体积及合计。';

  @override
  String get loginLockedTitle => '暂时锁定';

  @override
  String loginLockedBody(String sisa) {
    return '登录尝试次数过多。\"登录\"按钮将在 $sisa 后恢复。现在按它不会延长锁定，但也不会缩短。';
  }

  @override
  String loginLockedButton(String sisa) {
    return '请等待 $sisa';
  }

  @override
  String get koordinatKomaJudul => '是不是漏了小数点？';

  @override
  String koordinatKomaIsi(String nama, int diketik, int rencana, int maks) {
    return '实际 $nama 的小数点前有 $diketik 位数字，而该桩点的设计坐标是 $rencana 位。输入框在 $maks 位时停止接受数字——不是坏了，是满了。请在第 $rencana 位后输入小数点，再输入小数部分。';
  }

  @override
  String get koordinatKosongkan => '清空此输入框';

  @override
  String get swipeToFinishDrilling => '滑动以完成钻孔';

  @override
  String get swipeToFinishCasting => '滑动以完成浇筑';

  @override
  String get swipeDone => '已保存';

  @override
  String get entityGateTicket => '门岗记录';

  @override
  String get gateRecordTruck => '门岗：登记搅拌车';

  @override
  String gateTitle(String code) {
    return '搅拌车进门 · $code';
  }

  @override
  String get gateIntroTitle => '请按车身上的编号准确输入';

  @override
  String get gateIntroBody => '该编号用于把门岗记录与孔口浇筑的车次配对。';

  @override
  String get gateVolume => '送货单方量';

  @override
  String get gateGrade => '混凝土强度等级 (fc\')';

  @override
  String get gateGradeInvalid => '混凝土强度等级超出范围（1–150 MPa）。';

  @override
  String get gateRejected => '此车在门岗被拒收';

  @override
  String get gateRejectedTitle => '被拒收的车不浇筑';

  @override
  String get gateRejectedBody => '记录会保留作为凭证，但其方量不计入该桩位的浇筑记录。';

  @override
  String get gateRejectReason => '拒收原因';

  @override
  String get gateRejectReasonRequired => '请填写拒收原因。';

  @override
  String get gateTruckRequired => '请填写搅拌车编号。';

  @override
  String get gatePhotoRequired => '请先拍摄送货单。';

  @override
  String gateSaved(String truck) {
    return '已登记搅拌车 $truck。有信号时自动发送。';
  }

  @override
  String get startPourOnlyLog => '开始浇筑记录——仅孔口';

  @override
  String get pourTruckNoTitle => '车号是配对依据';

  @override
  String get pourTruckNoBody =>
      '选择门岗已登记的车号，或按车身上的编号准确输入。方量、坍落度和送货单会通过该车号从门岗记录附上。';

  @override
  String get pourTruckNoBodyEmpty =>
      '该桩位的门岗记录尚未同步到本机。请按车身上的编号准确输入车号；方量、坍落度和送货单会通过该车号从门岗记录附上。';

  @override
  String get gateQGrade => '混凝土强度等级是多少？';

  @override
  String get gateQSummary => '全部正确吗？';

  @override
  String get gateRejectAction => '拒收此车';

  @override
  String gateOtherPileTitle(String truck) {
    return '搅拌车 $truck 还要浇到别的孔吗？';
  }

  @override
  String get gateOtherPileBody =>
      '如果一车混凝土分浇两个孔，也要在下一个孔登记。车号、送货单照片、坍落度和强度等级会自动复制，只需填写方量。';

  @override
  String get gateOtherPileNo => '不用，完成';

  @override
  String get gateOtherPilePick => '是 — 点选下一个孔：';

  @override
  String get gateOtherPileSearch => '搜索桩号';

  @override
  String gateCopiedTitle(String truck) {
    return '搅拌车 $truck 继续浇到本桩位';
  }

  @override
  String get gateCopiedBody => '只填写浇到本桩位的方量，不是整车方量。';
}
