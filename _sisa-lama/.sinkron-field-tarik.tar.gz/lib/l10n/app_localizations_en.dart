// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'TerraBot Field';

  @override
  String get navHome => 'Home';

  @override
  String get navAttendance => 'Attendance';

  @override
  String get navCasting => 'Casting';

  @override
  String get navQueue => 'Queue';

  @override
  String get navSettings => 'Settings';

  @override
  String get navAttendanceSoon => 'Attendance is not active yet — coming soon.';

  @override
  String get comingSoon => 'Coming soon';

  @override
  String homeGreeting(String name) {
    return 'Hello, $name';
  }

  @override
  String get homeTagline =>
      'Have a good shift. Everything is saved on the phone, signal or not.';

  @override
  String get homePickProject => 'Choose my project';

  @override
  String get homeAllSent => 'Everything has been sent';

  @override
  String homePending(int count) {
    return '$count not sent yet';
  }

  @override
  String get homeWatched => 'Being watched';

  @override
  String homeWatchedCount(int count) {
    return '$count logs';
  }

  @override
  String get homeDrillRunning => 'drilling log running';

  @override
  String get homeCastRunning => 'casting log running';

  @override
  String get labelDrill => 'Drill';

  @override
  String get labelCast => 'Cast';

  @override
  String get shortcutAttendance => 'Crew attendance';

  @override
  String get shortcutAttendanceBody =>
      'Photo in & out, tick the crew who are here';

  @override
  String get shortcutCasting => 'Drilling & casting log';

  @override
  String get shortcutCastingBody =>
      'Record drill depth, trucks, tremie & sounding per pile';

  @override
  String get shortcutWorkers => 'Workers';

  @override
  String get shortcutWorkersBody =>
      'Every worker by project, register a new one';

  @override
  String get shortcutReports => 'Field report';

  @override
  String get shortcutReportsBody =>
      'Piles drilled & cast today, yesterday, or over a week';

  @override
  String get settingsLanguage => 'Language';

  @override
  String get settingsLanguageBody =>
      'Language of the app. Field terms stay the same in every language.';

  @override
  String get languageSystem => 'Follow phone';

  @override
  String get languageIndonesian => 'Indonesia';

  @override
  String get languageEnglish => 'English';

  @override
  String get languageChinese => '中文';

  @override
  String get settingsTitle => 'Settings';

  @override
  String settingsLevel(String n) {
    return 'Level $n';
  }

  @override
  String get sectionAppearance => 'Appearance';

  @override
  String get sectionMyProject => 'My project';

  @override
  String get sectionNotifications => 'Notifications';

  @override
  String get sectionAccount => 'Account';

  @override
  String get sectionAbout => 'About';

  @override
  String get settingsTheme => 'Theme';

  @override
  String get themeSystem => 'Follow phone';

  @override
  String get themeLight => 'Light';

  @override
  String get themeDark => 'Dark';

  @override
  String get settingsAccent => 'Accent colour';

  @override
  String get accentBlue => 'Blue';

  @override
  String get accentOrange => 'Orange';

  @override
  String get accentTeal => 'Teal';

  @override
  String get accentPurple => 'Purple';

  @override
  String get settingsTextSize => 'Text size';

  @override
  String get textSizeNormal => 'Normal';

  @override
  String get textSizeLarge => 'Large';

  @override
  String get textSizeHuge => 'Very large';

  @override
  String get myProjectBodyAttendance =>
      'Attendance, new workers and casting logs use this project by default. Still changeable on each screen.';

  @override
  String get myProjectBody =>
      'The drilling & casting point list opens with this project on top.';

  @override
  String get myProjectSaved => 'My project saved.';

  @override
  String get myProjectCleared => 'My project cleared.';

  @override
  String get projectsLoadFailed => 'Could not read the project list';

  @override
  String get projectsMissingTitle => 'No project list on this phone yet';

  @override
  String get projectsMissingBody =>
      'Pull down on Home to fetch it from the server. Signal is needed once only.';

  @override
  String get notifTitle => 'Vibrating reminders';

  @override
  String get notifOn =>
      'On. The phone buzzes when a truck passes 20 minutes and while a pour is paused. A watch already paired to the phone receives the reminders and the Finish truck button too — no extra setting here.';

  @override
  String get notifOff =>
      'Off. Tap to allow; without it the casting reminders never appear.';

  @override
  String get notifBlockedTitle => 'Reminders will not appear';

  @override
  String get notifBlockedBody =>
      'This phone has not allowed TerraBot Field to show notifications. Reminders for a TM past 20 minutes, a paused pour, and a drill log left open will all stay silent. Tap Allow.';

  @override
  String get notifAllow => 'Allow';

  @override
  String get notifAllowManual =>
      'Notifications are still turned off by the phone. Open phone Settings → Apps → TerraBot Field → Notifications and switch them on.';

  @override
  String get powerTitle => 'Battery & auto-start';

  @override
  String get powerOk =>
      'Unrestricted. Reminders and auto-send keep running with the screen off.';

  @override
  String get powerRestricted =>
      'Still restricted by the phone. Tap to fix, so casting reminders are not missed.';

  @override
  String get reloadPermissions => 'Reload permissions';

  @override
  String get reloadPermissionsBody =>
      'After the office changes your level or department.';

  @override
  String get permissionsReloaded => 'Permissions reloaded.';

  @override
  String logoutPendingTitle(int docs, int photos) {
    return '$docs records and $photos photos are still unsent';
  }

  @override
  String get logoutPendingBody =>
      'Signing out does NOT delete them; they go once you sign in again. But nobody else signing in on this phone can send them.';

  @override
  String get logout => 'Sign out';

  @override
  String get logoutConfirm => 'Sign out?';

  @override
  String get logoutConfirmBody => 'Signing in again needs signal.';

  @override
  String get cancel => 'Cancel';

  @override
  String get appVersion => 'App version';

  @override
  String serverLabel(String host) {
    return 'Server $host';
  }

  @override
  String deviceIdLabel(String id) {
    return 'Device ID $id';
  }

  @override
  String get sendLog => 'Send log to the admin';

  @override
  String get sendLogBody =>
      'If the app misbehaves: the error log from this phone, with no personal data.';

  @override
  String get noLogYet => 'No error log on this phone yet.';

  @override
  String logShareFailed(String error) {
    return 'Could not share the log: $error';
  }

  @override
  String get castingTitle => 'Casting log';

  @override
  String get projectsLoadError => 'Could not read the projects';

  @override
  String get pickProject => 'Pick a project';

  @override
  String get pickProjectBody =>
      'Points are entered by the office from the shop drawings';

  @override
  String get noCastingProjects =>
      'No casting projects on this phone yet. Pull down while you have signal.';

  @override
  String get myProjectTag => 'MY PROJECT';

  @override
  String pointCount(int n) {
    return '$n points';
  }

  @override
  String get pointsTitle => 'Drilling points';

  @override
  String pointsTitleOf(String code) {
    return '$code · drilling points';
  }

  @override
  String get toTop => 'To the top';

  @override
  String get pointsLoadError => 'Could not read the points';

  @override
  String get noPointsTitle => 'No drilling points yet';

  @override
  String get noPointsBody =>
      'Points are entered by the office (Excel import in TerraBot web). Pull down on the previous page to fetch the latest.';

  @override
  String get searchPointCode => 'Search point code';

  @override
  String get clear => 'Clear';

  @override
  String get filterAll => 'All';

  @override
  String get filterUndrilled => 'Not drilled';

  @override
  String get filterDrilled => 'Drilled';

  @override
  String get filterCast => 'Cast';

  @override
  String castProgress(int done, int total) {
    return '$done of $total points cast';
  }

  @override
  String get noMatchingPoints => 'No matching points.';

  @override
  String get stageCasting => 'Casting now';

  @override
  String get stageCast => 'Cast';

  @override
  String stageDrilled(String depth) {
    return 'Drilled $depth';
  }

  @override
  String get stageDrilling => 'Drilling now';

  @override
  String get stageUndrilled => 'Not drilled';

  @override
  String get gsMissingShort => 'Ground level missing';

  @override
  String pointHeading(String code) {
    return 'Point $code';
  }

  @override
  String get fieldDiameter => 'Diameter';

  @override
  String get fieldLevels => 'GS / cut-off / tip';

  @override
  String get fieldCutOffDepth => 'Cut-off depth from GS';

  @override
  String get fieldPlannedDrill => 'Planned drill length';

  @override
  String get fieldPlannedEff => 'Planned effective length';

  @override
  String get fieldPlannedVol => 'Planned theoretical volume';

  @override
  String get fieldActualDrill => 'Actual drilled depth';

  @override
  String get gsMissingTitle => 'Ground level not filled in';

  @override
  String get gsMissingBody =>
      'Depth from ground level cannot be worked out yet, and a casting log can only start once it is filled in. Enter it when marking this point drilled.';

  @override
  String get notFilled => 'not filled in';

  @override
  String get castLogExists => 'This point already has a casting log';

  @override
  String get castLogOnMyOther => 'Its casting log is on your other phone';

  @override
  String get castLogElsewhere => 'Being cast from another phone';

  @override
  String castLogHeldBody(String who) {
    return '$who holds its casting log. One point may have only one casting log. If that log is wrong, ask the office to delete it first.';
  }

  @override
  String get logIsMineBody =>
      'This log is held by your own account; only its contents are not on this phone. Take it here, no handover code needed.';

  @override
  String castLogHandoverBody(String who) {
    return '$who holds its casting log. One point may have only one casting log. To continue from this phone, ask them to tap \"Hand over\" and type the code here.';
  }

  @override
  String get takeToThisPhone => 'Take it to this phone';

  @override
  String get continueHereCode => 'Continue on this phone (handover code)';

  @override
  String get drillLogOnMyOther => 'Its drilling log is on your other phone';

  @override
  String get drillLogElsewhere => 'Being drilled from another phone';

  @override
  String drillLogHandoverBody(String who) {
    return 'Its drilling log is held by $who. One point may have only one drilling log. To continue from this phone, ask them to tap \"Hand over\" and type the code here.';
  }

  @override
  String get drillFirstTitle => 'Record the drilling first';

  @override
  String get castAfterDrillLog =>
      'A casting log can start once the drilling log is closed with \"Finish drilling\".';

  @override
  String get castAfterDrilled =>
      'A casting log can only start once this point is drilled: through a drilling log, or by marking it directly.';

  @override
  String get viewOnlyTitle => 'View only';

  @override
  String get viewOnlyCastBody => 'This account may not record casting logs.';

  @override
  String get continueDrillLog => 'Continue drilling log';

  @override
  String get viewDrillLog => 'View drilling log';

  @override
  String get startDrillLog => 'Start drilling log';

  @override
  String get markDrilledNoLog => 'Mark as drilled (no log)';

  @override
  String get correctDrillGs => 'Correct drilled depth / GS';

  @override
  String get openCastLog => 'Open casting log';

  @override
  String get startCastLog => 'Start casting log';

  @override
  String get confirmPointCodeTitle => 'Type the point number';

  @override
  String get confirmPointCodeBody =>
      'Look at the pile you are about to cast, not the list on the phone. What you type here is what keeps this log off the point next door.';

  @override
  String get confirmPointCodeField => 'Point number';

  @override
  String get confirmPointCodeConfirm => 'Correct, start casting';

  @override
  String confirmPointCodeMismatch(String selected, String typed) {
    return 'You picked $selected in the list; you typed $typed. If $typed is the right one, close this and pick it from the list.';
  }

  @override
  String get colleague => 'A colleague';

  @override
  String markedDrilled(String code, String depth) {
    return '$code marked as drilled $depth.';
  }

  @override
  String get gsInvalid => 'The ground level is not valid.';

  @override
  String get gsRequiredMsg =>
      'Enter this point’s ground level. A casting log cannot start without it.';

  @override
  String get drillDepthInvalid =>
      'Enter the drilled depth (m), greater than 0.';

  @override
  String drillDepthTooDeep(String max) {
    return 'The deepest allowed is $max. Check the figure.';
  }

  @override
  String markDrilledTitle(String code) {
    return 'Mark $code drilled';
  }

  @override
  String get checkInput => 'Check the entry';

  @override
  String get gsFieldRequired => 'Ground level (m) — required';

  @override
  String get gsField => 'Ground level (m)';

  @override
  String get cutOffAboveGsTitle => 'Cut-off above ground level';

  @override
  String cutOffAboveGsBody(String col) {
    return 'COL $col is higher than this ground level. Make sure the GS figure is right before saving.';
  }

  @override
  String get drillDepthField => 'Drilled depth (m)';

  @override
  String beyondPlanTitle(String over) {
    return '$over beyond the plan';
  }

  @override
  String beyondPlanBody(String planned) {
    return 'Planned $planned. A little over is fine; make sure deeper drilling is really needed.';
  }

  @override
  String get save => 'Save';

  @override
  String get drillLogWord => 'drilling log';

  @override
  String get castLogWord => 'casting log';

  @override
  String sendingFirst(String log) {
    return 'Sending the $log first…';
  }

  @override
  String get sendBeforeHandoverTitle => 'Send it before handing over';

  @override
  String sendBeforeHandoverBody(String log) {
    return 'This $log has not reached the server yet, so it cannot be handed over. Find signal for a moment and try again — your colleague receives exactly the latest contents.';
  }

  @override
  String get understood => 'Got it';

  @override
  String get askingCode => 'Asking for a handover code…';

  @override
  String handoverTitle(String log, String code) {
    return 'Hand over $log $code';
  }

  @override
  String handoverBody(String code) {
    return 'Ask your colleague to open point $code on their phone and choose \"Continue on this phone\", then read out this code:';
  }

  @override
  String codeValidFor(int minutes) {
    return 'Valid $minutes minutes, single use';
  }

  @override
  String get codeValidBody =>
      'Once they type it in, the log moves to them and this phone becomes view-only. Photos taken on this phone are still sent from here.';

  @override
  String get done => 'Done';

  @override
  String takeLogHere(String log, String code) {
    return 'Take $log $code to this phone';
  }

  @override
  String takeLogHereBody(String log) {
    return 'This $log is indeed held by your account; only its contents are not on this phone. No handover code needed.\n\nIf it is open on your other phone, carry on using ONE phone only so the entries do not clash.';
  }

  @override
  String takingLog(String log) {
    return 'Fetching the $log…';
  }

  @override
  String logNowHere(String log, String code) {
    return '$log $code is now held by this phone.';
  }

  @override
  String continueLog(String log, String code) {
    return 'Continue $log $code';
  }

  @override
  String get enterHandoverCode =>
      'Type the 6-digit handover code read out by whoever holds the log (they tap \"Hand over\" on their phone).';

  @override
  String get takeOver => 'Take over';

  @override
  String get castLogNotOnPhone => 'Casting log not found on this phone.';

  @override
  String get pointNotOnPhone =>
      'The point is not on this phone. Pull the latest data while you have signal.';

  @override
  String gsMissingFor(String code) {
    return 'Ground level for point $code is not filled in. Go back to the point list, choose \"Mark as drilled\" and enter it.';
  }

  @override
  String pointHasCastLog(String code, String by) {
    return 'Point $code already has a casting log$by. One point may have only one casting log.';
  }

  @override
  String byWhom(String who) {
    return ' by $who';
  }

  @override
  String pointNotDrilled(String code) {
    return 'Point $code is not marked as drilled. Go back to the point list, choose \"Mark as drilled\" and enter the depth.';
  }

  @override
  String get notSignedIn => 'Not signed in — nothing was saved.';

  @override
  String get lockedByOffice =>
      'The office has reviewed this casting log — it can no longer be changed.';

  @override
  String heldByOther(String who) {
    return 'This casting log is held by $who — change it from their phone.';
  }

  @override
  String get tremieTooLongTitle => 'Tremie too long';

  @override
  String tremieTooLongAdd(String len, String stick, String max, String need) {
    return 'With this $len m section the tremie top stands $stick above ground level (at most $max, hopper height). This hole needs $need of tremie. Check the sections again.';
  }

  @override
  String get tremieBottomTitle => 'Tremie bottom piece';

  @override
  String get lengthM => 'Length (m)';

  @override
  String get tremieBottomHint =>
      'The pointed piece fitted at the very bottom. Measure its length for this pour.';

  @override
  String get topSegmentRemoved => 'Top section removed from the stack.';

  @override
  String get segmentLength => 'Section length';

  @override
  String get dontPullYet => 'Do not pull it yet';

  @override
  String get embedTooShortTitle => 'Embedment too short';

  @override
  String embedAfterRemoval(String len, String after, String min) {
    return 'Pulling this $len m section leaves only $after of tremie in the concrete (at least $min is required). Fresh concrete could break through the surface and mix with slurry.';
  }

  @override
  String estimateSoundFirst(String text) {
    return '$text\n\nThis concrete level is an estimate. Sound it first if in doubt.';
  }

  @override
  String get tickAnyway => 'Tick it anyway';

  @override
  String get pullUndone => 'Pull undone; the section is fitted again.';

  @override
  String get pullTickTitle => 'Record this section as pulled?';

  @override
  String pullTickBody(int pos, String panjang, int seq, String sisa) {
    return 'Section #$pos ($panjang m) will be recorded as pulled after truck #$seq, leaving $sisa embedded. This goes into the Piling Record as evidence.';
  }

  @override
  String pullTickAfterPour(int seq) {
    return 'Truck #$seq has already finished pouring. If the tremie was not actually pulled, do not record it.';
  }

  @override
  String pullRecorded(int seq) {
    return 'Section recorded as pulled after truck #$seq.';
  }

  @override
  String truckSaved(int seq) {
    return 'Truck #$seq saved.';
  }

  @override
  String truckUpdated(int seq) {
    return 'Truck #$seq updated.';
  }

  @override
  String get atCutOffTitle => 'Concrete has reached cut-off';

  @override
  String atCutOffBody(String level, String cutoff, String over) {
    return 'Concrete level $level from ground, cut-off $cutoff$over. This point is usually finished here.';
  }

  @override
  String overBy(String over) {
    return ' ($over over)';
  }

  @override
  String get estimateFromVolume =>
      'This figure is estimated from the volume. Sound it to be sure.';

  @override
  String get finishCasting => 'Finish casting';

  @override
  String get addTruckAnyway => 'Add a truck anyway';

  @override
  String soundingAfter(String seq) {
    return 'Sounding after truck #$seq';
  }

  @override
  String soundingBefore(String seq) {
    return 'Sounding before truck #$seq';
  }

  @override
  String get soundingQuestion =>
      'From the ground down to the concrete surface, how many metres?';

  @override
  String get concreteDepthField => 'Ground down to concrete surface';

  @override
  String soundingHint(String est) {
    return 'Must be measured. Estimated from volume: $est.';
  }

  @override
  String soundingMissing(int seq) {
    return 'Sounding for truck #$seq is missing. Required before the next truck.';
  }

  @override
  String truckStartTime(String seq) {
    return 'Start time of truck #$seq';
  }

  @override
  String truckEndTime(String seq) {
    return 'End time of truck #$seq';
  }

  @override
  String soundingCleared(String seq) {
    return 'Sounding for truck #$seq cleared.';
  }

  @override
  String soundingSaved(String seq, String value) {
    return 'Sounding for truck #$seq saved: $value.';
  }

  @override
  String get tremieNotAtBottom => 'Tremie not down to the bottom';

  @override
  String tremieTooLongNow(
    String fitted,
    String stick,
    String max,
    String need,
  ) {
    return 'Fitted $fitted; its top stands $stick above ground level (at most $max). This hole needs $need. Remove the extra sections first.';
  }

  @override
  String tremieShortBody(String fitted, String need) {
    return 'Fitted $fitted, $need needed (hole bottom less the gap). Add sections first: concrete dropped from higher up mixes with slurry.';
  }

  @override
  String notifPouring(String seq) {
    return 'Pouring truck #$seq';
  }

  @override
  String notifTapToOpen(String vol) {
    return '$vol m³ · tap to open the casting log';
  }

  @override
  String pourStarted(String seq) {
    return 'Truck #$seq started. The clock runs in the notification.';
  }

  @override
  String notifTruckLate(String seq, int min, String code) {
    return 'Truck #$seq has run $min minutes · $code';
  }

  @override
  String get notifTruckLateBody =>
      'Still not finished. Check the concrete level and the tremie.';

  @override
  String notifPausedTitle(int seq) {
    return 'Truck #$seq paused';
  }

  @override
  String notifPausedBody(String reason) {
    return '$reason · tap to resume';
  }

  @override
  String notifStillPaused(int seq, String code) {
    return 'Truck #$seq still paused · $code';
  }

  @override
  String get notifStillPausedBody =>
      'Pouring again? Tap Resume in the casting log';

  @override
  String pourPaused(String reason) {
    return 'Pour paused: $reason.';
  }

  @override
  String pourResumed(int seq) {
    return 'Truck #$seq resumed.';
  }

  @override
  String notifNoNextTruck(String code) {
    return 'No next truck yet · $code';
  }

  @override
  String get notifNoNextTruckBody =>
      'Watch for a cold joint. Check when the truck arrives';

  @override
  String truckFinished(int seq) {
    return 'Truck #$seq finished.';
  }

  @override
  String get castDataSaved => 'Casting details saved.';

  @override
  String get finishNotStored =>
      'The finished status was not stored. Tap \"Finish casting\" once more.';

  @override
  String castFinished(String code) {
    return 'Casting $code finished. It is sent automatically when there is signal.';
  }

  @override
  String get castReopened =>
      'Casting log reopened. Remember to finish it when you are done.';

  @override
  String get cleanTremieTitle => 'Clean the tremie and hopper';

  @override
  String get beforeNextUse => 'Before the next use';

  @override
  String get cleanWhy =>
      'Concrete left to harden inside the pipe or the joints can block the tremie on the next pour.';

  @override
  String get cleanStep1 =>
      'Hose down the hopper and every tremie section until no concrete is left.';

  @override
  String get cleanStep2 =>
      'Clean the joints and rubber seals; replace any damaged seal.';

  @override
  String get cleanStep3 => 'Do it at once, before the concrete hardens.';

  @override
  String get cleanStep4 => 'Stack it back in its place, not on the ground.';

  @override
  String get cleanedOk => 'Done, cleaned';

  @override
  String castOf(String code) {
    return 'Casting $code';
  }

  @override
  String get handOverToMate => 'Hand over to a colleague';

  @override
  String handedOverTo(String who) {
    return 'Handed over to $who';
  }

  @override
  String handedOverBody(String who) {
    return 'This casting log continues on $who’s phone. Here it is view-only; changes are made on the holder’s phone.';
  }

  @override
  String get rejectedByServer => 'Rejected by the server';

  @override
  String get reviewedByOffice => 'Reviewed by the office';

  @override
  String officeNote(String note) {
    return 'Note: $note';
  }

  @override
  String get cannotChangeAnymore =>
      'This casting log can no longer be changed.';

  @override
  String get gradeMissingTitle => 'Concrete grade (fc\') not filled in';

  @override
  String get gradeMissingBody =>
      'Neither this point nor this project has a default grade. Enter it in the casting details, or the server will reject the log.';

  @override
  String get finishNeedsGrade => 'Fill the grade first';

  @override
  String get fill => 'Fill it in';

  @override
  String get drillDepthUnmarked => 'Drilled depth not marked';

  @override
  String get drillDepthUnmarkedBody =>
      'The figures use the PLANNED drill length. Mark the actual depth from the point list so the cut suggestion is right.';

  @override
  String get tremieSection => 'Tremie';

  @override
  String tremieSectionBody(String gap) {
    return 'Sections bottom → top. The lower end sits $gap above the hole bottom.';
  }

  @override
  String get trucksSection => 'Mixer trucks';

  @override
  String trucksSectionBody(int n, String vol) {
    return '$n trucks · $vol m³';
  }

  @override
  String get noTrucksYet => 'No trucks yet';

  @override
  String get noTrucksReadOnly => 'This casting log has no trucks.';

  @override
  String get noTrucksTremieFirst =>
      'Build the tremie first, then tap \"Truck #1 arrived\" when the first truck gets there.';

  @override
  String get noTrucksTapArrived =>
      'Tap \"Truck #1 arrived\" below when the first truck gets there.';

  @override
  String get pause => 'Pause';

  @override
  String get resume => 'Resume';

  @override
  String finishTruck(String seq) {
    return 'Finish truck #$seq';
  }

  @override
  String startTruck(String seq) {
    return 'Start pouring truck #$seq';
  }

  @override
  String get tremieFirst => 'Build the tremie first';

  @override
  String truckArrived(int seq) {
    return 'Truck #$seq arrived';
  }

  @override
  String get castDone => 'Casting finished';

  @override
  String get savedAutoSend => 'Saved. Sent automatically.';

  @override
  String get reopen => 'Reopen';

  @override
  String planNoPull(int seq) {
    return 'Plan for truck #$seq: no pulling needed';
  }

  @override
  String planTitle(int seq) {
    return 'Plan for truck #$seq';
  }

  @override
  String planCutLine(String vol, String which, String before, String after) {
    return '• After ±$vol m³: pull $which → embedment $before → $after m';
  }

  @override
  String get joinThen => ' then ';

  @override
  String warnEmbedShort(String emb) {
    return '⚠ Embedment before this truck is only $emb m — check the sounding.';
  }

  @override
  String warnNoSafePull(String vol) {
    return '⚠ After ±$vol m³ the embedment passes 6 m and no section is safe to pull.';
  }

  @override
  String planEnd(String level, String emb, String cut) {
    return 'Estimated at the end of the truck: concrete level $level, embedment $emb$cut.';
  }

  @override
  String get cutOffReachedSuffix => ' — cut-off reached';

  @override
  String usingOverbreak(String ratio) {
    return 'Using an overbreak ratio of $ratio from the earlier soundings.';
  }

  @override
  String embedTitle(String emb, String est) {
    return 'Embedment $emb$est';
  }

  @override
  String get estimateSuffix => ' (estimated)';

  @override
  String get notSoundedYet =>
      'The concrete level has not been sounded — this figure comes from the volume. Sound it before pulling.';

  @override
  String get dontPullUnderOne =>
      'Less than 1 m: do NOT pull. The tremie could come out of the concrete.';

  @override
  String get noPullNeeded => 'No pulling needed right now.';

  @override
  String pullSuggestion(String which, String after) {
    return 'Suggestion: pull $which → embedment $after. Tick it in the tremie list once pulled.';
  }

  @override
  String get tick => 'Tick';

  @override
  String get cellGrade => 'Grade fc\'';

  @override
  String get cellSupplier => 'Supplier';

  @override
  String get cellHoleBottom => 'Hole bottom';

  @override
  String get cellCutOff => 'Cut-off';

  @override
  String get cellConcreteLevel => 'Concrete level';

  @override
  String get cellTheoretical => 'Theoretical';

  @override
  String get cellUsed => 'Used';

  @override
  String get cellOveruse => 'Overuse';

  @override
  String get estimatedFootnote => '* estimated from the volume';

  @override
  String tremieNeedFrom(String need) {
    return '$need needed. Start with the bottom piece (the pointed end).';
  }

  @override
  String tremieOverLong(String stick, String max) {
    return 'Too long: the top stands $stick above ground level (at most $max). Remove the top section.';
  }

  @override
  String tremieAtBottom(String stick) {
    return 'Down to the bottom. The top stands $stick above ground level (hopper).';
  }

  @override
  String tremieShortBy(String missing) {
    return '$missing short of the bottom.';
  }

  @override
  String ofNeeded(String need) {
    return 'of $need needed';
  }

  @override
  String get fitBottomPiece => 'Fit the bottom piece';

  @override
  String get other => 'Other';

  @override
  String get removeTop => 'Remove top';

  @override
  String get pullTremieTitle => 'Pulling the tremie';

  @override
  String get pullTremieBody =>
      'Tap \"Pull\" on each section pulled after this truck. The drawing above follows.';

  @override
  String tremieBottomOf(String len) {
    return 'Bottom piece · $len m';
  }

  @override
  String pipeOf(String len) {
    return 'Pipe $len m';
  }

  @override
  String pulledAfterTruck(String seq) {
    return 'Pulled after truck #$seq';
  }

  @override
  String get lowest => 'lowest';

  @override
  String get pull => 'Pull';

  @override
  String truckHeading(int seq, String vol) {
    return 'Truck #$seq · $vol m³';
  }

  @override
  String hullNo(String no) {
    return 'Hull $no';
  }

  @override
  String ticketNo(String no) {
    return 'DN $no';
  }

  @override
  String slumpOf(String cm) {
    return 'Slump $cm cm';
  }

  @override
  String get tremieFitted => 'Tremie fitted';

  @override
  String get start => 'Start';

  @override
  String get finish => 'Finish';

  @override
  String pausesCount(int n, String total) {
    return '$n× · $total';
  }

  @override
  String pauseLine(String reason, String from, String to) {
    return '$reason · $from–$to';
  }

  @override
  String get now => 'now';

  @override
  String get soundingBeforeLabel => 'Sounding before';

  @override
  String get soundingAfterLabel => 'Sounding after';

  @override
  String get soundingAfterRequired =>
      'The sounding after is required. Tap the row above.';

  @override
  String get overbreakRatio => 'Hole wider than design';

  @override
  String get deliveryNote => 'Delivery note';

  @override
  String get slumpTest => 'Slump test';

  @override
  String get pausedLabel => 'Paused';

  @override
  String overMinutes(int min) {
    return '$min minutes over';
  }

  @override
  String get pourTime => 'Pouring time';

  @override
  String pauseTruckTitle(int seq) {
    return 'Pause truck #$seq';
  }

  @override
  String get pauseTruckBody =>
      'Why the pause? The pouring clock stops, and the phone buzzes every 3 minutes until you tap Resume.';

  @override
  String volumeInvalid(String max) {
    return 'Enter the truck volume (m³), at most $max.';
  }

  @override
  String volumeUnusual(String vol) {
    return '$vol m³ is larger than usual (5–7 m³). Check the delivery note; if it is right, tap Save truck again.';
  }

  @override
  String get slumpInvalid => 'That slump is not plausible (0–40 cm).';

  @override
  String editTruck(int seq) {
    return 'Edit truck #$seq';
  }

  @override
  String get photoTicket => 'Photo of the delivery note';

  @override
  String get photoSlump => 'Photo of the slump test';

  @override
  String get hullNoField => 'Truck hull number';

  @override
  String get truckSupplier => 'Concrete supplier for this truck';

  @override
  String get otherTypeName => 'Other — type the name';

  @override
  String get otherSupplierName => 'Other supplier name';

  @override
  String get volumeField => 'Volume';

  @override
  String get slumpField => 'Tested slump';

  @override
  String get soundingBeforeOptional => 'Sounding before (optional)';

  @override
  String estimateHint(String value) {
    return 'estimated $value';
  }

  @override
  String get saveChanges => 'Save changes';

  @override
  String get saveTruck => 'Save truck';

  @override
  String get castDataTitle => 'Casting details';

  @override
  String defaultGrade(String grade) {
    return 'Default grade fc\' $grade MPa';
  }

  @override
  String get defaultGradeBody =>
      'From the point or project. Fill it in only if the concrete that arrives differs.';

  @override
  String get suppliersWithPo => 'Suppliers with a concrete PO on this project';

  @override
  String get noPoYet => 'No concrete PO on this project yet';

  @override
  String get suppliersWithPoBody =>
      'Used as the default for each truck; every truck can still pick its own supplier. Not in the list? Choose \"Other\", type the name, and tell the office.';

  @override
  String get noPoYetBody =>
      'Showing every concrete supplier; the list narrows by itself once the office raises a PO. Every truck can still pick its own supplier.';

  @override
  String get noteField => 'Note';

  @override
  String hangAboveGs(String top, String bottom) {
    return '$top–$bottom m above ground level';
  }

  @override
  String hangAcrossGs(String top, String bottom) {
    return '$top m above ground level down to $bottom m deep';
  }

  @override
  String hangDepth(String top, String bottom) {
    return 'depth $top–$bottom m';
  }

  @override
  String get stopTremieBlocked => 'Tremie blocked / concrete stuck';

  @override
  String get stopNoTruck => 'No truck / concrete ran out';

  @override
  String get stopHoleCollapse => 'Hole collapsed';

  @override
  String get stopPlantWeather => 'Plant breakdown or weather';

  @override
  String labelDetail(String label, String detail) {
    return '$label — $detail';
  }

  @override
  String stoppedBeforeCutOff(String missing, String vol, String why) {
    return 'Pour stopped before cut-off ($missing ≈ $vol m³ short): $why';
  }

  @override
  String get belowCutOffTitle => 'Concrete has not reached cut-off';

  @override
  String finishCastingOf(String code) {
    return 'Finish casting $code?';
  }

  @override
  String shortfallTitle(String vol, int trucks) {
    return 'Still $vol m³ short (about $trucks more trucks)';
  }

  @override
  String shortfallLine1(String level, String cutoff, String missing) {
    return 'Concrete level $level from ground, cut-off $cutoff — $missing short.';
  }

  @override
  String shortfallLine2(String poured, String theoretical, String percent) {
    return '$poured m³ poured of about $theoretical m³ theoretical$percent.';
  }

  @override
  String percentSuffix(String percent) {
    return ' ($percent%)';
  }

  @override
  String get estimateSoundToBeSure =>
      'This figure is estimated from the volume — sound it to be sure.';

  @override
  String get shortPileWarning =>
      'A pile closed below cut-off is a short pile, and concrete sets — there is no undo. If the pour really was stopped, pick the reason; the office needs to know. If you tapped by mistake, choose \"Not yet — keep pouring\".';

  @override
  String get reasonRequired => 'Reason (required)';

  @override
  String get detailOptional => 'Details (optional)';

  @override
  String get reasonHint =>
      'e.g. tremie blocked at the 3rd section, concrete had set';

  @override
  String get shortABitBody =>
      'Only a little short of cut-off — anything above cut-off gets trimmed anyway. The point is marked cast; the log can still be corrected until the office reviews it.';

  @override
  String get finishedBody =>
      'The point is marked cast. The log can still be corrected until the office reviews it.';

  @override
  String get finishAnyway => 'Finish anyway';

  @override
  String get notYetKeepPouring => 'Not yet — keep pouring';

  @override
  String get notYet => 'Not yet';

  @override
  String get castLogTitle => 'Casting log';

  @override
  String overuseTitle(String percent) {
    return 'Concrete used $percent% above theoretical';
  }

  @override
  String overuseBody(String level, String used, String theoretical) {
    return 'Up to concrete level $level: $used m³ used, $theoretical m³ theoretical. The hole may be over-cut or collapsing. Report it to the supervisor.';
  }

  @override
  String get gapInvalid => 'Tremie bottom gap must be 0–5 m.';

  @override
  String get reasonTidakValid => 'The data is not valid';

  @override
  String get reasonTidakBerhak => 'Your account may not save this data';

  @override
  String get reasonBukanMilik => 'This data belongs to another user';

  @override
  String get reasonDioper =>
      'This log was handed over — changes only from the holder’s phone';

  @override
  String get reasonSudahDihapus => 'The office has deleted this data';

  @override
  String get reasonSudahDitinjau =>
      'The office reviewed this attendance — it can no longer be changed';

  @override
  String get reasonSudahDiperiksa =>
      'The office reviewed this casting log — it can no longer be changed';

  @override
  String get reasonSudahDicor => 'This point is already recorded as cast';

  @override
  String get reasonProyekTidakAda => 'Project not found or already closed';

  @override
  String get reasonProyekTanggalTetap =>
      'Project and attendance date cannot be changed once sent';

  @override
  String get reasonTanggalDepan =>
      'Attendance date is in the future — check the phone clock';

  @override
  String get reasonAbsenSudahAda =>
      'You already have attendance for this project and date';

  @override
  String get reasonWorkerBelumAda =>
      'Waiting for the new worker to be sent first';

  @override
  String get reasonPekerjaDihapus =>
      'One of the workers was deleted by the office';

  @override
  String get reasonPekerjaBukanKru => 'One of the workers is not in your crew';

  @override
  String get reasonPekerjaGanda => 'A worker is listed twice';

  @override
  String get reasonUuidBentrok =>
      'The data clashes with other data — contact the admin';

  @override
  String get reasonTitikTidakAda =>
      'The point was not found or has been deleted';

  @override
  String get reasonTitikTetap => 'The casting log’s point cannot be changed';

  @override
  String get reasonCorSudahAda =>
      'This point already has a casting log from another phone';

  @override
  String get reasonMutuKosong =>
      'Concrete grade (fc\') is missing — enter it in the casting log, or ask the office to set it on the point/project';

  @override
  String get reasonPemasokTidakAda => 'Concrete supplier not found';

  @override
  String get reasonTmGanda => 'Duplicate truck number';

  @override
  String get reasonJamTmTerbalik =>
      'The truck’s end time is before its start time';

  @override
  String get reasonSegmenGanda => 'Duplicate tremie section position';

  @override
  String get reasonSegmenTmAsing =>
      'Section pulled after a truck that does not exist';

  @override
  String get reasonGsKosong =>
      'This point’s ground level is missing — enter it when marking the point drilled';

  @override
  String get reasonJedaTmAsing =>
      'There is a pause for a truck that does not exist';

  @override
  String get reasonJamJedaTerbalik =>
      'The pause times are not plausible — check the phone clock';

  @override
  String get reasonTremieBottomSalah =>
      'The bottom piece must be lowest, the only one, and not pulled';

  @override
  String get reasonSoundingKosong =>
      'The sounding after a truck is missing — required before finishing';

  @override
  String get reasonLogBorSudahAda =>
      'This point already has a drilling log from another phone';

  @override
  String get reasonKedalamanMundur =>
      'A drilling reading is shallower than the one before it';

  @override
  String get reasonBorKosong => 'The drilling log has no depth reading at all';

  @override
  String get reasonEntriGanda => 'A drilling reading is recorded twice';

  @override
  String get reasonBerkasHilang => 'The photo file is missing from the phone';

  @override
  String reasonWithDetail(String reason, String detail) {
    return '$reason ($detail)';
  }

  @override
  String get entityWorker => 'Worker';

  @override
  String get entityAttendance => 'Attendance';

  @override
  String get entityDrillMark => 'Drill mark';

  @override
  String get entityDrillLog => 'Drilling log';

  @override
  String get entityCasting => 'Casting log';

  @override
  String get pauseCabutTremie => 'Pulling the tremie';

  @override
  String get pauseTungguTm => 'Waiting for a truck';

  @override
  String get pauseKendalaAlat => 'Equipment trouble';

  @override
  String get drillLogNotOnPhone => 'Drilling log not found on this phone.';

  @override
  String get pointNotFoundPull =>
      'Point not found. Pull the latest data first.';

  @override
  String pointHasDrillLog(String code, String by) {
    return 'Point $code already has a drilling log$by. One point may have only one drilling log.';
  }

  @override
  String pointAlreadyCast(String code) {
    return 'Point $code has already been cast.';
  }

  @override
  String drillHeldByOther(String who) {
    return 'This drilling log is held by $who — change it from their phone.';
  }

  @override
  String get operatorSaved => 'Drill operator saved.';

  @override
  String get readingDeleted => 'Reading deleted.';

  @override
  String readingRecorded(String depth, String time) {
    return 'Recorded $depth at $time.';
  }

  @override
  String get drillFinishNotStored =>
      'The finished status was not stored. Tap \"Finish drilling\" once more.';

  @override
  String drillFinished(String code, String depth) {
    return '$code drilled to $depth.';
  }

  @override
  String get drillReopened => 'Drilling log reopened.';

  @override
  String drillOf(String code) {
    return 'Drilling $code';
  }

  @override
  String drillHandedOverBody(String who) {
    return 'This drilling log continues on $who’s phone. Here it is view-only; changes are made on the holder’s phone.';
  }

  @override
  String drilledToDepth(String depth) {
    return 'Drilled to $depth';
  }

  @override
  String get drilledBodyOk =>
      'The point is marked drilled; a casting log can start.';

  @override
  String get readingsSection => 'Readings';

  @override
  String readingsCount(int n) {
    return '$n readings';
  }

  @override
  String get noReadingsYet =>
      'No readings yet. Tap \"Record depth\" each time the depth is read.';

  @override
  String get finishDrilling => 'Finish drilling';

  @override
  String get recordDepth => 'Record depth';

  @override
  String get drillOperatorLabel => 'DRILL OPERATOR';

  @override
  String get notPicked => 'Not picked';

  @override
  String get pick => 'Pick';

  @override
  String get change => 'Change';

  @override
  String get finalDepthLabel => 'FINAL DEPTH';

  @override
  String get currentDepthLabel => 'CURRENT DEPTH';

  @override
  String get planNotComputable => 'the plan cannot be worked out yet';

  @override
  String ofPlanned(String planned) {
    return 'of $planned planned';
  }

  @override
  String startedAt(String time) {
    return 'started $time';
  }

  @override
  String runningFor(String duration) {
    return 'running $duration';
  }

  @override
  String deeperThanPlan(String over) {
    return '$over deeper than planned.';
  }

  @override
  String hoursMinutes(int h, int m) {
    return '$h h $m m';
  }

  @override
  String minutesOnly(int m) {
    return '$m minutes';
  }

  @override
  String depthGain(String gain, String duration) {
    return '+$gain in $duration';
  }

  @override
  String get readingTime => 'Reading time';

  @override
  String get depthInvalid => 'Enter the depth (m), greater than 0.';

  @override
  String get timeInFuture =>
      'That time is in the future. Check the reading time.';

  @override
  String get editReading => 'Edit reading';

  @override
  String lastReadingWas(String depth, String time) {
    return 'Last reading $depth at $time';
  }

  @override
  String plannedIs(String planned) {
    return 'planned $planned';
  }

  @override
  String get editTime => 'Edit time';

  @override
  String get depthFromGs => 'Depth from ground level';

  @override
  String get noteOptional => 'Note (optional)';

  @override
  String get drillNoteHint => 'e.g. hit rock, changed the bit';

  @override
  String get deleteThisReading => 'Delete this reading';

  @override
  String finishDrillingOf(String code) {
    return 'Finish drilling $code?';
  }

  @override
  String finishDrillBody(String depth) {
    return 'Final depth $depth (the deepest reading). The point is marked drilled and a casting log can start.';
  }

  @override
  String shallowerThanPlan(String short) {
    return 'Still $short shallower than planned';
  }

  @override
  String shallowerBody(String planned) {
    return 'Planned $planned. Make sure this is really where it stops.';
  }

  @override
  String get operatorNameRequired => 'Enter the operator’s name.';

  @override
  String operatorExists(String name) {
    return '\"$name\" already exists. Pick from the list if it is the same person, or tap Save again if it really is someone else.';
  }

  @override
  String get drillOperator => 'Drill operator';

  @override
  String get newOperator => 'New operator';

  @override
  String get checkFirst => 'Check first';

  @override
  String get operatorName => 'Operator name';

  @override
  String get phoneOptional => 'Phone (optional)';

  @override
  String get backToList => 'Back to the list';

  @override
  String get searchName => 'Search name';

  @override
  String get noMatchAddNew => 'No match. Add a new operator.';

  @override
  String get queueTitle => 'Send queue';

  @override
  String get queueLoadError => 'Could not read the queue';

  @override
  String get lastSendFailed => 'The last send failed';

  @override
  String queueCount(int docs, int photos) {
    return '$docs records · $photos photos';
  }

  @override
  String get notSentSinceOpen => 'Nothing sent since the app was opened';

  @override
  String lastTriedAt(String time) {
    return 'Last tried at $time';
  }

  @override
  String get allSent => 'Everything has been sent.';

  @override
  String get photosSection => 'Photos';

  @override
  String photoLine(String kind, String kb, String time) {
    return '$kind · $kb kB · $time';
  }

  @override
  String get photoFace => 'Worker face';

  @override
  String get photoCheckIn => 'Check-in';

  @override
  String get photoCheckOut => 'Check-out';

  @override
  String get photoTicketKind => 'Truck delivery note';

  @override
  String get photoSlumpKind => 'Truck slump test';

  @override
  String changedAt(String time, String id) {
    return 'Changed $time · $id';
  }

  @override
  String retryAt(String time) {
    return 'Retrying at $time';
  }

  @override
  String get discardTitle => 'Discard from the phone?';

  @override
  String get discardBody =>
      'This data will never be sent. It cannot be undone.';

  @override
  String get discard => 'Discard';

  @override
  String get unsavedTitle => 'Leave without saving?';

  @override
  String get unsavedBody =>
      'This sheet has entries that are not saved yet, including a photo just taken. A discarded photo will not attach to this truck.';

  @override
  String get discarded => 'Discarded from the phone.';

  @override
  String get queuedResend => 'Queued, resending now.';

  @override
  String get resend => 'Resend';

  @override
  String get fillEmailPassword => 'Enter the e-mail and password.';

  @override
  String get loginNeedsSignal =>
      'Signing in needs signal. After one sign-in, the app works offline.';

  @override
  String get accountOnOtherPhone =>
      'This account is still signed in on another phone';

  @override
  String oneAccountOnePhone(String last) {
    return 'One account may be used on one phone only, so the field records do not branch.$last';
  }

  @override
  String lastActiveSuffix(String when) {
    return ' That phone was last active $when.';
  }

  @override
  String get oldPhoneKeepsData => 'Nothing is lost on the old phone';

  @override
  String get oldPhoneKeepsDataBody =>
      'That phone can still send its queue; it just may not record anything new. If that is the phone you actually use, cancel and sign in there.';

  @override
  String get moveToThisPhone => 'Move it to this phone';

  @override
  String minutesAgo(int n) {
    return '$n minutes ago';
  }

  @override
  String hoursAgo(int n) {
    return '$n hours ago';
  }

  @override
  String daysAgo(int n) {
    return '$n days ago';
  }

  @override
  String get justNow => 'just now';

  @override
  String get loginTagline => 'Crew attendance & casting logs';

  @override
  String get dataSafeHere => 'Your data on this phone is safe';

  @override
  String get signInAgainToSend =>
      'Sign in again with the same account so the queue can be sent.';

  @override
  String get cannotSignInYet => 'Cannot sign in yet';

  @override
  String get email => 'E-mail';

  @override
  String get password => 'Password';

  @override
  String get signIn => 'Sign in';

  @override
  String get phoneReplacedTitle => 'This phone has been replaced';

  @override
  String get accountUsedElsewhere => 'This account is in use on another phone';

  @override
  String get phoneReplacedBody =>
      'Your account was signed in on another phone, so this one no longer takes new records. The remaining queue is still sent from here. If this is the phone you use, sign in again here.';

  @override
  String accountUsedElsewhereBody(String who, String until) {
    return 'Your account was signed in on another phone$who. Send the rest from this phone, then carry on there. From $until this phone no longer takes new records.';
  }

  @override
  String inParens(String what) {
    return ' ($what)';
  }

  @override
  String get signInOnThisPhone => 'Sign in on this phone';

  @override
  String get sessionExpired => 'Session ended — sign in again';

  @override
  String get sessionExpiredBody =>
      'Your data on this phone is SAFE and can still be filled in. Sign in again so the queue can be sent.';

  @override
  String clockOffTitle(String drift) {
    return 'Phone clock is $drift from the server clock';
  }

  @override
  String get clockOffBody =>
      'Every drilling reading time and truck time comes from this phone’s clock. Turn on \"Automatic date & time\" in the phone settings, then pull again.';

  @override
  String rejectedCount(int n) {
    return '$n records rejected by the server';
  }

  @override
  String get rejectedBody => 'Open the queue to see why and fix it.';

  @override
  String get view => 'View';

  @override
  String get sending => 'Sending…';

  @override
  String staleUnsent(int docs, int photos) {
    return 'Unsent for more than a day: $docs records, $photos photos';
  }

  @override
  String unsent(int docs, int photos) {
    return 'Unsent: $docs records, $photos photos';
  }

  @override
  String get staleUnsentBody =>
      'Find signal or WiFi, then tap Send. If it still does not go, contact the TerraBot admin.';

  @override
  String get offlineAutoSend =>
      'No signal. It is sent automatically as soon as the phone has signal, even with the app closed.';

  @override
  String get autoSendOnSignal =>
      'Sent automatically as soon as there is signal.';

  @override
  String get send => 'Send';

  @override
  String updateAvailableTitle(String version) {
    return 'Version $version is available';
  }

  @override
  String get updateAvailableBody =>
      'The app keeps working as usual. Update when you get a chance — easier before starting work than in the middle of a pour.';

  @override
  String get updateNow => 'Update';

  @override
  String get updateTitle => 'Update TerraBot Field';

  @override
  String updateBody(String current, String min) {
    return 'Version $current on this phone is no longer served. Install version $min or newer to keep working.';
  }

  @override
  String unsentSafeHere(int n) {
    return '$n records unsent — SAFE on this phone';
  }

  @override
  String get installOverBody =>
      'Install the new version OVER this app. Do NOT uninstall first: uninstalling deletes everything not yet sent. Once updated, the data goes by itself.';

  @override
  String get downloadNew => 'Download the new version';

  @override
  String get askAdminApk => 'Ask the admin for the latest app file';

  @override
  String get askAdminApkBody =>
      'The TerraBot admin will send the APK file or a link.';

  @override
  String get checkAgain => 'Check again';

  @override
  String get keepRunningTitle => 'Let TerraBot Field keep running';

  @override
  String get keepRunningBody =>
      'This phone kills apps that are not open. Without the settings below, the casting reminders (20 minutes, pauses) and auto-send do NOT run with the screen off.';

  @override
  String get openAutostart => 'Open the auto-start settings';

  @override
  String get openBattery => 'Open the app battery settings';

  @override
  String get setBatteryOnce => 'Set the phone battery once';

  @override
  String get setBatteryBody =>
      'So the casting reminders and auto-send keep running with the screen off.';

  @override
  String get setUp => 'Set up';

  @override
  String get thisPeriod => 'This period';

  @override
  String get fullRecap => 'Full recap';

  @override
  String fullRecapBody(String to) {
    return 'Every point from the start of the project to $to';
  }

  @override
  String get excelSubject => 'Pile data recap';

  @override
  String excelFailed(String error) {
    return 'Could not download the Excel: $error';
  }

  @override
  String get reportsTitle => 'Field report';

  @override
  String get presetToday => 'Today';

  @override
  String get presetYesterday => 'Yesterday';

  @override
  String get presetWeek => '7 days';

  @override
  String get pickDate => 'Pick a date';

  @override
  String get pickRange => 'Pick a range';

  @override
  String rangeTooLong(String max) {
    return 'The range may span at most $max days.';
  }

  @override
  String dateRange(String from, String to) {
    return '$from – $to';
  }

  @override
  String get preparingExcel => 'Preparing the Excel…';

  @override
  String get downloadExcel => 'Download Excel (pile data recap)';

  @override
  String get reportLoadError => 'Could not read the report';

  @override
  String get statDrilledPoints => 'Points drilled';

  @override
  String get statCastPoints => 'Points cast';

  @override
  String statCastSub(String vol, String trucks) {
    return '$vol m³ · $trucks trucks';
  }

  @override
  String get noPointsThatDay => 'No point was drilled or cast on this date.';

  @override
  String projectNo(String id) {
    return 'Project #$id';
  }

  @override
  String get pullToReload =>
      'Pull down to reload. Data from every phone that has sent.';

  @override
  String pointsSuffix(String n) {
    return '$n points';
  }

  @override
  String drilledCount(int n) {
    return 'Drilled ($n)';
  }

  @override
  String castCount(int n) {
    return 'Cast ($n)';
  }

  @override
  String get noLog => 'no log';

  @override
  String operatorShort(String name) {
    return 'op. $name';
  }

  @override
  String get statusDone => 'Finished';

  @override
  String get statusChecked => 'Reviewed';

  @override
  String theoreticalOf(String vol, String over) {
    return 'theoretical $vol m³$over';
  }

  @override
  String percentParens(String sign, String percent) {
    return ' ($sign$percent%)';
  }

  @override
  String get resumePouring => 'Resume pouring';

  @override
  String pauseReminderMin(String body, int min) {
    return '$body · $min minutes';
  }

  @override
  String idleReminderMin(String body, int min) {
    return '$body · $min minutes since the last truck';
  }

  @override
  String get drillSnoozeAction => 'Silence until tomorrow';

  @override
  String get activityTodayTitle => 'Today';

  @override
  String activityTodayMore(int n) {
    return '+$n more — open Reports for the full list';
  }

  @override
  String activityTodayDone(String jam) {
    return 'done $jam';
  }

  @override
  String activityTodayRunning(String jam) {
    return 'still running · last $jam';
  }

  @override
  String drillIdleTitle(String code) {
    return 'Drilling log $code has no new reading';
  }

  @override
  String drillIdleBody(String since, String time) {
    return 'It has been $since since the last reading ($time). Record the depth now, or tap Finish drilling if it is done.';
  }

  @override
  String hoursText(int h) {
    return '$h h';
  }

  @override
  String minutesText(int m) {
    return '$m min';
  }

  @override
  String hoursMinutesText(int h, int m) {
    return '$h h $m min';
  }

  @override
  String get unsentTitle => 'Some data is still unsent';

  @override
  String unsentBody(String since) {
    return 'Since $since. Open TerraBot Field where there is signal so it can be sent.';
  }

  @override
  String get badgeSent => 'Sent';

  @override
  String get badgeRejected => 'Rejected';

  @override
  String get badgeWaiting => 'Waiting for data';

  @override
  String get badgeFailedRetry => 'Failed, retrying';

  @override
  String get badgeUnsent => 'Not sent';

  @override
  String get powerXiaomi1 => 'Autostart: turn it ON for TerraBot Field.';

  @override
  String get powerXiaomi2 => 'Battery saver: choose \"No restrictions\".';

  @override
  String get powerOppo1 =>
      'Auto-start / Allow auto-launch: turn it ON for TerraBot Field.';

  @override
  String get powerOppo2 =>
      'Battery usage: allow \"Background activity\" and \"Auto-start\".';

  @override
  String get powerVivo1 =>
      'Auto-start / Background: ALLOW it for TerraBot Field.';

  @override
  String get powerVivo2 => 'Battery → High background power use: ALLOW.';

  @override
  String get powerHuawei1 =>
      'App launch: turn off \"Manage automatically\", then turn on Auto-launch, Secondary launch and Run in background.';

  @override
  String get powerSamsung1 => 'Battery: choose \"Unrestricted\".';

  @override
  String get powerSamsung2 =>
      'Make sure TerraBot Field is NOT in \"Sleeping apps\" / \"Deep sleeping apps\".';

  @override
  String get powerGeneric =>
      'Battery: choose \"Unrestricted\" / \"Not optimised\" for TerraBot Field.';

  @override
  String soundDeeperThanBottom(String bottom) {
    return 'Deeper than the hole bottom ($bottom m). Check again.';
  }

  @override
  String soundDeeperThanBefore(String before) {
    return 'Deeper than the concrete level before this truck ($before m). Concrete cannot drop; check again.';
  }

  @override
  String readingShallower(String time, String depth) {
    return 'Shallower than the reading at $time ($depth). A hole cannot get shallower.';
  }

  @override
  String readingDeeperThanNext(String time, String depth) {
    return 'Deeper than the next reading at $time ($depth). Check the time.';
  }

  @override
  String depthFarFromPlan(String depth, String planned, String max) {
    return '$depth m is far from the planned $planned m (deepest $max m). Check the figure, the point, or the ground level.';
  }

  @override
  String numberInvalid(String max) {
    return 'Enter a number greater than 0, at most $max.';
  }

  @override
  String get castAlreadyDone => 'This point’s casting is already finished.';

  @override
  String get noTruckPouring => 'No truck is pouring.';

  @override
  String truckAlreadyPaused(int seq) {
    return 'Truck #$seq is already paused.';
  }

  @override
  String truckNotPaused(int seq) {
    return 'Truck #$seq is not paused.';
  }

  @override
  String get photoUnreadable => 'The photo cannot be read.';

  @override
  String get photoCompressFailed => 'The photo cannot be compressed.';

  @override
  String get workersTitle => 'Workers';

  @override
  String get newWorker => 'New worker';

  @override
  String get workersLoadError => 'Could not read the worker list';

  @override
  String get workersAllBody =>
      'Every worker in the company. Anyone may take their attendance and edit them.';

  @override
  String workersNoProjectBody(String days) {
    return 'No main project and no attendance anywhere in the last $days days.';
  }

  @override
  String workersProjectBody(String code, String days) {
    return 'Main project $code, or attended at $code in the last $days days.';
  }

  @override
  String workersCount(int n) {
    return '$n workers';
  }

  @override
  String get noWorkersYet =>
      'No workers yet. Register one with the button below.';

  @override
  String get searchNameOrPhone => 'Search name or phone';

  @override
  String allCount(int n) {
    return 'All ($n)';
  }

  @override
  String withoutProject(int n) {
    return 'No project ($n)';
  }

  @override
  String get noMatchingWorkers => 'No matching workers.';

  @override
  String mainProjectIs(String code) {
    return 'Main project $code';
  }

  @override
  String lastSeenAt(String code, String date) {
    return 'Last at $code · $date';
  }

  @override
  String cameraFailed(String error) {
    return 'Camera failed: $error';
  }

  @override
  String get workerNameRequired => 'Enter the worker’s name.';

  @override
  String workerSaved(String name) {
    return '$name saved. Sent automatically when there is signal.';
  }

  @override
  String get mainProjectOptional => 'Main project (optional)';

  @override
  String get noMainProject => 'No main project';

  @override
  String andOthers(int n) {
    return '\n• and $n more';
  }

  @override
  String get maybeRegistered => 'May already be registered';

  @override
  String maybeRegisteredBody(String names) {
    return 'This name or phone looks like an existing worker:\n$names\n\nIf it is the same person, cancel and use the existing one. If it really is someone else, tap save again.';
  }

  @override
  String get needsFixing => 'Needs fixing';

  @override
  String get viewOnlyWorkerBody =>
      'Your account may not register or edit workers. Ask the office to grant the permission.';

  @override
  String get noFaceDetected => 'No face detected';

  @override
  String facesDetected(int n) {
    return '$n faces detected';
  }

  @override
  String get facePhotoBody =>
      'The office uses the face photo to match the crew. Retake it with one face, looking at the camera.';

  @override
  String get retake => 'Retake';

  @override
  String get fullName => 'Full name';

  @override
  String get phoneOptional2 => 'Phone (optional)';

  @override
  String get workerNoteHint => 'Note (e.g. steel fixer, operator)';

  @override
  String get saveAsNewWorker => 'Save as a new worker anyway';

  @override
  String get attendanceTitle => 'Crew attendance';

  @override
  String get attendToday => 'Today’s attendance';

  @override
  String get attendanceLoadError => 'Could not read the attendance';

  @override
  String get attendanceHistory => 'Attendance history';

  @override
  String get otherProject => 'another project';

  @override
  String get attendanceHistoryBody => 'Attendance created on this phone';

  @override
  String get noAttendanceYet => 'No attendance yet.';

  @override
  String failedWith(String error) {
    return 'Failed: $error';
  }

  @override
  String photoInGallery(String album) {
    return 'Photo saved to the phone gallery (album \"$album\").';
  }

  @override
  String get galleryDenied =>
      'Attendance saved, but the photo did not reach the gallery: permission denied.';

  @override
  String get galleryFailed =>
      'Attendance saved, but the photo could not be saved to the gallery.';

  @override
  String get saveCrewTicks => 'Save the crew ticks?';

  @override
  String get saveCrewTicksBody => 'There are unsaved crew changes.';

  @override
  String get crewAttendance => 'Crew attendance';

  @override
  String saveWithCount(int n) {
    return 'Save · $n crew';
  }

  @override
  String get rejectedByOffice => 'Rejected by the office';

  @override
  String get approvedByOffice => 'Approved by the office';

  @override
  String get attendanceLocked =>
      'This attendance can no longer be changed from the phone.';

  @override
  String get projectLabel => 'Project';

  @override
  String get projectNoLocation => 'The office has not set the project location';

  @override
  String get projectNoLocationBody =>
      'Attendance is still saved; the distance to the project cannot be checked.';

  @override
  String get checkIn => 'Check-in';

  @override
  String get checkOut => 'Check-out';

  @override
  String get savedWithoutLocation => 'Saved without a location';

  @override
  String savedWithoutLocationBody(String problem) {
    return '$problem The office will see this attendance flagged \"no location\".';
  }

  @override
  String crewPresent(int n) {
    return 'Crew present ($n)';
  }

  @override
  String get noWorkersTitle => 'No workers yet';

  @override
  String get noWorkersBody =>
      'Register a worker first. A worker registered here can be marked present at once, even before being sent.';

  @override
  String get thisProject => 'this project';

  @override
  String get searchWorkerName => 'Search worker name';

  @override
  String noWorkersForProject(String code) {
    return 'No workers for $code yet';
  }

  @override
  String noWorkersForProjectBody(String code, String days) {
    return 'Nobody has $code as their main project or has been marked present here in the last $days days. Tick them from the full list below; once sent, they appear at the top here.';
  }

  @override
  String get unknownWorker => 'Unknown worker';

  @override
  String otherWorkers(int n) {
    return 'Other workers ($n)';
  }

  @override
  String get noWorkerByName => 'No worker by that name.';

  @override
  String get flaggedForOffice => 'Flagged for the office to check';

  @override
  String get flagOutsideRadius =>
      '• The attendance location is outside the project radius';

  @override
  String get flagNoProjectLocation =>
      '• The office has not set the project location';

  @override
  String get flagNoLocation => '• Attendance without a GPS location';

  @override
  String get flagMockLocation => '• The phone reported a mock location';

  @override
  String get flagClockOff => '• The phone clock is far from the server clock';

  @override
  String get flagClockUnverified =>
      '• The phone clock could not be verified (the phone was restarted)';

  @override
  String get flagClockEdited => '• The time was edited by hand';

  @override
  String get flagFaceCountOff =>
      '• The number of faces differs from the crew size';

  @override
  String get flagPhotoPending => '• The photo is still waiting to be sent';

  @override
  String get fullDay => 'Full day';

  @override
  String get halfDay => '½ day';

  @override
  String get overtime => 'Overtime';

  @override
  String hoursShort(String h) {
    return '$h h';
  }

  @override
  String crewPhotoOf(String what) {
    return 'Crew photo · $what';
  }

  @override
  String atTime(String time) {
    return 'At $time';
  }

  @override
  String withinRadius(String m) {
    return '$m m from the project ✓';
  }

  @override
  String outsideRadius(String m, String radius) {
    return '$m m from the project — outside the $radius m radius';
  }

  @override
  String get noLocation => 'No location';

  @override
  String get mockLocation => 'Mock location detected';

  @override
  String facesInPhoto(int n) {
    return '$n faces in the photo';
  }

  @override
  String get longPressRetake => 'Press and hold to retake';

  @override
  String get levelRefTitle => 'Level reference';

  @override
  String levelRefColTip(String col, String tip) {
    return 'COL $col · Tip $tip';
  }

  @override
  String get notSet => 'not set';

  @override
  String get levelRefNoGs =>
      'Enter the ground level first to see the cut-off depth and the planned drill length.';

  @override
  String levelRefGs(String gs) {
    return 'Ground level $gs';
  }

  @override
  String levelRefColBelow(String d) {
    return '• COL $d below ground level';
  }

  @override
  String levelRefPlanned(String d) {
    return '• Planned drill $d';
  }

  @override
  String get levelRefFooter =>
      'Drill depth is measured from ground level to the hole bottom.';

  @override
  String get projectsMissingHome =>
      'Pull down to fetch it from the server. Signal is needed once; after that it works offline.';

  @override
  String get noFieldAccess => 'This account has no field access yet';

  @override
  String get noFieldAccessBody =>
      'Ask the TerraBot admin to add the Field Engineer department to your account, then pull down.';

  @override
  String get volumePouredHere => 'Volume poured into this point';

  @override
  String get volumeSharedHint =>
      'Defaults to the whole truck. If this truck is shared with another hole, enter only the part poured here.';

  @override
  String overuseAheadTitle(String percent) {
    return 'Concrete will run $percent% over theory';
  }

  @override
  String overuseAheadBody(String used, String theoretical) {
    return '$used m³ used of $theoretical m³ theoretical after this truck. The usual cause is a truck shared with another hole — enter only this pile’s share if so.';
  }

  @override
  String get overuseAfterTitle => 'Concrete far above theory';

  @override
  String overuseAfterBody(int seq, String percent) {
    return 'Up to truck #$seq, $percent% more concrete than theory. Before recording this as a wider hole, check: was any truck shared with another pile?';
  }

  @override
  String get fixTruckVolume => 'Fix the truck volume';

  @override
  String get holeReallyWider => 'The hole really is wider';

  @override
  String get later => 'Later';

  @override
  String widerHoleNote(int seq, String percent) {
    return 'Truck #$seq: concrete $percent% above theory — hole is wider (checked on site).';
  }

  @override
  String get pullNowTitle => 'Pull the tremie now?';

  @override
  String pullNowBody(int seq, String emb, String which, String after) {
    return 'Truck #$seq is finished, embedment $emb. Pull $which to bring it to $after.';
  }

  @override
  String get pulledAlready => 'Already pulled';

  @override
  String get notYetPull => 'Not pulled yet';

  @override
  String get overbreakCheckedTag => '[overbreak diperiksa]';

  @override
  String get excelOptionsTitle => 'Download Excel';

  @override
  String get excelPeriodLabel => 'Range';

  @override
  String get excelSheetsLabel => 'Sheets to include';

  @override
  String get sheetPiles => 'Pile recap';

  @override
  String get sheetPilesBody => 'One row per point: depth, volume, dates.';

  @override
  String get sheetConcrete => 'Concrete grade';

  @override
  String get sheetConcreteBody =>
      'Only points already cast, with their compressive strength.';

  @override
  String get sheetOperators => 'Operator recap';

  @override
  String get sheetOperatorsBody =>
      'Actual vs design metres per operator, plus one sheet per operator.';

  @override
  String get pickAtLeastOneSheet => 'Pick at least one sheet.';

  @override
  String get download => 'Download';

  @override
  String get retakePhoto => 'Retake';

  @override
  String get tapToEnlarge => 'Tap to enlarge';

  @override
  String get photoNotOnThisPhone => 'Photo not on this phone';

  @override
  String get correct => 'Correct';

  @override
  String get backOut => 'Back out';

  @override
  String get gsRowLabel => 'Ground level (GS)';

  @override
  String plannedDrillOf(String depth) {
    return 'Planned drill length $depth';
  }

  @override
  String confirmBeforeDrilling(String code) {
    return 'Confirm before drilling $code';
  }

  @override
  String get confirmBeforeDrillingBody =>
      'Enter the corrected GS for this point. The planned drill length is worked out from it, so it has to be right before the bit goes down.';

  @override
  String get correctGsTitle => 'Correct GS';

  @override
  String get correctGsBody =>
      'Surveyor revised the shot? Change GS here; the planned drill length and cut-off depth are recomputed with it.';

  @override
  String codeHeldBy(String name) {
    return 'The code is on $name’s phone';
  }

  @override
  String codeHeldByBody(String name) {
    return 'Ask $name to open this point on their phone and tap \"Hand over to a mate\". A 6-digit code appears on their screen to read out. No request is sent automatically.';
  }

  @override
  String get askHolder => 'Ask the holder';

  @override
  String get sendingRequest => 'Sending request…';

  @override
  String get requestSentTitle => 'Request sent';

  @override
  String requestSentBody(String name) {
    return '$name gets a notification on their phone. Once they agree, this log moves to your phone — no code needed.';
  }

  @override
  String get handingOver => 'Handing the log over…';

  @override
  String get rejectingRequest => 'Rejecting the request…';

  @override
  String logHandedTo(String code, String name) {
    return 'Log $code is now with $name.';
  }

  @override
  String requestRejected(String name) {
    return '$name’s request was rejected.';
  }

  @override
  String handoverRequestTitle(String name) {
    return '$name asks for the log';
  }

  @override
  String handoverRequestBody(String code) {
    return 'Point $code — open to approve or reject.';
  }

  @override
  String handoverRequestPrompt(String name, String code) {
    return '$name is at point $code waiting for an answer. Approving moves this log to their phone right away, and closes this screen.';
  }

  @override
  String get approve => 'Approve';

  @override
  String get reject => 'Reject';

  @override
  String get drillProgressLabel => 'Drilling progress';

  @override
  String get castProgressLabel => 'Casting progress';

  @override
  String drillProgressMain(String depth, String planned) {
    return '$depth of $planned planned';
  }

  @override
  String castProgressMain(String n, String vol, String theoretical) {
    return 'TM #$n · $vol m³ of $theoretical m³ theoretical';
  }

  @override
  String get progressNothingYet => 'Nothing recorded yet';

  @override
  String get logGoneResynced =>
      'The log no longer exists on the server — it was probably deleted from the office. This point has just been re-pulled; open it again.';

  @override
  String get progressNoSync =>
      'The log is open; the first record has not arrived';

  @override
  String progressLastAt(String time, String age) {
    return 'Last record $time · $age';
  }

  @override
  String get progressAsSent =>
      'As far as the holder’s phone has sent. If it is out of signal, the real state may be further along.';

  @override
  String get refresh => 'Refresh';

  @override
  String get pointHistoryOpen => 'View point history';

  @override
  String pointHistoryTitle(String code) {
    return 'History of $code';
  }

  @override
  String get pointHistoryErrorTitle => 'History cannot be opened';

  @override
  String get pointHistoryErrorBody =>
      'This screen reads straight from the server, so it needs a connection. Pull down to try again.';

  @override
  String get pointHistoryNoCasting =>
      'No casting log on the server for this point yet.';

  @override
  String get pointHistoryTrail => 'Correction trail';

  @override
  String get deletedLabel => 'Deleted';

  @override
  String get fromOffice => 'From office';

  @override
  String trucksCount(int n) {
    return '$n trucks';
  }

  @override
  String get volumeUsed => 'Volume used';

  @override
  String get volumeTheoretical => 'Theoretical volume';

  @override
  String get overusePercent => 'Overuse';

  @override
  String get castStartEnd => 'Casting start – end';

  @override
  String get drillLogNotClosed => 'Log still open';

  @override
  String get embedBeforeLabel => 'Embedment before';

  @override
  String get embedAfterLabel => 'Embedment after';

  @override
  String tremieSummary(int n, String total, String gap) {
    return '$n sections · $total m · bottom end $gap above the hole bottom';
  }

  @override
  String get tremieStillFitted => 'still fitted';

  @override
  String tremiePulledAfter(int seq) {
    return 'pulled after truck $seq';
  }

  @override
  String get pointConfirmedTitle => 'Point confirmed';

  @override
  String pointConfirmedBody(String who, String when) {
    return 'Confirmed by $who, $when. The drilling and casting data of this point can no longer be changed until the confirmation is reopened from the office.';
  }

  @override
  String get reasonTitikDikonfirmasi =>
      'This point has been confirmed by the office — ask them to reopen the confirmation first';

  @override
  String get drillSection => 'Drilling';

  @override
  String get castSection => 'Casting';

  @override
  String get deepestLabel => 'Deepest';

  @override
  String get drillDurationLabel => 'Drilling time';

  @override
  String get avgRateLabel => 'Average rate';

  @override
  String get slowestSegmentLabel => 'Slowest segment';

  @override
  String metresPerHour(String v) {
    return '$v m/h';
  }

  @override
  String get drillEffectiveLabel => 'Drilling time';

  @override
  String drillOfTotal(String total) {
    return 'of $total total';
  }

  @override
  String get drillEffectiveRateLabel => 'Drilling rate';

  @override
  String drillRateTotal(String laju) {
    return '$laju m/h including stops';
  }

  @override
  String drillStops(String n, String lama) {
    return '$n stops · $lama';
  }

  @override
  String get denahTitle => 'Point layout';

  @override
  String get denahLabelToggle => 'Point codes';

  @override
  String get denahRotate => 'Rotate 90°';

  @override
  String get denahFit => 'Fit to screen';

  @override
  String get denahDeviationToggle => 'Deviation lines';

  @override
  String get denahDrilled => 'Drilled';

  @override
  String denahNoCoordTitle(String n) {
    return '$n points are not drawn';
  }

  @override
  String get denahNoCoordBody =>
      'These points have no X/Y coordinates — neither design nor as-built — so there is nowhere to draw them. The office fills them in through the Excel import.';

  @override
  String get denahEmptyTitle => 'No coordinates yet';

  @override
  String get denahEmptyBody =>
      'Not one point in this project has X/Y coordinates, so the layout cannot be drawn yet. The office fills the design coordinates in from the office.';

  @override
  String drillPlanRef(String v) {
    return '$v planned';
  }

  @override
  String deviationStopTitle(String v) {
    return 'Deviation $v is beyond tolerance';
  }

  @override
  String deviationStopBody(String batas, String lewat) {
    return 'The project tolerance is $batas; this point is $lewat beyond it. Check the measurement and the design coordinates before the hole is poured — once it is, the only remaining option is strengthening, and that is not a decision made from the phone.';
  }

  @override
  String get deviationStopSave => 'Save as is';

  @override
  String get deviationStopRecheck => 'Check again';

  @override
  String get filterDrilling => 'Being drilled';

  @override
  String get filterCasting => 'Being poured';

  @override
  String progressIdle(String jam, String lama) {
    return 'Stopped since $jam · $lama with no new reading';
  }

  @override
  String readingTableTitle(String n) {
    return 'Readings ($n)';
  }

  @override
  String get readingColTime => 'Time';

  @override
  String get readingColDepth => 'Depth';

  @override
  String get readingColAdded => 'Added';

  @override
  String get readingColRate => 'Rate';

  @override
  String get readingNotPlotted =>
      'Not on the curve — its time or depth cannot be read.';

  @override
  String get activityTitle => 'Field activity';

  @override
  String get activityToday => 'Today · tap to pick a date';

  @override
  String get activityPick => 'Tap to pick a date';

  @override
  String get activityPrevDay => 'Previous day';

  @override
  String get activityNextDay => 'Next day';

  @override
  String get activityEmptyTitle => 'Nothing was recorded on this day';

  @override
  String get activityEmptyBody =>
      'No drilling or pouring was logged. Pick another day with the arrows above.';

  @override
  String get activityDrilled => 'points drilled';

  @override
  String get activityPoured => 'points poured';

  @override
  String get activityAllProjects => 'All projects';

  @override
  String get activityNoProject => 'No project';

  @override
  String get activitySeeAll => 'See all';

  @override
  String get curveNeedsTwo =>
      'The curve needs at least two readings whose time and depth can be read.';

  @override
  String get readingUnreadable =>
      'This reading\'s time or depth cannot be read - correct it from the office.';

  @override
  String trailCount(int n) {
    return '$n changes';
  }

  @override
  String get pourStartTitle => 'Before the first truck';

  @override
  String get stickOutQuestion =>
      'How many metres of tremie pipe stick out above the ground?';

  @override
  String get stickOutField => 'Sticking out above ground';

  @override
  String stickOutBasis(String panjang) {
    return 'Pipe already built: $panjang.';
  }

  @override
  String stickOutResult(String dalam, String celah) {
    return 'So the tremie bottom sits at $dalam, which is $celah above the hole bottom.';
  }

  @override
  String get stickOutRequired =>
      'Fill in how many metres are sticking out first.';

  @override
  String stickOutTooHigh(String celah) {
    return 'That puts the tremie bottom $celah above the hole bottom. Too high — check again.';
  }

  @override
  String get stickOutTooDeep =>
      'That puts the tremie bottom deeper than the hole bottom. Check again.';

  @override
  String get gradeQuestion => 'What is the concrete grade today?';

  @override
  String get nextStep => 'Next';

  @override
  String get backStep => 'Back';

  @override
  String get ratioOddTitle => 'Sounding does not match the concrete volume';

  @override
  String ratioOddBody(String ini, String pola) {
    return 'This truck comes out at $ini, while the earlier trucks were $pola. The hole was finished before any concrete went in, so its shape does not change mid-pour — most often the sounding was misread.';
  }

  @override
  String ratioOddAlone(String ini) {
    return 'This truck comes out at $ini, with no earlier truck to compare against. The usual range is −20% to +100%; outside it the sounding is usually misread.';
  }

  @override
  String get remeasure => 'Measure again';

  @override
  String get saveAnyway => 'Save anyway';

  @override
  String get qTruckNo => 'What is the truck\'s hull number?';

  @override
  String get qVolume => 'How many cubic metres in this truck?';

  @override
  String get qSupplier => 'Which supplier is the concrete from?';

  @override
  String get qSlump => 'What was the tested slump?';

  @override
  String get qPhoto => 'Photo of the delivery note';

  @override
  String supplierSameAsBefore(String nama) {
    return 'Still $nama, same as the previous truck.';
  }

  @override
  String get changeIt => 'Change';

  @override
  String get lengkapiTitle => 'A few things first';

  @override
  String get lengkapiBody =>
      'The casting log cannot be closed yet. Fill in what is missing below, then carry on.';

  @override
  String get qSoundingAwal =>
      'Before the first truck was poured, how many metres from the ground to the concrete?';

  @override
  String get tremieDepthField => 'Tremie bottom depth from GS';

  @override
  String tremieDepthHint(String dasar) {
    return 'Measured once the tremie is assembled, before the first truck. Hole bottom $dasar; the gap is computed from this.';
  }

  @override
  String get tremieDepthRequired => 'Fill in the tremie bottom depth first.';

  @override
  String tremieDepthInvalid(String dasar) {
    return 'The tremie bottom must sit between the hole bottom ($dasar) and 5 m above it.';
  }

  @override
  String get soundingBeforeNeeded =>
      'The before-sounding of truck #1 is missing - without it there is never an embedment-before.';

  @override
  String get reasonSoundingAwalKosong =>
      'The before-sounding of the first truck is missing';

  @override
  String get reasonTremieDalamSalah =>
      'The tremie bottom depth does not make sense against the hole bottom';

  @override
  String get actualX => 'Actual X';

  @override
  String get actualY => 'Actual Y';

  @override
  String get actualXRequired => 'Actual X — required';

  @override
  String get actualYRequired => 'Actual Y — required';

  @override
  String get actualXYRequiredMsg =>
      'Enter the actual X and Y of the hole centre. Measured once drilling is finished.';

  @override
  String get actualXYBothMsg => 'X and Y must both be filled in.';

  @override
  String get actualXYInvalid => 'The coordinates are not valid.';

  @override
  String get designXYTitle => 'Design coordinates';

  @override
  String designXYBody(String x, String y) {
    return 'X $x · Y $y';
  }

  @override
  String deviationBody(String simpangan, String toleransi) {
    return 'Deviation $simpangan, tolerance $toleransi.';
  }

  @override
  String deviationOverTitle(String simpangan) {
    return 'Deviation $simpangan is over tolerance';
  }

  @override
  String deviationOverBody(String toleransi) {
    return 'This project\'s tolerance is $toleransi. Check the figures before saving — if they are right, report it to the office.';
  }

  @override
  String get castDoneTitle => 'Casting finished';

  @override
  String get castDoneVolume => 'Concrete delivered';

  @override
  String get castDonePlanned => 'Theoretical plan';

  @override
  String castDoneVsPlanned(String rencana, String selisih) {
    return '$rencana m³ ($selisih%)';
  }

  @override
  String get castDoneTrucks => 'Trucks';

  @override
  String get castDoneTopDepth => 'Last recorded concrete level';

  @override
  String get castDoneHoleDepth => 'Hole depth';

  @override
  String get castDoneAt => 'Finished at';

  @override
  String get finishTruckAction => 'Finish truck';

  @override
  String notifSoundingDue(String seq) {
    return 'Truck $seq finished — sounding not entered';
  }

  @override
  String get notifSoundingDueBody =>
      'Open the casting log on the phone and enter the concrete sounding after the pour. Tremie embedment and the volume checks are computed from that figure.';

  @override
  String get drillLockedConfirmedTitle => 'Checked by the office — locked';

  @override
  String get drillLockedConfirmedBody =>
      'This point has been checked and approved, so its drill log can no longer be changed. If a figure is wrong, ask the office to undo the check first.';

  @override
  String get drillLockedCastTitle => 'Already cast — locked';

  @override
  String get drillLockedCastBody =>
      'Concrete has gone in, so the drill log is closed for good. Nothing on this screen can be changed any more.';

  @override
  String get drillNeedGsTitle => 'Fill in the ground level first';

  @override
  String get drillNeedGsBody =>
      'Every depth is measured down from the ground level, so nothing can be recorded until it is set. Tap the ground level row above to fill it in.';

  @override
  String get blockedNeedGs =>
      'Fill in the ground level first — tap the row above.';

  @override
  String get blockedConfirmed =>
      'Checked by the office; this log can no longer be changed.';

  @override
  String get blockedCast => 'Already cast; the drill log is closed for good.';

  @override
  String get blockedNeedTremie =>
      'Set up the tremie string first, then add the truck.';

  @override
  String get tremieDepthFirst => 'Measure the tremie first';

  @override
  String get blockedNeedTremieDepth =>
      'Measure the tremie bottom depth first. Once concrete goes in, it can no longer be measured.';

  @override
  String get drillReopenConfirmTitle => 'Open this drill log again?';

  @override
  String get drillReopenConfirmBody =>
      'The log is closed now. Opening it again lets depths be added and changed, and the office will see that it was reopened. Only do this if a figure really is wrong.';

  @override
  String get castReopenConfirmTitle => 'Open this casting log again?';

  @override
  String get castReopenConfirmBody =>
      'The log is closed now. Opening it again lets trucks and volumes be added and changed, and the office will see that it was reopened. Only do this if a figure really is wrong.';

  @override
  String get supplierLocal => 'Local (site-mix, batched on site)';

  @override
  String get supplierMustBePicked =>
      'Pick a supplier from the list. If the supplier is not on it, ask the office to add it — do not type a name.';

  @override
  String get supplierMissingTitle => 'Supplier not on the list?';

  @override
  String get supplierMissingBody =>
      'Do not type one. Ask the office to mark the supplier \"Pemasok beton\" and issue this project\'s PO — a typed name never reaches the supplier recap and never matches the delivery notes.';

  @override
  String get supplierTypedBefore =>
      'This name was typed by hand on an older build — pick the right supplier from the list';

  @override
  String get supplierLocalConfirmTitle => 'Use local (site-mix) concrete?';

  @override
  String get supplierLocalConfirmBody =>
      'That means the concrete is batched on site, not delivered by a plant — so this log will have no supplier and will not match any delivery note. If the concrete arrives by truck, pick the supplier from the list.';

  @override
  String get supplierLocalConfirmYes => 'Yes, site-mix';

  @override
  String get watchOpen => 'Watch live';

  @override
  String watchTitle(String code) {
    return 'Watching $code';
  }

  @override
  String watchAsOf(String jam, int menit) {
    return 'as of $jam · $menit min ago';
  }

  @override
  String get watchNoTimestamp =>
      'No time-stamped record from the holder\'s phone yet';

  @override
  String get watchOfflineTitle => 'Cannot fetch';

  @override
  String get watchOfflineBody =>
      'Watching reads straight from the server, so it needs signal. Pull down to try again.';

  @override
  String get watchNothingTitle => 'Nothing started on this point yet';

  @override
  String get watchNothingBody =>
      'As soon as the holder\'s phone sends a first reading or truck, the progress shows up here.';

  @override
  String get watchCastRunning => 'Pouring';

  @override
  String get watchCastDone => 'Pour finished';

  @override
  String watchPouringNow(String seq) {
    return 'Truck $seq pouring';
  }

  @override
  String get watchTrucks => 'Trucks in';

  @override
  String get watchVolume => 'Volume';

  @override
  String get watchConcreteLevel => 'Concrete level from GS';

  @override
  String get watchNotSounded => 'not sounded yet';

  @override
  String get watchEmbedment => 'Tremie embedment';

  @override
  String get watchDrillRunning => 'Drilling';

  @override
  String get watchDrillDone => 'Drilling finished';

  @override
  String get watchCurveWaitTitle => 'The curve needs two readings';

  @override
  String get watchCurveWaitBody =>
      'One reading spans no time at all. It appears by itself once the second reading arrives.';

  @override
  String get watchDepth => 'Depth';

  @override
  String get watchRate => 'Average rate';

  @override
  String get watchReadings => 'Readings';

  @override
  String truckTableTitle(String n) {
    return 'Mixer trucks ($n)';
  }

  @override
  String get truckColSeq => 'TM';

  @override
  String get truckColPour => 'Pour';

  @override
  String get truckColVolume => 'Volume';

  @override
  String get truckColCumulative => 'Cumulative';

  @override
  String truckArrivedAt(String jam) {
    return 'arrived $jam';
  }

  @override
  String get photoExpired =>
      'This photo is past its retention period on the server.';

  @override
  String get photoFailed =>
      'The photo could not be loaded. Check your signal, then try again.';

  @override
  String get truckShare => 'Share';

  @override
  String get shareNoPhoto =>
      'The delivery ticket photo could not be fetched — sharing the text only.';

  @override
  String get sheetSupplier => 'Concrete by supplier';

  @override
  String get sheetSupplierBody =>
      'One sheet per supplier: trucks, delivery tickets, volume, and totals.';

  @override
  String get loginLockedTitle => 'Locked for now';

  @override
  String loginLockedBody(String sisa) {
    return 'Too many sign-in attempts. The Sign in button comes back in $sisa. Pressing it now does not extend the lock, but it does not shorten it either.';
  }

  @override
  String loginLockedButton(String sisa) {
    return 'Wait $sisa';
  }

  @override
  String get koordinatKomaJudul => 'Is the decimal mark missing?';

  @override
  String koordinatKomaIsi(String nama, int diketik, int rencana, int maks) {
    return 'Actual $nama has $diketik digits before the decimal mark, while this point’s design coordinate has $rencana. The field stops accepting digits at $maks — it is full, not broken. Type the mark after $rencana digits, then the decimals.';
  }

  @override
  String get koordinatKosongkan => 'Clear this field';

  @override
  String get swipeToFinishDrilling => 'Swipe to finish drilling';

  @override
  String get swipeToFinishCasting => 'Swipe to finish casting';

  @override
  String get swipeDone => 'Saved';

  @override
  String get entityGateTicket => 'Gate record';

  @override
  String get gateRecordTruck => 'Gate: record a truck';

  @override
  String gateTitle(String code) {
    return 'Truck at gate · $code';
  }

  @override
  String get gateIntroTitle => 'Type it exactly as painted on the truck';

  @override
  String get gateIntroBody =>
      'This number is what pairs the gate record with the truck poured at the hole.';

  @override
  String get gateVolume => 'Volume on delivery note';

  @override
  String get gateGrade => 'Concrete grade (fc\')';

  @override
  String get gateGradeInvalid => 'Concrete grade is out of range (1–150 MPa).';

  @override
  String get gateRejected => 'This truck is rejected at the gate';

  @override
  String get gateRejectedTitle => 'A rejected truck is not poured';

  @override
  String get gateRejectedBody =>
      'The record is kept as evidence, but its volume does not enter this point\'s casting log.';

  @override
  String get gateRejectReason => 'Reason for rejection';

  @override
  String get gateRejectReasonRequired => 'Enter why this truck is rejected.';

  @override
  String get gateTruckRequired => 'Enter the truck number.';

  @override
  String get gatePhotoRequired => 'Take the delivery note photo first.';

  @override
  String gateSaved(String truck) {
    return 'Truck $truck recorded. Sent automatically when there is signal.';
  }

  @override
  String get startPourOnlyLog => 'Start casting log — at the hole only';

  @override
  String get pourTruckNoTitle => 'The truck number is the key';

  @override
  String get pourTruckNoBody =>
      'Pick a truck number already recorded at the gate, or type it exactly as painted on the truck. Its volume, slump and delivery note attach from the gate record through this number.';

  @override
  String get pourTruckNoBodyEmpty =>
      'Gate records for this point have not reached this phone yet. Type the truck number exactly as painted on the truck; its volume, slump and delivery note attach from the gate record through this number.';

  @override
  String get gateQGrade => 'What is the concrete grade?';

  @override
  String get gateQSummary => 'Is everything correct?';

  @override
  String get gateRejectAction => 'Reject this truck';

  @override
  String gateOtherPileTitle(String truck) {
    return 'Does truck $truck also pour into another hole?';
  }

  @override
  String get gateOtherPileBody =>
      'If one truck is split between two holes, record it on the next hole too. The truck number, delivery note photo, slump and grade are copied — only the volume is left to fill in.';

  @override
  String get gateOtherPileNo => 'No, done';

  @override
  String get gateOtherPilePick => 'Yes — tap the next hole:';

  @override
  String get gateOtherPileSearch => 'Search pile code';

  @override
  String gateCopiedTitle(String truck) {
    return 'Truck $truck continues to this point';
  }

  @override
  String get gateCopiedBody =>
      'Enter only the volume poured AT THIS POINT, not the whole truck load.';
}
