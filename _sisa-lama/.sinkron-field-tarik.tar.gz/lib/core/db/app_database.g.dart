// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'app_database.dart';

// ignore_for_file: type=lint
class $MasterRecordsTable extends MasterRecords
    with TableInfo<$MasterRecordsTable, MasterRecord> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $MasterRecordsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _entityMeta = const VerificationMeta('entity');
  @override
  late final GeneratedColumn<String> entity = GeneratedColumn<String>(
    'entity',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _keyMeta = const VerificationMeta('key');
  @override
  late final GeneratedColumn<String> key = GeneratedColumn<String>(
    'key',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _bodyMeta = const VerificationMeta('body');
  @override
  late final GeneratedColumn<String> body = GeneratedColumn<String>(
    'body',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _deletedMeta = const VerificationMeta(
    'deleted',
  );
  @override
  late final GeneratedColumn<bool> deleted = GeneratedColumn<bool>(
    'deleted',
    aliasedName,
    false,
    type: DriftSqlType.bool,
    requiredDuringInsert: false,
    defaultConstraints: GeneratedColumn.constraintIsAlways(
      'CHECK ("deleted" IN (0, 1))',
    ),
    defaultValue: const Constant(false),
  );
  @override
  List<GeneratedColumn> get $columns => [entity, key, body, deleted];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'master_records';
  @override
  VerificationContext validateIntegrity(
    Insertable<MasterRecord> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('entity')) {
      context.handle(
        _entityMeta,
        entity.isAcceptableOrUnknown(data['entity']!, _entityMeta),
      );
    } else if (isInserting) {
      context.missing(_entityMeta);
    }
    if (data.containsKey('key')) {
      context.handle(
        _keyMeta,
        key.isAcceptableOrUnknown(data['key']!, _keyMeta),
      );
    } else if (isInserting) {
      context.missing(_keyMeta);
    }
    if (data.containsKey('body')) {
      context.handle(
        _bodyMeta,
        body.isAcceptableOrUnknown(data['body']!, _bodyMeta),
      );
    } else if (isInserting) {
      context.missing(_bodyMeta);
    }
    if (data.containsKey('deleted')) {
      context.handle(
        _deletedMeta,
        deleted.isAcceptableOrUnknown(data['deleted']!, _deletedMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {entity, key};
  @override
  MasterRecord map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MasterRecord(
      entity: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}entity'],
      )!,
      key: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}key'],
      )!,
      body: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}body'],
      )!,
      deleted: attachedDatabase.typeMapping.read(
        DriftSqlType.bool,
        data['${effectivePrefix}deleted'],
      )!,
    );
  }

  @override
  $MasterRecordsTable createAlias(String alias) {
    return $MasterRecordsTable(attachedDatabase, alias);
  }
}

class MasterRecord extends DataClass implements Insertable<MasterRecord> {
  /// project | worker | pile_point
  final String entity;

  /// server id (project) or uuid (worker, pile point).
  final String key;
  final String body;
  final bool deleted;
  const MasterRecord({
    required this.entity,
    required this.key,
    required this.body,
    required this.deleted,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['entity'] = Variable<String>(entity);
    map['key'] = Variable<String>(key);
    map['body'] = Variable<String>(body);
    map['deleted'] = Variable<bool>(deleted);
    return map;
  }

  MasterRecordsCompanion toCompanion(bool nullToAbsent) {
    return MasterRecordsCompanion(
      entity: Value(entity),
      key: Value(key),
      body: Value(body),
      deleted: Value(deleted),
    );
  }

  factory MasterRecord.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MasterRecord(
      entity: serializer.fromJson<String>(json['entity']),
      key: serializer.fromJson<String>(json['key']),
      body: serializer.fromJson<String>(json['body']),
      deleted: serializer.fromJson<bool>(json['deleted']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'entity': serializer.toJson<String>(entity),
      'key': serializer.toJson<String>(key),
      'body': serializer.toJson<String>(body),
      'deleted': serializer.toJson<bool>(deleted),
    };
  }

  MasterRecord copyWith({
    String? entity,
    String? key,
    String? body,
    bool? deleted,
  }) => MasterRecord(
    entity: entity ?? this.entity,
    key: key ?? this.key,
    body: body ?? this.body,
    deleted: deleted ?? this.deleted,
  );
  MasterRecord copyWithCompanion(MasterRecordsCompanion data) {
    return MasterRecord(
      entity: data.entity.present ? data.entity.value : this.entity,
      key: data.key.present ? data.key.value : this.key,
      body: data.body.present ? data.body.value : this.body,
      deleted: data.deleted.present ? data.deleted.value : this.deleted,
    );
  }

  @override
  String toString() {
    return (StringBuffer('MasterRecord(')
          ..write('entity: $entity, ')
          ..write('key: $key, ')
          ..write('body: $body, ')
          ..write('deleted: $deleted')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(entity, key, body, deleted);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MasterRecord &&
          other.entity == this.entity &&
          other.key == this.key &&
          other.body == this.body &&
          other.deleted == this.deleted);
}

class MasterRecordsCompanion extends UpdateCompanion<MasterRecord> {
  final Value<String> entity;
  final Value<String> key;
  final Value<String> body;
  final Value<bool> deleted;
  final Value<int> rowid;
  const MasterRecordsCompanion({
    this.entity = const Value.absent(),
    this.key = const Value.absent(),
    this.body = const Value.absent(),
    this.deleted = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  MasterRecordsCompanion.insert({
    required String entity,
    required String key,
    required String body,
    this.deleted = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : entity = Value(entity),
       key = Value(key),
       body = Value(body);
  static Insertable<MasterRecord> custom({
    Expression<String>? entity,
    Expression<String>? key,
    Expression<String>? body,
    Expression<bool>? deleted,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (entity != null) 'entity': entity,
      if (key != null) 'key': key,
      if (body != null) 'body': body,
      if (deleted != null) 'deleted': deleted,
      if (rowid != null) 'rowid': rowid,
    });
  }

  MasterRecordsCompanion copyWith({
    Value<String>? entity,
    Value<String>? key,
    Value<String>? body,
    Value<bool>? deleted,
    Value<int>? rowid,
  }) {
    return MasterRecordsCompanion(
      entity: entity ?? this.entity,
      key: key ?? this.key,
      body: body ?? this.body,
      deleted: deleted ?? this.deleted,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (entity.present) {
      map['entity'] = Variable<String>(entity.value);
    }
    if (key.present) {
      map['key'] = Variable<String>(key.value);
    }
    if (body.present) {
      map['body'] = Variable<String>(body.value);
    }
    if (deleted.present) {
      map['deleted'] = Variable<bool>(deleted.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('MasterRecordsCompanion(')
          ..write('entity: $entity, ')
          ..write('key: $key, ')
          ..write('body: $body, ')
          ..write('deleted: $deleted, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $DocumentsTable extends Documents
    with TableInfo<$DocumentsTable, DocumentRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $DocumentsTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _uuidMeta = const VerificationMeta('uuid');
  @override
  late final GeneratedColumn<String> uuid = GeneratedColumn<String>(
    'uuid',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _entityMeta = const VerificationMeta('entity');
  @override
  late final GeneratedColumn<String> entity = GeneratedColumn<String>(
    'entity',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<int> userId = GeneratedColumn<int>(
    'user_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _versionMeta = const VerificationMeta(
    'version',
  );
  @override
  late final GeneratedColumn<int> version = GeneratedColumn<int>(
    'version',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(1),
  );
  static const VerificationMeta _syncedVersionMeta = const VerificationMeta(
    'syncedVersion',
  );
  @override
  late final GeneratedColumn<int> syncedVersion = GeneratedColumn<int>(
    'synced_version',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _bodyMeta = const VerificationMeta('body');
  @override
  late final GeneratedColumn<String> body = GeneratedColumn<String>(
    'body',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _sendStatusMeta = const VerificationMeta(
    'sendStatus',
  );
  @override
  late final GeneratedColumn<String> sendStatus = GeneratedColumn<String>(
    'send_status',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
    defaultValue: const Constant('pending'),
  );
  static const VerificationMeta _reasonMeta = const VerificationMeta('reason');
  @override
  late final GeneratedColumn<String> reason = GeneratedColumn<String>(
    'reason',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _detailMeta = const VerificationMeta('detail');
  @override
  late final GeneratedColumn<String> detail = GeneratedColumn<String>(
    'detail',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _flagsMeta = const VerificationMeta('flags');
  @override
  late final GeneratedColumn<String> flags = GeneratedColumn<String>(
    'flags',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _serverIdMeta = const VerificationMeta(
    'serverId',
  );
  @override
  late final GeneratedColumn<int> serverId = GeneratedColumn<int>(
    'server_id',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _serverStatusMeta = const VerificationMeta(
    'serverStatus',
  );
  @override
  late final GeneratedColumn<String> serverStatus = GeneratedColumn<String>(
    'server_status',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _serverNoteMeta = const VerificationMeta(
    'serverNote',
  );
  @override
  late final GeneratedColumn<String> serverNote = GeneratedColumn<String>(
    'server_note',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _attemptsMeta = const VerificationMeta(
    'attempts',
  );
  @override
  late final GeneratedColumn<int> attempts = GeneratedColumn<int>(
    'attempts',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _retryAfterMeta = const VerificationMeta(
    'retryAfter',
  );
  @override
  late final GeneratedColumn<DateTime> retryAfter = GeneratedColumn<DateTime>(
    'retry_after',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _createdAtMeta = const VerificationMeta(
    'createdAt',
  );
  @override
  late final GeneratedColumn<DateTime> createdAt = GeneratedColumn<DateTime>(
    'created_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _updatedAtMeta = const VerificationMeta(
    'updatedAt',
  );
  @override
  late final GeneratedColumn<DateTime> updatedAt = GeneratedColumn<DateTime>(
    'updated_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  @override
  List<GeneratedColumn> get $columns => [
    uuid,
    entity,
    userId,
    version,
    syncedVersion,
    body,
    sendStatus,
    reason,
    detail,
    flags,
    serverId,
    serverStatus,
    serverNote,
    attempts,
    retryAfter,
    createdAt,
    updatedAt,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'documents';
  @override
  VerificationContext validateIntegrity(
    Insertable<DocumentRow> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('uuid')) {
      context.handle(
        _uuidMeta,
        uuid.isAcceptableOrUnknown(data['uuid']!, _uuidMeta),
      );
    } else if (isInserting) {
      context.missing(_uuidMeta);
    }
    if (data.containsKey('entity')) {
      context.handle(
        _entityMeta,
        entity.isAcceptableOrUnknown(data['entity']!, _entityMeta),
      );
    } else if (isInserting) {
      context.missing(_entityMeta);
    }
    if (data.containsKey('user_id')) {
      context.handle(
        _userIdMeta,
        userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta),
      );
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('version')) {
      context.handle(
        _versionMeta,
        version.isAcceptableOrUnknown(data['version']!, _versionMeta),
      );
    }
    if (data.containsKey('synced_version')) {
      context.handle(
        _syncedVersionMeta,
        syncedVersion.isAcceptableOrUnknown(
          data['synced_version']!,
          _syncedVersionMeta,
        ),
      );
    }
    if (data.containsKey('body')) {
      context.handle(
        _bodyMeta,
        body.isAcceptableOrUnknown(data['body']!, _bodyMeta),
      );
    } else if (isInserting) {
      context.missing(_bodyMeta);
    }
    if (data.containsKey('send_status')) {
      context.handle(
        _sendStatusMeta,
        sendStatus.isAcceptableOrUnknown(data['send_status']!, _sendStatusMeta),
      );
    }
    if (data.containsKey('reason')) {
      context.handle(
        _reasonMeta,
        reason.isAcceptableOrUnknown(data['reason']!, _reasonMeta),
      );
    }
    if (data.containsKey('detail')) {
      context.handle(
        _detailMeta,
        detail.isAcceptableOrUnknown(data['detail']!, _detailMeta),
      );
    }
    if (data.containsKey('flags')) {
      context.handle(
        _flagsMeta,
        flags.isAcceptableOrUnknown(data['flags']!, _flagsMeta),
      );
    }
    if (data.containsKey('server_id')) {
      context.handle(
        _serverIdMeta,
        serverId.isAcceptableOrUnknown(data['server_id']!, _serverIdMeta),
      );
    }
    if (data.containsKey('server_status')) {
      context.handle(
        _serverStatusMeta,
        serverStatus.isAcceptableOrUnknown(
          data['server_status']!,
          _serverStatusMeta,
        ),
      );
    }
    if (data.containsKey('server_note')) {
      context.handle(
        _serverNoteMeta,
        serverNote.isAcceptableOrUnknown(data['server_note']!, _serverNoteMeta),
      );
    }
    if (data.containsKey('attempts')) {
      context.handle(
        _attemptsMeta,
        attempts.isAcceptableOrUnknown(data['attempts']!, _attemptsMeta),
      );
    }
    if (data.containsKey('retry_after')) {
      context.handle(
        _retryAfterMeta,
        retryAfter.isAcceptableOrUnknown(data['retry_after']!, _retryAfterMeta),
      );
    }
    if (data.containsKey('created_at')) {
      context.handle(
        _createdAtMeta,
        createdAt.isAcceptableOrUnknown(data['created_at']!, _createdAtMeta),
      );
    } else if (isInserting) {
      context.missing(_createdAtMeta);
    }
    if (data.containsKey('updated_at')) {
      context.handle(
        _updatedAtMeta,
        updatedAt.isAcceptableOrUnknown(data['updated_at']!, _updatedAtMeta),
      );
    } else if (isInserting) {
      context.missing(_updatedAtMeta);
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {uuid};
  @override
  DocumentRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return DocumentRow(
      uuid: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uuid'],
      )!,
      entity: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}entity'],
      )!,
      userId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}user_id'],
      )!,
      version: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}version'],
      )!,
      syncedVersion: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}synced_version'],
      )!,
      body: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}body'],
      )!,
      sendStatus: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}send_status'],
      )!,
      reason: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}reason'],
      ),
      detail: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}detail'],
      ),
      flags: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}flags'],
      ),
      serverId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}server_id'],
      ),
      serverStatus: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}server_status'],
      ),
      serverNote: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}server_note'],
      ),
      attempts: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}attempts'],
      )!,
      retryAfter: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}retry_after'],
      ),
      createdAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}created_at'],
      )!,
      updatedAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}updated_at'],
      )!,
    );
  }

  @override
  $DocumentsTable createAlias(String alias) {
    return $DocumentsTable(attachedDatabase, alias);
  }
}

class DocumentRow extends DataClass implements Insertable<DocumentRow> {
  final String uuid;

  /// worker | attendance | drill_mark | casting — same as the server.
  final String entity;

  /// The queue is bound to the USER. If someone else logs in on the same phone,
  /// the previous user's documents are not sent on their behalf.
  final int userId;
  final int version;
  final int syncedVersion;
  final String body;

  /// pending | sent | deferred | rejected | failed
  final String sendStatus;
  final String? reason;
  final String? detail;

  /// Fraud flags from the server (JSON), for the banner on the phone.
  final String? flags;
  final int? serverId;

  /// Status on the server: dikirim/ditinjau/ditolak (attendance),
  /// berjalan/selesai/diperiksa (casting). Filled in from the pull.
  final String? serverStatus;
  final String? serverNote;
  final int attempts;
  final DateTime? retryAfter;
  final DateTime createdAt;
  final DateTime updatedAt;
  const DocumentRow({
    required this.uuid,
    required this.entity,
    required this.userId,
    required this.version,
    required this.syncedVersion,
    required this.body,
    required this.sendStatus,
    this.reason,
    this.detail,
    this.flags,
    this.serverId,
    this.serverStatus,
    this.serverNote,
    required this.attempts,
    this.retryAfter,
    required this.createdAt,
    required this.updatedAt,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['uuid'] = Variable<String>(uuid);
    map['entity'] = Variable<String>(entity);
    map['user_id'] = Variable<int>(userId);
    map['version'] = Variable<int>(version);
    map['synced_version'] = Variable<int>(syncedVersion);
    map['body'] = Variable<String>(body);
    map['send_status'] = Variable<String>(sendStatus);
    if (!nullToAbsent || reason != null) {
      map['reason'] = Variable<String>(reason);
    }
    if (!nullToAbsent || detail != null) {
      map['detail'] = Variable<String>(detail);
    }
    if (!nullToAbsent || flags != null) {
      map['flags'] = Variable<String>(flags);
    }
    if (!nullToAbsent || serverId != null) {
      map['server_id'] = Variable<int>(serverId);
    }
    if (!nullToAbsent || serverStatus != null) {
      map['server_status'] = Variable<String>(serverStatus);
    }
    if (!nullToAbsent || serverNote != null) {
      map['server_note'] = Variable<String>(serverNote);
    }
    map['attempts'] = Variable<int>(attempts);
    if (!nullToAbsent || retryAfter != null) {
      map['retry_after'] = Variable<DateTime>(retryAfter);
    }
    map['created_at'] = Variable<DateTime>(createdAt);
    map['updated_at'] = Variable<DateTime>(updatedAt);
    return map;
  }

  DocumentsCompanion toCompanion(bool nullToAbsent) {
    return DocumentsCompanion(
      uuid: Value(uuid),
      entity: Value(entity),
      userId: Value(userId),
      version: Value(version),
      syncedVersion: Value(syncedVersion),
      body: Value(body),
      sendStatus: Value(sendStatus),
      reason: reason == null && nullToAbsent
          ? const Value.absent()
          : Value(reason),
      detail: detail == null && nullToAbsent
          ? const Value.absent()
          : Value(detail),
      flags: flags == null && nullToAbsent
          ? const Value.absent()
          : Value(flags),
      serverId: serverId == null && nullToAbsent
          ? const Value.absent()
          : Value(serverId),
      serverStatus: serverStatus == null && nullToAbsent
          ? const Value.absent()
          : Value(serverStatus),
      serverNote: serverNote == null && nullToAbsent
          ? const Value.absent()
          : Value(serverNote),
      attempts: Value(attempts),
      retryAfter: retryAfter == null && nullToAbsent
          ? const Value.absent()
          : Value(retryAfter),
      createdAt: Value(createdAt),
      updatedAt: Value(updatedAt),
    );
  }

  factory DocumentRow.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return DocumentRow(
      uuid: serializer.fromJson<String>(json['uuid']),
      entity: serializer.fromJson<String>(json['entity']),
      userId: serializer.fromJson<int>(json['userId']),
      version: serializer.fromJson<int>(json['version']),
      syncedVersion: serializer.fromJson<int>(json['syncedVersion']),
      body: serializer.fromJson<String>(json['body']),
      sendStatus: serializer.fromJson<String>(json['sendStatus']),
      reason: serializer.fromJson<String?>(json['reason']),
      detail: serializer.fromJson<String?>(json['detail']),
      flags: serializer.fromJson<String?>(json['flags']),
      serverId: serializer.fromJson<int?>(json['serverId']),
      serverStatus: serializer.fromJson<String?>(json['serverStatus']),
      serverNote: serializer.fromJson<String?>(json['serverNote']),
      attempts: serializer.fromJson<int>(json['attempts']),
      retryAfter: serializer.fromJson<DateTime?>(json['retryAfter']),
      createdAt: serializer.fromJson<DateTime>(json['createdAt']),
      updatedAt: serializer.fromJson<DateTime>(json['updatedAt']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'uuid': serializer.toJson<String>(uuid),
      'entity': serializer.toJson<String>(entity),
      'userId': serializer.toJson<int>(userId),
      'version': serializer.toJson<int>(version),
      'syncedVersion': serializer.toJson<int>(syncedVersion),
      'body': serializer.toJson<String>(body),
      'sendStatus': serializer.toJson<String>(sendStatus),
      'reason': serializer.toJson<String?>(reason),
      'detail': serializer.toJson<String?>(detail),
      'flags': serializer.toJson<String?>(flags),
      'serverId': serializer.toJson<int?>(serverId),
      'serverStatus': serializer.toJson<String?>(serverStatus),
      'serverNote': serializer.toJson<String?>(serverNote),
      'attempts': serializer.toJson<int>(attempts),
      'retryAfter': serializer.toJson<DateTime?>(retryAfter),
      'createdAt': serializer.toJson<DateTime>(createdAt),
      'updatedAt': serializer.toJson<DateTime>(updatedAt),
    };
  }

  DocumentRow copyWith({
    String? uuid,
    String? entity,
    int? userId,
    int? version,
    int? syncedVersion,
    String? body,
    String? sendStatus,
    Value<String?> reason = const Value.absent(),
    Value<String?> detail = const Value.absent(),
    Value<String?> flags = const Value.absent(),
    Value<int?> serverId = const Value.absent(),
    Value<String?> serverStatus = const Value.absent(),
    Value<String?> serverNote = const Value.absent(),
    int? attempts,
    Value<DateTime?> retryAfter = const Value.absent(),
    DateTime? createdAt,
    DateTime? updatedAt,
  }) => DocumentRow(
    uuid: uuid ?? this.uuid,
    entity: entity ?? this.entity,
    userId: userId ?? this.userId,
    version: version ?? this.version,
    syncedVersion: syncedVersion ?? this.syncedVersion,
    body: body ?? this.body,
    sendStatus: sendStatus ?? this.sendStatus,
    reason: reason.present ? reason.value : this.reason,
    detail: detail.present ? detail.value : this.detail,
    flags: flags.present ? flags.value : this.flags,
    serverId: serverId.present ? serverId.value : this.serverId,
    serverStatus: serverStatus.present ? serverStatus.value : this.serverStatus,
    serverNote: serverNote.present ? serverNote.value : this.serverNote,
    attempts: attempts ?? this.attempts,
    retryAfter: retryAfter.present ? retryAfter.value : this.retryAfter,
    createdAt: createdAt ?? this.createdAt,
    updatedAt: updatedAt ?? this.updatedAt,
  );
  DocumentRow copyWithCompanion(DocumentsCompanion data) {
    return DocumentRow(
      uuid: data.uuid.present ? data.uuid.value : this.uuid,
      entity: data.entity.present ? data.entity.value : this.entity,
      userId: data.userId.present ? data.userId.value : this.userId,
      version: data.version.present ? data.version.value : this.version,
      syncedVersion: data.syncedVersion.present
          ? data.syncedVersion.value
          : this.syncedVersion,
      body: data.body.present ? data.body.value : this.body,
      sendStatus: data.sendStatus.present
          ? data.sendStatus.value
          : this.sendStatus,
      reason: data.reason.present ? data.reason.value : this.reason,
      detail: data.detail.present ? data.detail.value : this.detail,
      flags: data.flags.present ? data.flags.value : this.flags,
      serverId: data.serverId.present ? data.serverId.value : this.serverId,
      serverStatus: data.serverStatus.present
          ? data.serverStatus.value
          : this.serverStatus,
      serverNote: data.serverNote.present
          ? data.serverNote.value
          : this.serverNote,
      attempts: data.attempts.present ? data.attempts.value : this.attempts,
      retryAfter: data.retryAfter.present
          ? data.retryAfter.value
          : this.retryAfter,
      createdAt: data.createdAt.present ? data.createdAt.value : this.createdAt,
      updatedAt: data.updatedAt.present ? data.updatedAt.value : this.updatedAt,
    );
  }

  @override
  String toString() {
    return (StringBuffer('DocumentRow(')
          ..write('uuid: $uuid, ')
          ..write('entity: $entity, ')
          ..write('userId: $userId, ')
          ..write('version: $version, ')
          ..write('syncedVersion: $syncedVersion, ')
          ..write('body: $body, ')
          ..write('sendStatus: $sendStatus, ')
          ..write('reason: $reason, ')
          ..write('detail: $detail, ')
          ..write('flags: $flags, ')
          ..write('serverId: $serverId, ')
          ..write('serverStatus: $serverStatus, ')
          ..write('serverNote: $serverNote, ')
          ..write('attempts: $attempts, ')
          ..write('retryAfter: $retryAfter, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    uuid,
    entity,
    userId,
    version,
    syncedVersion,
    body,
    sendStatus,
    reason,
    detail,
    flags,
    serverId,
    serverStatus,
    serverNote,
    attempts,
    retryAfter,
    createdAt,
    updatedAt,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is DocumentRow &&
          other.uuid == this.uuid &&
          other.entity == this.entity &&
          other.userId == this.userId &&
          other.version == this.version &&
          other.syncedVersion == this.syncedVersion &&
          other.body == this.body &&
          other.sendStatus == this.sendStatus &&
          other.reason == this.reason &&
          other.detail == this.detail &&
          other.flags == this.flags &&
          other.serverId == this.serverId &&
          other.serverStatus == this.serverStatus &&
          other.serverNote == this.serverNote &&
          other.attempts == this.attempts &&
          other.retryAfter == this.retryAfter &&
          other.createdAt == this.createdAt &&
          other.updatedAt == this.updatedAt);
}

class DocumentsCompanion extends UpdateCompanion<DocumentRow> {
  final Value<String> uuid;
  final Value<String> entity;
  final Value<int> userId;
  final Value<int> version;
  final Value<int> syncedVersion;
  final Value<String> body;
  final Value<String> sendStatus;
  final Value<String?> reason;
  final Value<String?> detail;
  final Value<String?> flags;
  final Value<int?> serverId;
  final Value<String?> serverStatus;
  final Value<String?> serverNote;
  final Value<int> attempts;
  final Value<DateTime?> retryAfter;
  final Value<DateTime> createdAt;
  final Value<DateTime> updatedAt;
  final Value<int> rowid;
  const DocumentsCompanion({
    this.uuid = const Value.absent(),
    this.entity = const Value.absent(),
    this.userId = const Value.absent(),
    this.version = const Value.absent(),
    this.syncedVersion = const Value.absent(),
    this.body = const Value.absent(),
    this.sendStatus = const Value.absent(),
    this.reason = const Value.absent(),
    this.detail = const Value.absent(),
    this.flags = const Value.absent(),
    this.serverId = const Value.absent(),
    this.serverStatus = const Value.absent(),
    this.serverNote = const Value.absent(),
    this.attempts = const Value.absent(),
    this.retryAfter = const Value.absent(),
    this.createdAt = const Value.absent(),
    this.updatedAt = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  DocumentsCompanion.insert({
    required String uuid,
    required String entity,
    required int userId,
    this.version = const Value.absent(),
    this.syncedVersion = const Value.absent(),
    required String body,
    this.sendStatus = const Value.absent(),
    this.reason = const Value.absent(),
    this.detail = const Value.absent(),
    this.flags = const Value.absent(),
    this.serverId = const Value.absent(),
    this.serverStatus = const Value.absent(),
    this.serverNote = const Value.absent(),
    this.attempts = const Value.absent(),
    this.retryAfter = const Value.absent(),
    required DateTime createdAt,
    required DateTime updatedAt,
    this.rowid = const Value.absent(),
  }) : uuid = Value(uuid),
       entity = Value(entity),
       userId = Value(userId),
       body = Value(body),
       createdAt = Value(createdAt),
       updatedAt = Value(updatedAt);
  static Insertable<DocumentRow> custom({
    Expression<String>? uuid,
    Expression<String>? entity,
    Expression<int>? userId,
    Expression<int>? version,
    Expression<int>? syncedVersion,
    Expression<String>? body,
    Expression<String>? sendStatus,
    Expression<String>? reason,
    Expression<String>? detail,
    Expression<String>? flags,
    Expression<int>? serverId,
    Expression<String>? serverStatus,
    Expression<String>? serverNote,
    Expression<int>? attempts,
    Expression<DateTime>? retryAfter,
    Expression<DateTime>? createdAt,
    Expression<DateTime>? updatedAt,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (uuid != null) 'uuid': uuid,
      if (entity != null) 'entity': entity,
      if (userId != null) 'user_id': userId,
      if (version != null) 'version': version,
      if (syncedVersion != null) 'synced_version': syncedVersion,
      if (body != null) 'body': body,
      if (sendStatus != null) 'send_status': sendStatus,
      if (reason != null) 'reason': reason,
      if (detail != null) 'detail': detail,
      if (flags != null) 'flags': flags,
      if (serverId != null) 'server_id': serverId,
      if (serverStatus != null) 'server_status': serverStatus,
      if (serverNote != null) 'server_note': serverNote,
      if (attempts != null) 'attempts': attempts,
      if (retryAfter != null) 'retry_after': retryAfter,
      if (createdAt != null) 'created_at': createdAt,
      if (updatedAt != null) 'updated_at': updatedAt,
      if (rowid != null) 'rowid': rowid,
    });
  }

  DocumentsCompanion copyWith({
    Value<String>? uuid,
    Value<String>? entity,
    Value<int>? userId,
    Value<int>? version,
    Value<int>? syncedVersion,
    Value<String>? body,
    Value<String>? sendStatus,
    Value<String?>? reason,
    Value<String?>? detail,
    Value<String?>? flags,
    Value<int?>? serverId,
    Value<String?>? serverStatus,
    Value<String?>? serverNote,
    Value<int>? attempts,
    Value<DateTime?>? retryAfter,
    Value<DateTime>? createdAt,
    Value<DateTime>? updatedAt,
    Value<int>? rowid,
  }) {
    return DocumentsCompanion(
      uuid: uuid ?? this.uuid,
      entity: entity ?? this.entity,
      userId: userId ?? this.userId,
      version: version ?? this.version,
      syncedVersion: syncedVersion ?? this.syncedVersion,
      body: body ?? this.body,
      sendStatus: sendStatus ?? this.sendStatus,
      reason: reason ?? this.reason,
      detail: detail ?? this.detail,
      flags: flags ?? this.flags,
      serverId: serverId ?? this.serverId,
      serverStatus: serverStatus ?? this.serverStatus,
      serverNote: serverNote ?? this.serverNote,
      attempts: attempts ?? this.attempts,
      retryAfter: retryAfter ?? this.retryAfter,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (uuid.present) {
      map['uuid'] = Variable<String>(uuid.value);
    }
    if (entity.present) {
      map['entity'] = Variable<String>(entity.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<int>(userId.value);
    }
    if (version.present) {
      map['version'] = Variable<int>(version.value);
    }
    if (syncedVersion.present) {
      map['synced_version'] = Variable<int>(syncedVersion.value);
    }
    if (body.present) {
      map['body'] = Variable<String>(body.value);
    }
    if (sendStatus.present) {
      map['send_status'] = Variable<String>(sendStatus.value);
    }
    if (reason.present) {
      map['reason'] = Variable<String>(reason.value);
    }
    if (detail.present) {
      map['detail'] = Variable<String>(detail.value);
    }
    if (flags.present) {
      map['flags'] = Variable<String>(flags.value);
    }
    if (serverId.present) {
      map['server_id'] = Variable<int>(serverId.value);
    }
    if (serverStatus.present) {
      map['server_status'] = Variable<String>(serverStatus.value);
    }
    if (serverNote.present) {
      map['server_note'] = Variable<String>(serverNote.value);
    }
    if (attempts.present) {
      map['attempts'] = Variable<int>(attempts.value);
    }
    if (retryAfter.present) {
      map['retry_after'] = Variable<DateTime>(retryAfter.value);
    }
    if (createdAt.present) {
      map['created_at'] = Variable<DateTime>(createdAt.value);
    }
    if (updatedAt.present) {
      map['updated_at'] = Variable<DateTime>(updatedAt.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('DocumentsCompanion(')
          ..write('uuid: $uuid, ')
          ..write('entity: $entity, ')
          ..write('userId: $userId, ')
          ..write('version: $version, ')
          ..write('syncedVersion: $syncedVersion, ')
          ..write('body: $body, ')
          ..write('sendStatus: $sendStatus, ')
          ..write('reason: $reason, ')
          ..write('detail: $detail, ')
          ..write('flags: $flags, ')
          ..write('serverId: $serverId, ')
          ..write('serverStatus: $serverStatus, ')
          ..write('serverNote: $serverNote, ')
          ..write('attempts: $attempts, ')
          ..write('retryAfter: $retryAfter, ')
          ..write('createdAt: $createdAt, ')
          ..write('updatedAt: $updatedAt, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $PhotosTable extends Photos with TableInfo<$PhotosTable, PhotoRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $PhotosTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _uuidMeta = const VerificationMeta('uuid');
  @override
  late final GeneratedColumn<String> uuid = GeneratedColumn<String>(
    'uuid',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _kindMeta = const VerificationMeta('kind');
  @override
  late final GeneratedColumn<String> kind = GeneratedColumn<String>(
    'kind',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _pathMeta = const VerificationMeta('path');
  @override
  late final GeneratedColumn<String> path = GeneratedColumn<String>(
    'path',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _sha256Meta = const VerificationMeta('sha256');
  @override
  late final GeneratedColumn<String> sha256 = GeneratedColumn<String>(
    'sha256',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _sizeBytesMeta = const VerificationMeta(
    'sizeBytes',
  );
  @override
  late final GeneratedColumn<int> sizeBytes = GeneratedColumn<int>(
    'size_bytes',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _faceCountMeta = const VerificationMeta(
    'faceCount',
  );
  @override
  late final GeneratedColumn<int> faceCount = GeneratedColumn<int>(
    'face_count',
    aliasedName,
    true,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _takenAtMeta = const VerificationMeta(
    'takenAt',
  );
  @override
  late final GeneratedColumn<DateTime> takenAt = GeneratedColumn<DateTime>(
    'taken_at',
    aliasedName,
    false,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _latMeta = const VerificationMeta('lat');
  @override
  late final GeneratedColumn<double> lat = GeneratedColumn<double>(
    'lat',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _lngMeta = const VerificationMeta('lng');
  @override
  late final GeneratedColumn<double> lng = GeneratedColumn<double>(
    'lng',
    aliasedName,
    true,
    type: DriftSqlType.double,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _userIdMeta = const VerificationMeta('userId');
  @override
  late final GeneratedColumn<int> userId = GeneratedColumn<int>(
    'user_id',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _sendStatusMeta = const VerificationMeta(
    'sendStatus',
  );
  @override
  late final GeneratedColumn<String> sendStatus = GeneratedColumn<String>(
    'send_status',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
    defaultValue: const Constant('pending'),
  );
  static const VerificationMeta _reasonMeta = const VerificationMeta('reason');
  @override
  late final GeneratedColumn<String> reason = GeneratedColumn<String>(
    'reason',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  static const VerificationMeta _attemptsMeta = const VerificationMeta(
    'attempts',
  );
  @override
  late final GeneratedColumn<int> attempts = GeneratedColumn<int>(
    'attempts',
    aliasedName,
    false,
    type: DriftSqlType.int,
    requiredDuringInsert: false,
    defaultValue: const Constant(0),
  );
  static const VerificationMeta _retryAfterMeta = const VerificationMeta(
    'retryAfter',
  );
  @override
  late final GeneratedColumn<DateTime> retryAfter = GeneratedColumn<DateTime>(
    'retry_after',
    aliasedName,
    true,
    type: DriftSqlType.dateTime,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [
    uuid,
    kind,
    path,
    sha256,
    sizeBytes,
    faceCount,
    takenAt,
    lat,
    lng,
    userId,
    sendStatus,
    reason,
    attempts,
    retryAfter,
  ];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'photos';
  @override
  VerificationContext validateIntegrity(
    Insertable<PhotoRow> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('uuid')) {
      context.handle(
        _uuidMeta,
        uuid.isAcceptableOrUnknown(data['uuid']!, _uuidMeta),
      );
    } else if (isInserting) {
      context.missing(_uuidMeta);
    }
    if (data.containsKey('kind')) {
      context.handle(
        _kindMeta,
        kind.isAcceptableOrUnknown(data['kind']!, _kindMeta),
      );
    } else if (isInserting) {
      context.missing(_kindMeta);
    }
    if (data.containsKey('path')) {
      context.handle(
        _pathMeta,
        path.isAcceptableOrUnknown(data['path']!, _pathMeta),
      );
    } else if (isInserting) {
      context.missing(_pathMeta);
    }
    if (data.containsKey('sha256')) {
      context.handle(
        _sha256Meta,
        sha256.isAcceptableOrUnknown(data['sha256']!, _sha256Meta),
      );
    } else if (isInserting) {
      context.missing(_sha256Meta);
    }
    if (data.containsKey('size_bytes')) {
      context.handle(
        _sizeBytesMeta,
        sizeBytes.isAcceptableOrUnknown(data['size_bytes']!, _sizeBytesMeta),
      );
    } else if (isInserting) {
      context.missing(_sizeBytesMeta);
    }
    if (data.containsKey('face_count')) {
      context.handle(
        _faceCountMeta,
        faceCount.isAcceptableOrUnknown(data['face_count']!, _faceCountMeta),
      );
    }
    if (data.containsKey('taken_at')) {
      context.handle(
        _takenAtMeta,
        takenAt.isAcceptableOrUnknown(data['taken_at']!, _takenAtMeta),
      );
    } else if (isInserting) {
      context.missing(_takenAtMeta);
    }
    if (data.containsKey('lat')) {
      context.handle(
        _latMeta,
        lat.isAcceptableOrUnknown(data['lat']!, _latMeta),
      );
    }
    if (data.containsKey('lng')) {
      context.handle(
        _lngMeta,
        lng.isAcceptableOrUnknown(data['lng']!, _lngMeta),
      );
    }
    if (data.containsKey('user_id')) {
      context.handle(
        _userIdMeta,
        userId.isAcceptableOrUnknown(data['user_id']!, _userIdMeta),
      );
    } else if (isInserting) {
      context.missing(_userIdMeta);
    }
    if (data.containsKey('send_status')) {
      context.handle(
        _sendStatusMeta,
        sendStatus.isAcceptableOrUnknown(data['send_status']!, _sendStatusMeta),
      );
    }
    if (data.containsKey('reason')) {
      context.handle(
        _reasonMeta,
        reason.isAcceptableOrUnknown(data['reason']!, _reasonMeta),
      );
    }
    if (data.containsKey('attempts')) {
      context.handle(
        _attemptsMeta,
        attempts.isAcceptableOrUnknown(data['attempts']!, _attemptsMeta),
      );
    }
    if (data.containsKey('retry_after')) {
      context.handle(
        _retryAfterMeta,
        retryAfter.isAcceptableOrUnknown(data['retry_after']!, _retryAfterMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {uuid};
  @override
  PhotoRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return PhotoRow(
      uuid: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}uuid'],
      )!,
      kind: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}kind'],
      )!,
      path: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}path'],
      )!,
      sha256: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}sha256'],
      )!,
      sizeBytes: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}size_bytes'],
      )!,
      faceCount: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}face_count'],
      ),
      takenAt: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}taken_at'],
      )!,
      lat: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}lat'],
      ),
      lng: attachedDatabase.typeMapping.read(
        DriftSqlType.double,
        data['${effectivePrefix}lng'],
      ),
      userId: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}user_id'],
      )!,
      sendStatus: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}send_status'],
      )!,
      reason: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}reason'],
      ),
      attempts: attachedDatabase.typeMapping.read(
        DriftSqlType.int,
        data['${effectivePrefix}attempts'],
      )!,
      retryAfter: attachedDatabase.typeMapping.read(
        DriftSqlType.dateTime,
        data['${effectivePrefix}retry_after'],
      ),
    );
  }

  @override
  $PhotosTable createAlias(String alias) {
    return $PhotosTable(attachedDatabase, alias);
  }
}

class PhotoRow extends DataClass implements Insertable<PhotoRow> {
  final String uuid;

  /// wajah | absen_masuk | absen_pulang | tiket_tm | slump_tm
  final String kind;
  final String path;
  final String sha256;
  final int sizeBytes;
  final int? faceCount;
  final DateTime takenAt;
  final double? lat;
  final double? lng;
  final int userId;

  /// pending | sent | rejected | failed (failed is passed in by the sync engine and
  /// stored back as pending with a retry delay)
  final String sendStatus;
  final String? reason;
  final int attempts;
  final DateTime? retryAfter;
  const PhotoRow({
    required this.uuid,
    required this.kind,
    required this.path,
    required this.sha256,
    required this.sizeBytes,
    this.faceCount,
    required this.takenAt,
    this.lat,
    this.lng,
    required this.userId,
    required this.sendStatus,
    this.reason,
    required this.attempts,
    this.retryAfter,
  });
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['uuid'] = Variable<String>(uuid);
    map['kind'] = Variable<String>(kind);
    map['path'] = Variable<String>(path);
    map['sha256'] = Variable<String>(sha256);
    map['size_bytes'] = Variable<int>(sizeBytes);
    if (!nullToAbsent || faceCount != null) {
      map['face_count'] = Variable<int>(faceCount);
    }
    map['taken_at'] = Variable<DateTime>(takenAt);
    if (!nullToAbsent || lat != null) {
      map['lat'] = Variable<double>(lat);
    }
    if (!nullToAbsent || lng != null) {
      map['lng'] = Variable<double>(lng);
    }
    map['user_id'] = Variable<int>(userId);
    map['send_status'] = Variable<String>(sendStatus);
    if (!nullToAbsent || reason != null) {
      map['reason'] = Variable<String>(reason);
    }
    map['attempts'] = Variable<int>(attempts);
    if (!nullToAbsent || retryAfter != null) {
      map['retry_after'] = Variable<DateTime>(retryAfter);
    }
    return map;
  }

  PhotosCompanion toCompanion(bool nullToAbsent) {
    return PhotosCompanion(
      uuid: Value(uuid),
      kind: Value(kind),
      path: Value(path),
      sha256: Value(sha256),
      sizeBytes: Value(sizeBytes),
      faceCount: faceCount == null && nullToAbsent
          ? const Value.absent()
          : Value(faceCount),
      takenAt: Value(takenAt),
      lat: lat == null && nullToAbsent ? const Value.absent() : Value(lat),
      lng: lng == null && nullToAbsent ? const Value.absent() : Value(lng),
      userId: Value(userId),
      sendStatus: Value(sendStatus),
      reason: reason == null && nullToAbsent
          ? const Value.absent()
          : Value(reason),
      attempts: Value(attempts),
      retryAfter: retryAfter == null && nullToAbsent
          ? const Value.absent()
          : Value(retryAfter),
    );
  }

  factory PhotoRow.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return PhotoRow(
      uuid: serializer.fromJson<String>(json['uuid']),
      kind: serializer.fromJson<String>(json['kind']),
      path: serializer.fromJson<String>(json['path']),
      sha256: serializer.fromJson<String>(json['sha256']),
      sizeBytes: serializer.fromJson<int>(json['sizeBytes']),
      faceCount: serializer.fromJson<int?>(json['faceCount']),
      takenAt: serializer.fromJson<DateTime>(json['takenAt']),
      lat: serializer.fromJson<double?>(json['lat']),
      lng: serializer.fromJson<double?>(json['lng']),
      userId: serializer.fromJson<int>(json['userId']),
      sendStatus: serializer.fromJson<String>(json['sendStatus']),
      reason: serializer.fromJson<String?>(json['reason']),
      attempts: serializer.fromJson<int>(json['attempts']),
      retryAfter: serializer.fromJson<DateTime?>(json['retryAfter']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'uuid': serializer.toJson<String>(uuid),
      'kind': serializer.toJson<String>(kind),
      'path': serializer.toJson<String>(path),
      'sha256': serializer.toJson<String>(sha256),
      'sizeBytes': serializer.toJson<int>(sizeBytes),
      'faceCount': serializer.toJson<int?>(faceCount),
      'takenAt': serializer.toJson<DateTime>(takenAt),
      'lat': serializer.toJson<double?>(lat),
      'lng': serializer.toJson<double?>(lng),
      'userId': serializer.toJson<int>(userId),
      'sendStatus': serializer.toJson<String>(sendStatus),
      'reason': serializer.toJson<String?>(reason),
      'attempts': serializer.toJson<int>(attempts),
      'retryAfter': serializer.toJson<DateTime?>(retryAfter),
    };
  }

  PhotoRow copyWith({
    String? uuid,
    String? kind,
    String? path,
    String? sha256,
    int? sizeBytes,
    Value<int?> faceCount = const Value.absent(),
    DateTime? takenAt,
    Value<double?> lat = const Value.absent(),
    Value<double?> lng = const Value.absent(),
    int? userId,
    String? sendStatus,
    Value<String?> reason = const Value.absent(),
    int? attempts,
    Value<DateTime?> retryAfter = const Value.absent(),
  }) => PhotoRow(
    uuid: uuid ?? this.uuid,
    kind: kind ?? this.kind,
    path: path ?? this.path,
    sha256: sha256 ?? this.sha256,
    sizeBytes: sizeBytes ?? this.sizeBytes,
    faceCount: faceCount.present ? faceCount.value : this.faceCount,
    takenAt: takenAt ?? this.takenAt,
    lat: lat.present ? lat.value : this.lat,
    lng: lng.present ? lng.value : this.lng,
    userId: userId ?? this.userId,
    sendStatus: sendStatus ?? this.sendStatus,
    reason: reason.present ? reason.value : this.reason,
    attempts: attempts ?? this.attempts,
    retryAfter: retryAfter.present ? retryAfter.value : this.retryAfter,
  );
  PhotoRow copyWithCompanion(PhotosCompanion data) {
    return PhotoRow(
      uuid: data.uuid.present ? data.uuid.value : this.uuid,
      kind: data.kind.present ? data.kind.value : this.kind,
      path: data.path.present ? data.path.value : this.path,
      sha256: data.sha256.present ? data.sha256.value : this.sha256,
      sizeBytes: data.sizeBytes.present ? data.sizeBytes.value : this.sizeBytes,
      faceCount: data.faceCount.present ? data.faceCount.value : this.faceCount,
      takenAt: data.takenAt.present ? data.takenAt.value : this.takenAt,
      lat: data.lat.present ? data.lat.value : this.lat,
      lng: data.lng.present ? data.lng.value : this.lng,
      userId: data.userId.present ? data.userId.value : this.userId,
      sendStatus: data.sendStatus.present
          ? data.sendStatus.value
          : this.sendStatus,
      reason: data.reason.present ? data.reason.value : this.reason,
      attempts: data.attempts.present ? data.attempts.value : this.attempts,
      retryAfter: data.retryAfter.present
          ? data.retryAfter.value
          : this.retryAfter,
    );
  }

  @override
  String toString() {
    return (StringBuffer('PhotoRow(')
          ..write('uuid: $uuid, ')
          ..write('kind: $kind, ')
          ..write('path: $path, ')
          ..write('sha256: $sha256, ')
          ..write('sizeBytes: $sizeBytes, ')
          ..write('faceCount: $faceCount, ')
          ..write('takenAt: $takenAt, ')
          ..write('lat: $lat, ')
          ..write('lng: $lng, ')
          ..write('userId: $userId, ')
          ..write('sendStatus: $sendStatus, ')
          ..write('reason: $reason, ')
          ..write('attempts: $attempts, ')
          ..write('retryAfter: $retryAfter')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(
    uuid,
    kind,
    path,
    sha256,
    sizeBytes,
    faceCount,
    takenAt,
    lat,
    lng,
    userId,
    sendStatus,
    reason,
    attempts,
    retryAfter,
  );
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is PhotoRow &&
          other.uuid == this.uuid &&
          other.kind == this.kind &&
          other.path == this.path &&
          other.sha256 == this.sha256 &&
          other.sizeBytes == this.sizeBytes &&
          other.faceCount == this.faceCount &&
          other.takenAt == this.takenAt &&
          other.lat == this.lat &&
          other.lng == this.lng &&
          other.userId == this.userId &&
          other.sendStatus == this.sendStatus &&
          other.reason == this.reason &&
          other.attempts == this.attempts &&
          other.retryAfter == this.retryAfter);
}

class PhotosCompanion extends UpdateCompanion<PhotoRow> {
  final Value<String> uuid;
  final Value<String> kind;
  final Value<String> path;
  final Value<String> sha256;
  final Value<int> sizeBytes;
  final Value<int?> faceCount;
  final Value<DateTime> takenAt;
  final Value<double?> lat;
  final Value<double?> lng;
  final Value<int> userId;
  final Value<String> sendStatus;
  final Value<String?> reason;
  final Value<int> attempts;
  final Value<DateTime?> retryAfter;
  final Value<int> rowid;
  const PhotosCompanion({
    this.uuid = const Value.absent(),
    this.kind = const Value.absent(),
    this.path = const Value.absent(),
    this.sha256 = const Value.absent(),
    this.sizeBytes = const Value.absent(),
    this.faceCount = const Value.absent(),
    this.takenAt = const Value.absent(),
    this.lat = const Value.absent(),
    this.lng = const Value.absent(),
    this.userId = const Value.absent(),
    this.sendStatus = const Value.absent(),
    this.reason = const Value.absent(),
    this.attempts = const Value.absent(),
    this.retryAfter = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  PhotosCompanion.insert({
    required String uuid,
    required String kind,
    required String path,
    required String sha256,
    required int sizeBytes,
    this.faceCount = const Value.absent(),
    required DateTime takenAt,
    this.lat = const Value.absent(),
    this.lng = const Value.absent(),
    required int userId,
    this.sendStatus = const Value.absent(),
    this.reason = const Value.absent(),
    this.attempts = const Value.absent(),
    this.retryAfter = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : uuid = Value(uuid),
       kind = Value(kind),
       path = Value(path),
       sha256 = Value(sha256),
       sizeBytes = Value(sizeBytes),
       takenAt = Value(takenAt),
       userId = Value(userId);
  static Insertable<PhotoRow> custom({
    Expression<String>? uuid,
    Expression<String>? kind,
    Expression<String>? path,
    Expression<String>? sha256,
    Expression<int>? sizeBytes,
    Expression<int>? faceCount,
    Expression<DateTime>? takenAt,
    Expression<double>? lat,
    Expression<double>? lng,
    Expression<int>? userId,
    Expression<String>? sendStatus,
    Expression<String>? reason,
    Expression<int>? attempts,
    Expression<DateTime>? retryAfter,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (uuid != null) 'uuid': uuid,
      if (kind != null) 'kind': kind,
      if (path != null) 'path': path,
      if (sha256 != null) 'sha256': sha256,
      if (sizeBytes != null) 'size_bytes': sizeBytes,
      if (faceCount != null) 'face_count': faceCount,
      if (takenAt != null) 'taken_at': takenAt,
      if (lat != null) 'lat': lat,
      if (lng != null) 'lng': lng,
      if (userId != null) 'user_id': userId,
      if (sendStatus != null) 'send_status': sendStatus,
      if (reason != null) 'reason': reason,
      if (attempts != null) 'attempts': attempts,
      if (retryAfter != null) 'retry_after': retryAfter,
      if (rowid != null) 'rowid': rowid,
    });
  }

  PhotosCompanion copyWith({
    Value<String>? uuid,
    Value<String>? kind,
    Value<String>? path,
    Value<String>? sha256,
    Value<int>? sizeBytes,
    Value<int?>? faceCount,
    Value<DateTime>? takenAt,
    Value<double?>? lat,
    Value<double?>? lng,
    Value<int>? userId,
    Value<String>? sendStatus,
    Value<String?>? reason,
    Value<int>? attempts,
    Value<DateTime?>? retryAfter,
    Value<int>? rowid,
  }) {
    return PhotosCompanion(
      uuid: uuid ?? this.uuid,
      kind: kind ?? this.kind,
      path: path ?? this.path,
      sha256: sha256 ?? this.sha256,
      sizeBytes: sizeBytes ?? this.sizeBytes,
      faceCount: faceCount ?? this.faceCount,
      takenAt: takenAt ?? this.takenAt,
      lat: lat ?? this.lat,
      lng: lng ?? this.lng,
      userId: userId ?? this.userId,
      sendStatus: sendStatus ?? this.sendStatus,
      reason: reason ?? this.reason,
      attempts: attempts ?? this.attempts,
      retryAfter: retryAfter ?? this.retryAfter,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (uuid.present) {
      map['uuid'] = Variable<String>(uuid.value);
    }
    if (kind.present) {
      map['kind'] = Variable<String>(kind.value);
    }
    if (path.present) {
      map['path'] = Variable<String>(path.value);
    }
    if (sha256.present) {
      map['sha256'] = Variable<String>(sha256.value);
    }
    if (sizeBytes.present) {
      map['size_bytes'] = Variable<int>(sizeBytes.value);
    }
    if (faceCount.present) {
      map['face_count'] = Variable<int>(faceCount.value);
    }
    if (takenAt.present) {
      map['taken_at'] = Variable<DateTime>(takenAt.value);
    }
    if (lat.present) {
      map['lat'] = Variable<double>(lat.value);
    }
    if (lng.present) {
      map['lng'] = Variable<double>(lng.value);
    }
    if (userId.present) {
      map['user_id'] = Variable<int>(userId.value);
    }
    if (sendStatus.present) {
      map['send_status'] = Variable<String>(sendStatus.value);
    }
    if (reason.present) {
      map['reason'] = Variable<String>(reason.value);
    }
    if (attempts.present) {
      map['attempts'] = Variable<int>(attempts.value);
    }
    if (retryAfter.present) {
      map['retry_after'] = Variable<DateTime>(retryAfter.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('PhotosCompanion(')
          ..write('uuid: $uuid, ')
          ..write('kind: $kind, ')
          ..write('path: $path, ')
          ..write('sha256: $sha256, ')
          ..write('sizeBytes: $sizeBytes, ')
          ..write('faceCount: $faceCount, ')
          ..write('takenAt: $takenAt, ')
          ..write('lat: $lat, ')
          ..write('lng: $lng, ')
          ..write('userId: $userId, ')
          ..write('sendStatus: $sendStatus, ')
          ..write('reason: $reason, ')
          ..write('attempts: $attempts, ')
          ..write('retryAfter: $retryAfter, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

class $LocalMetaTable extends LocalMeta
    with TableInfo<$LocalMetaTable, MetaRow> {
  @override
  final GeneratedDatabase attachedDatabase;
  final String? _alias;
  $LocalMetaTable(this.attachedDatabase, [this._alias]);
  static const VerificationMeta _keyMeta = const VerificationMeta('key');
  @override
  late final GeneratedColumn<String> key = GeneratedColumn<String>(
    'key',
    aliasedName,
    false,
    type: DriftSqlType.string,
    requiredDuringInsert: true,
  );
  static const VerificationMeta _valueMeta = const VerificationMeta('value');
  @override
  late final GeneratedColumn<String> value = GeneratedColumn<String>(
    'value',
    aliasedName,
    true,
    type: DriftSqlType.string,
    requiredDuringInsert: false,
  );
  @override
  List<GeneratedColumn> get $columns => [key, value];
  @override
  String get aliasedName => _alias ?? actualTableName;
  @override
  String get actualTableName => $name;
  static const String $name = 'local_meta';
  @override
  VerificationContext validateIntegrity(
    Insertable<MetaRow> instance, {
    bool isInserting = false,
  }) {
    final context = VerificationContext();
    final data = instance.toColumns(true);
    if (data.containsKey('key')) {
      context.handle(
        _keyMeta,
        key.isAcceptableOrUnknown(data['key']!, _keyMeta),
      );
    } else if (isInserting) {
      context.missing(_keyMeta);
    }
    if (data.containsKey('value')) {
      context.handle(
        _valueMeta,
        value.isAcceptableOrUnknown(data['value']!, _valueMeta),
      );
    }
    return context;
  }

  @override
  Set<GeneratedColumn> get $primaryKey => {key};
  @override
  MetaRow map(Map<String, dynamic> data, {String? tablePrefix}) {
    final effectivePrefix = tablePrefix != null ? '$tablePrefix.' : '';
    return MetaRow(
      key: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}key'],
      )!,
      value: attachedDatabase.typeMapping.read(
        DriftSqlType.string,
        data['${effectivePrefix}value'],
      ),
    );
  }

  @override
  $LocalMetaTable createAlias(String alias) {
    return $LocalMetaTable(attachedDatabase, alias);
  }
}

class MetaRow extends DataClass implements Insertable<MetaRow> {
  final String key;
  final String? value;
  const MetaRow({required this.key, this.value});
  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    map['key'] = Variable<String>(key);
    if (!nullToAbsent || value != null) {
      map['value'] = Variable<String>(value);
    }
    return map;
  }

  LocalMetaCompanion toCompanion(bool nullToAbsent) {
    return LocalMetaCompanion(
      key: Value(key),
      value: value == null && nullToAbsent
          ? const Value.absent()
          : Value(value),
    );
  }

  factory MetaRow.fromJson(
    Map<String, dynamic> json, {
    ValueSerializer? serializer,
  }) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return MetaRow(
      key: serializer.fromJson<String>(json['key']),
      value: serializer.fromJson<String?>(json['value']),
    );
  }
  @override
  Map<String, dynamic> toJson({ValueSerializer? serializer}) {
    serializer ??= driftRuntimeOptions.defaultSerializer;
    return <String, dynamic>{
      'key': serializer.toJson<String>(key),
      'value': serializer.toJson<String?>(value),
    };
  }

  MetaRow copyWith({
    String? key,
    Value<String?> value = const Value.absent(),
  }) => MetaRow(
    key: key ?? this.key,
    value: value.present ? value.value : this.value,
  );
  MetaRow copyWithCompanion(LocalMetaCompanion data) {
    return MetaRow(
      key: data.key.present ? data.key.value : this.key,
      value: data.value.present ? data.value.value : this.value,
    );
  }

  @override
  String toString() {
    return (StringBuffer('MetaRow(')
          ..write('key: $key, ')
          ..write('value: $value')
          ..write(')'))
        .toString();
  }

  @override
  int get hashCode => Object.hash(key, value);
  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      (other is MetaRow && other.key == this.key && other.value == this.value);
}

class LocalMetaCompanion extends UpdateCompanion<MetaRow> {
  final Value<String> key;
  final Value<String?> value;
  final Value<int> rowid;
  const LocalMetaCompanion({
    this.key = const Value.absent(),
    this.value = const Value.absent(),
    this.rowid = const Value.absent(),
  });
  LocalMetaCompanion.insert({
    required String key,
    this.value = const Value.absent(),
    this.rowid = const Value.absent(),
  }) : key = Value(key);
  static Insertable<MetaRow> custom({
    Expression<String>? key,
    Expression<String>? value,
    Expression<int>? rowid,
  }) {
    return RawValuesInsertable({
      if (key != null) 'key': key,
      if (value != null) 'value': value,
      if (rowid != null) 'rowid': rowid,
    });
  }

  LocalMetaCompanion copyWith({
    Value<String>? key,
    Value<String?>? value,
    Value<int>? rowid,
  }) {
    return LocalMetaCompanion(
      key: key ?? this.key,
      value: value ?? this.value,
      rowid: rowid ?? this.rowid,
    );
  }

  @override
  Map<String, Expression> toColumns(bool nullToAbsent) {
    final map = <String, Expression>{};
    if (key.present) {
      map['key'] = Variable<String>(key.value);
    }
    if (value.present) {
      map['value'] = Variable<String>(value.value);
    }
    if (rowid.present) {
      map['rowid'] = Variable<int>(rowid.value);
    }
    return map;
  }

  @override
  String toString() {
    return (StringBuffer('LocalMetaCompanion(')
          ..write('key: $key, ')
          ..write('value: $value, ')
          ..write('rowid: $rowid')
          ..write(')'))
        .toString();
  }
}

abstract class _$AppDatabase extends GeneratedDatabase {
  _$AppDatabase(QueryExecutor e) : super(e);
  $AppDatabaseManager get managers => $AppDatabaseManager(this);
  late final $MasterRecordsTable masterRecords = $MasterRecordsTable(this);
  late final $DocumentsTable documents = $DocumentsTable(this);
  late final $PhotosTable photos = $PhotosTable(this);
  late final $LocalMetaTable localMeta = $LocalMetaTable(this);
  @override
  Iterable<TableInfo<Table, Object?>> get allTables =>
      allSchemaEntities.whereType<TableInfo<Table, Object?>>();
  @override
  List<DatabaseSchemaEntity> get allSchemaEntities => [
    masterRecords,
    documents,
    photos,
    localMeta,
  ];
}

typedef $$MasterRecordsTableCreateCompanionBuilder =
    MasterRecordsCompanion Function({
      required String entity,
      required String key,
      required String body,
      Value<bool> deleted,
      Value<int> rowid,
    });
typedef $$MasterRecordsTableUpdateCompanionBuilder =
    MasterRecordsCompanion Function({
      Value<String> entity,
      Value<String> key,
      Value<String> body,
      Value<bool> deleted,
      Value<int> rowid,
    });

class $$MasterRecordsTableFilterComposer
    extends Composer<_$AppDatabase, $MasterRecordsTable> {
  $$MasterRecordsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get entity => $composableBuilder(
    column: $table.entity,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get key => $composableBuilder(
    column: $table.key,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get body => $composableBuilder(
    column: $table.body,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<bool> get deleted => $composableBuilder(
    column: $table.deleted,
    builder: (column) => ColumnFilters(column),
  );
}

class $$MasterRecordsTableOrderingComposer
    extends Composer<_$AppDatabase, $MasterRecordsTable> {
  $$MasterRecordsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get entity => $composableBuilder(
    column: $table.entity,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get key => $composableBuilder(
    column: $table.key,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get body => $composableBuilder(
    column: $table.body,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<bool> get deleted => $composableBuilder(
    column: $table.deleted,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$MasterRecordsTableAnnotationComposer
    extends Composer<_$AppDatabase, $MasterRecordsTable> {
  $$MasterRecordsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get entity =>
      $composableBuilder(column: $table.entity, builder: (column) => column);

  GeneratedColumn<String> get key =>
      $composableBuilder(column: $table.key, builder: (column) => column);

  GeneratedColumn<String> get body =>
      $composableBuilder(column: $table.body, builder: (column) => column);

  GeneratedColumn<bool> get deleted =>
      $composableBuilder(column: $table.deleted, builder: (column) => column);
}

class $$MasterRecordsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $MasterRecordsTable,
          MasterRecord,
          $$MasterRecordsTableFilterComposer,
          $$MasterRecordsTableOrderingComposer,
          $$MasterRecordsTableAnnotationComposer,
          $$MasterRecordsTableCreateCompanionBuilder,
          $$MasterRecordsTableUpdateCompanionBuilder,
          (
            MasterRecord,
            BaseReferences<_$AppDatabase, $MasterRecordsTable, MasterRecord>,
          ),
          MasterRecord,
          PrefetchHooks Function()
        > {
  $$MasterRecordsTableTableManager(_$AppDatabase db, $MasterRecordsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$MasterRecordsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$MasterRecordsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$MasterRecordsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> entity = const Value.absent(),
                Value<String> key = const Value.absent(),
                Value<String> body = const Value.absent(),
                Value<bool> deleted = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => MasterRecordsCompanion(
                entity: entity,
                key: key,
                body: body,
                deleted: deleted,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String entity,
                required String key,
                required String body,
                Value<bool> deleted = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => MasterRecordsCompanion.insert(
                entity: entity,
                key: key,
                body: body,
                deleted: deleted,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$MasterRecordsTable, MasterRecord>(table),
                  BaseReferences<
                    _$AppDatabase,
                    $MasterRecordsTable,
                    MasterRecord
                  >(db, table, e),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$MasterRecordsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $MasterRecordsTable,
      MasterRecord,
      $$MasterRecordsTableFilterComposer,
      $$MasterRecordsTableOrderingComposer,
      $$MasterRecordsTableAnnotationComposer,
      $$MasterRecordsTableCreateCompanionBuilder,
      $$MasterRecordsTableUpdateCompanionBuilder,
      (
        MasterRecord,
        BaseReferences<_$AppDatabase, $MasterRecordsTable, MasterRecord>,
      ),
      MasterRecord,
      PrefetchHooks Function()
    >;
typedef $$DocumentsTableCreateCompanionBuilder =
    DocumentsCompanion Function({
      required String uuid,
      required String entity,
      required int userId,
      Value<int> version,
      Value<int> syncedVersion,
      required String body,
      Value<String> sendStatus,
      Value<String?> reason,
      Value<String?> detail,
      Value<String?> flags,
      Value<int?> serverId,
      Value<String?> serverStatus,
      Value<String?> serverNote,
      Value<int> attempts,
      Value<DateTime?> retryAfter,
      required DateTime createdAt,
      required DateTime updatedAt,
      Value<int> rowid,
    });
typedef $$DocumentsTableUpdateCompanionBuilder =
    DocumentsCompanion Function({
      Value<String> uuid,
      Value<String> entity,
      Value<int> userId,
      Value<int> version,
      Value<int> syncedVersion,
      Value<String> body,
      Value<String> sendStatus,
      Value<String?> reason,
      Value<String?> detail,
      Value<String?> flags,
      Value<int?> serverId,
      Value<String?> serverStatus,
      Value<String?> serverNote,
      Value<int> attempts,
      Value<DateTime?> retryAfter,
      Value<DateTime> createdAt,
      Value<DateTime> updatedAt,
      Value<int> rowid,
    });

class $$DocumentsTableFilterComposer
    extends Composer<_$AppDatabase, $DocumentsTable> {
  $$DocumentsTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get uuid => $composableBuilder(
    column: $table.uuid,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get entity => $composableBuilder(
    column: $table.entity,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get userId => $composableBuilder(
    column: $table.userId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get version => $composableBuilder(
    column: $table.version,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get syncedVersion => $composableBuilder(
    column: $table.syncedVersion,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get body => $composableBuilder(
    column: $table.body,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get sendStatus => $composableBuilder(
    column: $table.sendStatus,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get reason => $composableBuilder(
    column: $table.reason,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get detail => $composableBuilder(
    column: $table.detail,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get flags => $composableBuilder(
    column: $table.flags,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get serverId => $composableBuilder(
    column: $table.serverId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get serverStatus => $composableBuilder(
    column: $table.serverStatus,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get serverNote => $composableBuilder(
    column: $table.serverNote,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get attempts => $composableBuilder(
    column: $table.attempts,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get retryAfter => $composableBuilder(
    column: $table.retryAfter,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnFilters(column),
  );
}

class $$DocumentsTableOrderingComposer
    extends Composer<_$AppDatabase, $DocumentsTable> {
  $$DocumentsTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get uuid => $composableBuilder(
    column: $table.uuid,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get entity => $composableBuilder(
    column: $table.entity,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get userId => $composableBuilder(
    column: $table.userId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get version => $composableBuilder(
    column: $table.version,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get syncedVersion => $composableBuilder(
    column: $table.syncedVersion,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get body => $composableBuilder(
    column: $table.body,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get sendStatus => $composableBuilder(
    column: $table.sendStatus,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get reason => $composableBuilder(
    column: $table.reason,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get detail => $composableBuilder(
    column: $table.detail,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get flags => $composableBuilder(
    column: $table.flags,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get serverId => $composableBuilder(
    column: $table.serverId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get serverStatus => $composableBuilder(
    column: $table.serverStatus,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get serverNote => $composableBuilder(
    column: $table.serverNote,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get attempts => $composableBuilder(
    column: $table.attempts,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get retryAfter => $composableBuilder(
    column: $table.retryAfter,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get createdAt => $composableBuilder(
    column: $table.createdAt,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get updatedAt => $composableBuilder(
    column: $table.updatedAt,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$DocumentsTableAnnotationComposer
    extends Composer<_$AppDatabase, $DocumentsTable> {
  $$DocumentsTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get uuid =>
      $composableBuilder(column: $table.uuid, builder: (column) => column);

  GeneratedColumn<String> get entity =>
      $composableBuilder(column: $table.entity, builder: (column) => column);

  GeneratedColumn<int> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<int> get version =>
      $composableBuilder(column: $table.version, builder: (column) => column);

  GeneratedColumn<int> get syncedVersion => $composableBuilder(
    column: $table.syncedVersion,
    builder: (column) => column,
  );

  GeneratedColumn<String> get body =>
      $composableBuilder(column: $table.body, builder: (column) => column);

  GeneratedColumn<String> get sendStatus => $composableBuilder(
    column: $table.sendStatus,
    builder: (column) => column,
  );

  GeneratedColumn<String> get reason =>
      $composableBuilder(column: $table.reason, builder: (column) => column);

  GeneratedColumn<String> get detail =>
      $composableBuilder(column: $table.detail, builder: (column) => column);

  GeneratedColumn<String> get flags =>
      $composableBuilder(column: $table.flags, builder: (column) => column);

  GeneratedColumn<int> get serverId =>
      $composableBuilder(column: $table.serverId, builder: (column) => column);

  GeneratedColumn<String> get serverStatus => $composableBuilder(
    column: $table.serverStatus,
    builder: (column) => column,
  );

  GeneratedColumn<String> get serverNote => $composableBuilder(
    column: $table.serverNote,
    builder: (column) => column,
  );

  GeneratedColumn<int> get attempts =>
      $composableBuilder(column: $table.attempts, builder: (column) => column);

  GeneratedColumn<DateTime> get retryAfter => $composableBuilder(
    column: $table.retryAfter,
    builder: (column) => column,
  );

  GeneratedColumn<DateTime> get createdAt =>
      $composableBuilder(column: $table.createdAt, builder: (column) => column);

  GeneratedColumn<DateTime> get updatedAt =>
      $composableBuilder(column: $table.updatedAt, builder: (column) => column);
}

class $$DocumentsTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $DocumentsTable,
          DocumentRow,
          $$DocumentsTableFilterComposer,
          $$DocumentsTableOrderingComposer,
          $$DocumentsTableAnnotationComposer,
          $$DocumentsTableCreateCompanionBuilder,
          $$DocumentsTableUpdateCompanionBuilder,
          (
            DocumentRow,
            BaseReferences<_$AppDatabase, $DocumentsTable, DocumentRow>,
          ),
          DocumentRow,
          PrefetchHooks Function()
        > {
  $$DocumentsTableTableManager(_$AppDatabase db, $DocumentsTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$DocumentsTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$DocumentsTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$DocumentsTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> uuid = const Value.absent(),
                Value<String> entity = const Value.absent(),
                Value<int> userId = const Value.absent(),
                Value<int> version = const Value.absent(),
                Value<int> syncedVersion = const Value.absent(),
                Value<String> body = const Value.absent(),
                Value<String> sendStatus = const Value.absent(),
                Value<String?> reason = const Value.absent(),
                Value<String?> detail = const Value.absent(),
                Value<String?> flags = const Value.absent(),
                Value<int?> serverId = const Value.absent(),
                Value<String?> serverStatus = const Value.absent(),
                Value<String?> serverNote = const Value.absent(),
                Value<int> attempts = const Value.absent(),
                Value<DateTime?> retryAfter = const Value.absent(),
                Value<DateTime> createdAt = const Value.absent(),
                Value<DateTime> updatedAt = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => DocumentsCompanion(
                uuid: uuid,
                entity: entity,
                userId: userId,
                version: version,
                syncedVersion: syncedVersion,
                body: body,
                sendStatus: sendStatus,
                reason: reason,
                detail: detail,
                flags: flags,
                serverId: serverId,
                serverStatus: serverStatus,
                serverNote: serverNote,
                attempts: attempts,
                retryAfter: retryAfter,
                createdAt: createdAt,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String uuid,
                required String entity,
                required int userId,
                Value<int> version = const Value.absent(),
                Value<int> syncedVersion = const Value.absent(),
                required String body,
                Value<String> sendStatus = const Value.absent(),
                Value<String?> reason = const Value.absent(),
                Value<String?> detail = const Value.absent(),
                Value<String?> flags = const Value.absent(),
                Value<int?> serverId = const Value.absent(),
                Value<String?> serverStatus = const Value.absent(),
                Value<String?> serverNote = const Value.absent(),
                Value<int> attempts = const Value.absent(),
                Value<DateTime?> retryAfter = const Value.absent(),
                required DateTime createdAt,
                required DateTime updatedAt,
                Value<int> rowid = const Value.absent(),
              }) => DocumentsCompanion.insert(
                uuid: uuid,
                entity: entity,
                userId: userId,
                version: version,
                syncedVersion: syncedVersion,
                body: body,
                sendStatus: sendStatus,
                reason: reason,
                detail: detail,
                flags: flags,
                serverId: serverId,
                serverStatus: serverStatus,
                serverNote: serverNote,
                attempts: attempts,
                retryAfter: retryAfter,
                createdAt: createdAt,
                updatedAt: updatedAt,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$DocumentsTable, DocumentRow>(table),
                  BaseReferences<_$AppDatabase, $DocumentsTable, DocumentRow>(
                    db,
                    table,
                    e,
                  ),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$DocumentsTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $DocumentsTable,
      DocumentRow,
      $$DocumentsTableFilterComposer,
      $$DocumentsTableOrderingComposer,
      $$DocumentsTableAnnotationComposer,
      $$DocumentsTableCreateCompanionBuilder,
      $$DocumentsTableUpdateCompanionBuilder,
      (
        DocumentRow,
        BaseReferences<_$AppDatabase, $DocumentsTable, DocumentRow>,
      ),
      DocumentRow,
      PrefetchHooks Function()
    >;
typedef $$PhotosTableCreateCompanionBuilder =
    PhotosCompanion Function({
      required String uuid,
      required String kind,
      required String path,
      required String sha256,
      required int sizeBytes,
      Value<int?> faceCount,
      required DateTime takenAt,
      Value<double?> lat,
      Value<double?> lng,
      required int userId,
      Value<String> sendStatus,
      Value<String?> reason,
      Value<int> attempts,
      Value<DateTime?> retryAfter,
      Value<int> rowid,
    });
typedef $$PhotosTableUpdateCompanionBuilder =
    PhotosCompanion Function({
      Value<String> uuid,
      Value<String> kind,
      Value<String> path,
      Value<String> sha256,
      Value<int> sizeBytes,
      Value<int?> faceCount,
      Value<DateTime> takenAt,
      Value<double?> lat,
      Value<double?> lng,
      Value<int> userId,
      Value<String> sendStatus,
      Value<String?> reason,
      Value<int> attempts,
      Value<DateTime?> retryAfter,
      Value<int> rowid,
    });

class $$PhotosTableFilterComposer
    extends Composer<_$AppDatabase, $PhotosTable> {
  $$PhotosTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get uuid => $composableBuilder(
    column: $table.uuid,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get kind => $composableBuilder(
    column: $table.kind,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get path => $composableBuilder(
    column: $table.path,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get sha256 => $composableBuilder(
    column: $table.sha256,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get sizeBytes => $composableBuilder(
    column: $table.sizeBytes,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get faceCount => $composableBuilder(
    column: $table.faceCount,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get takenAt => $composableBuilder(
    column: $table.takenAt,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get lat => $composableBuilder(
    column: $table.lat,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<double> get lng => $composableBuilder(
    column: $table.lng,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get userId => $composableBuilder(
    column: $table.userId,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get sendStatus => $composableBuilder(
    column: $table.sendStatus,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get reason => $composableBuilder(
    column: $table.reason,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<int> get attempts => $composableBuilder(
    column: $table.attempts,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<DateTime> get retryAfter => $composableBuilder(
    column: $table.retryAfter,
    builder: (column) => ColumnFilters(column),
  );
}

class $$PhotosTableOrderingComposer
    extends Composer<_$AppDatabase, $PhotosTable> {
  $$PhotosTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get uuid => $composableBuilder(
    column: $table.uuid,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get kind => $composableBuilder(
    column: $table.kind,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get path => $composableBuilder(
    column: $table.path,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get sha256 => $composableBuilder(
    column: $table.sha256,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get sizeBytes => $composableBuilder(
    column: $table.sizeBytes,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get faceCount => $composableBuilder(
    column: $table.faceCount,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get takenAt => $composableBuilder(
    column: $table.takenAt,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get lat => $composableBuilder(
    column: $table.lat,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<double> get lng => $composableBuilder(
    column: $table.lng,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get userId => $composableBuilder(
    column: $table.userId,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get sendStatus => $composableBuilder(
    column: $table.sendStatus,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get reason => $composableBuilder(
    column: $table.reason,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<int> get attempts => $composableBuilder(
    column: $table.attempts,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<DateTime> get retryAfter => $composableBuilder(
    column: $table.retryAfter,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$PhotosTableAnnotationComposer
    extends Composer<_$AppDatabase, $PhotosTable> {
  $$PhotosTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get uuid =>
      $composableBuilder(column: $table.uuid, builder: (column) => column);

  GeneratedColumn<String> get kind =>
      $composableBuilder(column: $table.kind, builder: (column) => column);

  GeneratedColumn<String> get path =>
      $composableBuilder(column: $table.path, builder: (column) => column);

  GeneratedColumn<String> get sha256 =>
      $composableBuilder(column: $table.sha256, builder: (column) => column);

  GeneratedColumn<int> get sizeBytes =>
      $composableBuilder(column: $table.sizeBytes, builder: (column) => column);

  GeneratedColumn<int> get faceCount =>
      $composableBuilder(column: $table.faceCount, builder: (column) => column);

  GeneratedColumn<DateTime> get takenAt =>
      $composableBuilder(column: $table.takenAt, builder: (column) => column);

  GeneratedColumn<double> get lat =>
      $composableBuilder(column: $table.lat, builder: (column) => column);

  GeneratedColumn<double> get lng =>
      $composableBuilder(column: $table.lng, builder: (column) => column);

  GeneratedColumn<int> get userId =>
      $composableBuilder(column: $table.userId, builder: (column) => column);

  GeneratedColumn<String> get sendStatus => $composableBuilder(
    column: $table.sendStatus,
    builder: (column) => column,
  );

  GeneratedColumn<String> get reason =>
      $composableBuilder(column: $table.reason, builder: (column) => column);

  GeneratedColumn<int> get attempts =>
      $composableBuilder(column: $table.attempts, builder: (column) => column);

  GeneratedColumn<DateTime> get retryAfter => $composableBuilder(
    column: $table.retryAfter,
    builder: (column) => column,
  );
}

class $$PhotosTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $PhotosTable,
          PhotoRow,
          $$PhotosTableFilterComposer,
          $$PhotosTableOrderingComposer,
          $$PhotosTableAnnotationComposer,
          $$PhotosTableCreateCompanionBuilder,
          $$PhotosTableUpdateCompanionBuilder,
          (PhotoRow, BaseReferences<_$AppDatabase, $PhotosTable, PhotoRow>),
          PhotoRow,
          PrefetchHooks Function()
        > {
  $$PhotosTableTableManager(_$AppDatabase db, $PhotosTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$PhotosTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$PhotosTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$PhotosTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> uuid = const Value.absent(),
                Value<String> kind = const Value.absent(),
                Value<String> path = const Value.absent(),
                Value<String> sha256 = const Value.absent(),
                Value<int> sizeBytes = const Value.absent(),
                Value<int?> faceCount = const Value.absent(),
                Value<DateTime> takenAt = const Value.absent(),
                Value<double?> lat = const Value.absent(),
                Value<double?> lng = const Value.absent(),
                Value<int> userId = const Value.absent(),
                Value<String> sendStatus = const Value.absent(),
                Value<String?> reason = const Value.absent(),
                Value<int> attempts = const Value.absent(),
                Value<DateTime?> retryAfter = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => PhotosCompanion(
                uuid: uuid,
                kind: kind,
                path: path,
                sha256: sha256,
                sizeBytes: sizeBytes,
                faceCount: faceCount,
                takenAt: takenAt,
                lat: lat,
                lng: lng,
                userId: userId,
                sendStatus: sendStatus,
                reason: reason,
                attempts: attempts,
                retryAfter: retryAfter,
                rowid: rowid,
              ),
          createCompanionCallback:
              ({
                required String uuid,
                required String kind,
                required String path,
                required String sha256,
                required int sizeBytes,
                Value<int?> faceCount = const Value.absent(),
                required DateTime takenAt,
                Value<double?> lat = const Value.absent(),
                Value<double?> lng = const Value.absent(),
                required int userId,
                Value<String> sendStatus = const Value.absent(),
                Value<String?> reason = const Value.absent(),
                Value<int> attempts = const Value.absent(),
                Value<DateTime?> retryAfter = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => PhotosCompanion.insert(
                uuid: uuid,
                kind: kind,
                path: path,
                sha256: sha256,
                sizeBytes: sizeBytes,
                faceCount: faceCount,
                takenAt: takenAt,
                lat: lat,
                lng: lng,
                userId: userId,
                sendStatus: sendStatus,
                reason: reason,
                attempts: attempts,
                retryAfter: retryAfter,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$PhotosTable, PhotoRow>(table),
                  BaseReferences<_$AppDatabase, $PhotosTable, PhotoRow>(
                    db,
                    table,
                    e,
                  ),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$PhotosTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $PhotosTable,
      PhotoRow,
      $$PhotosTableFilterComposer,
      $$PhotosTableOrderingComposer,
      $$PhotosTableAnnotationComposer,
      $$PhotosTableCreateCompanionBuilder,
      $$PhotosTableUpdateCompanionBuilder,
      (PhotoRow, BaseReferences<_$AppDatabase, $PhotosTable, PhotoRow>),
      PhotoRow,
      PrefetchHooks Function()
    >;
typedef $$LocalMetaTableCreateCompanionBuilder =
    LocalMetaCompanion Function({
      required String key,
      Value<String?> value,
      Value<int> rowid,
    });
typedef $$LocalMetaTableUpdateCompanionBuilder =
    LocalMetaCompanion Function({
      Value<String> key,
      Value<String?> value,
      Value<int> rowid,
    });

class $$LocalMetaTableFilterComposer
    extends Composer<_$AppDatabase, $LocalMetaTable> {
  $$LocalMetaTableFilterComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnFilters<String> get key => $composableBuilder(
    column: $table.key,
    builder: (column) => ColumnFilters(column),
  );

  ColumnFilters<String> get value => $composableBuilder(
    column: $table.value,
    builder: (column) => ColumnFilters(column),
  );
}

class $$LocalMetaTableOrderingComposer
    extends Composer<_$AppDatabase, $LocalMetaTable> {
  $$LocalMetaTableOrderingComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  ColumnOrderings<String> get key => $composableBuilder(
    column: $table.key,
    builder: (column) => ColumnOrderings(column),
  );

  ColumnOrderings<String> get value => $composableBuilder(
    column: $table.value,
    builder: (column) => ColumnOrderings(column),
  );
}

class $$LocalMetaTableAnnotationComposer
    extends Composer<_$AppDatabase, $LocalMetaTable> {
  $$LocalMetaTableAnnotationComposer({
    required super.$db,
    required super.$table,
    super.joinBuilder,
    super.$addJoinBuilderToRootComposer,
    super.$removeJoinBuilderFromRootComposer,
  });
  GeneratedColumn<String> get key =>
      $composableBuilder(column: $table.key, builder: (column) => column);

  GeneratedColumn<String> get value =>
      $composableBuilder(column: $table.value, builder: (column) => column);
}

class $$LocalMetaTableTableManager
    extends
        RootTableManager<
          _$AppDatabase,
          $LocalMetaTable,
          MetaRow,
          $$LocalMetaTableFilterComposer,
          $$LocalMetaTableOrderingComposer,
          $$LocalMetaTableAnnotationComposer,
          $$LocalMetaTableCreateCompanionBuilder,
          $$LocalMetaTableUpdateCompanionBuilder,
          (MetaRow, BaseReferences<_$AppDatabase, $LocalMetaTable, MetaRow>),
          MetaRow,
          PrefetchHooks Function()
        > {
  $$LocalMetaTableTableManager(_$AppDatabase db, $LocalMetaTable table)
    : super(
        TableManagerState(
          db: db,
          table: table,
          createFilteringComposer: () =>
              $$LocalMetaTableFilterComposer($db: db, $table: table),
          createOrderingComposer: () =>
              $$LocalMetaTableOrderingComposer($db: db, $table: table),
          createComputedFieldComposer: () =>
              $$LocalMetaTableAnnotationComposer($db: db, $table: table),
          updateCompanionCallback:
              ({
                Value<String> key = const Value.absent(),
                Value<String?> value = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => LocalMetaCompanion(key: key, value: value, rowid: rowid),
          createCompanionCallback:
              ({
                required String key,
                Value<String?> value = const Value.absent(),
                Value<int> rowid = const Value.absent(),
              }) => LocalMetaCompanion.insert(
                key: key,
                value: value,
                rowid: rowid,
              ),
          withReferenceMapper: (p0) => p0
              .map(
                (e) => (
                  e.readTable<$LocalMetaTable, MetaRow>(table),
                  BaseReferences<_$AppDatabase, $LocalMetaTable, MetaRow>(
                    db,
                    table,
                    e,
                  ),
                ),
              )
              .toList(),
          prefetchHooksCallback: null,
        ),
      );
}

typedef $$LocalMetaTableProcessedTableManager =
    ProcessedTableManager<
      _$AppDatabase,
      $LocalMetaTable,
      MetaRow,
      $$LocalMetaTableFilterComposer,
      $$LocalMetaTableOrderingComposer,
      $$LocalMetaTableAnnotationComposer,
      $$LocalMetaTableCreateCompanionBuilder,
      $$LocalMetaTableUpdateCompanionBuilder,
      (MetaRow, BaseReferences<_$AppDatabase, $LocalMetaTable, MetaRow>),
      MetaRow,
      PrefetchHooks Function()
    >;

class $AppDatabaseManager {
  final _$AppDatabase _db;
  $AppDatabaseManager(this._db);
  $$MasterRecordsTableTableManager get masterRecords =>
      $$MasterRecordsTableTableManager(_db, _db.masterRecords);
  $$DocumentsTableTableManager get documents =>
      $$DocumentsTableTableManager(_db, _db.documents);
  $$PhotosTableTableManager get photos =>
      $$PhotosTableTableManager(_db, _db.photos);
  $$LocalMetaTableTableManager get localMeta =>
      $$LocalMetaTableTableManager(_db, _db.localMeta);
}
